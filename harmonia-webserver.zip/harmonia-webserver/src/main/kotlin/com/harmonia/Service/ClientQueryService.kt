package com.harmonia.Service

import com.harmonia.schemas.*
import com.harmonia.states.*
import net.corda.core.contracts.ContractState
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.messaging.CordaRPCOps
import net.corda.core.messaging.vaultQueryBy
import net.corda.core.node.services.CordaService
import net.corda.core.node.services.Vault
import net.corda.core.node.services.vault.*
import net.corda.core.node.services.vault.Builder.equal
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import net.corda.core.serialization.SingletonSerializeAsToken
import kotlin.reflect.KProperty1

@CordaService
class ClientQueryService(val proxy : CordaRPCOps) : SingletonSerializeAsToken() {


    fun linearStateQueryProjectUsers(linearIdList: List<String>) = linearStateQueryWithPagination<ProjectUsersState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryContainer(linearIdList: List<String>) = linearStateQueryWithPagination<DocumentContainerDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryFiles(linearIdList: List<String>) = linearStateQueryWithPagination<FileDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryPackage(linearIdList: List<String>) = linearStateQueryWithPagination<AcceptancePackageState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryProject(linearIdList: List<String>) = linearStateQueryWithPagination<ProjectDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryActivity(linearIdList: List<String>) = linearStateQueryWithPagination<ActivityDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryWorkplan(linearIdList: List<String>) = linearStateQueryWithPagination<WorkplanDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryMilestone(linearIdList: List<String>) = linearStateQueryWithPagination<MilestoneDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryChecklist(linearIdList: List<String>) = linearStateQueryWithPagination<ChecklistDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    fun linearStateQueryHistoryItemProof(linearIdList : List<String>) = linearStateQueryHistoryWithPagination<ChecklistItemDetailsState>(linearIdList = linearIdList.map { UniqueIdentifier.fromString(it) })

    //QUERY ALL FUNCTION
    fun queryAllUsers() = QueryAll<UserEnrollmentState>()

    fun queryAllProject() = QueryAll<ProjectDetailsState>()

    fun queryAllProjectUsers() = QueryAll<ProjectUsersState>()

    //CUSTOM QUERY FUNCTION

    fun customQueryChecklistItemDetailsByCategory(LinearId : String) = customQueryWithPagination<ChecklistItemDetailsState, PersistChecklistItemDetails>(PersistChecklistItemDetails::mappedToLinearId,LinearId)

    fun customQueryChecklistCategory(checklistLinearId : String) = customQueryWithPagination<ChecklistCategoryDetailsState, PersistChecklistCategoryDetails>(PersistChecklistCategoryDetails :: mappedToLinearId, checklistLinearId)

    fun customQueryContainerDetails(mappedToLinearId : String) = customQueryWithPagination<DocumentContainerDetailsState, PersistDocumentContainerDetails>(PersistDocumentContainerDetails::mappedToLinearId,mappedToLinearId)

    fun customQueryFileDetails(containerLinearId : String) = customQueryWithPagination<FileDetailsState, PersistFileDetails>(PersistFileDetails::mappedToLinearId,containerLinearId)

    fun customQueryWorkplanDetails(projectLinearId: String) = customQueryWithPagination<WorkplanDetailsState, PersistWorkplanDetails>(PersistWorkplanDetails::mappedToLinearId,projectLinearId)

    fun customQueryPackageDetails(projectLinearId : String) = customQueryWithPagination<AcceptancePackageState, PersistAcceptancePackage>(PersistAcceptancePackage::projectLinearId,projectLinearId)

    fun customQueryPackageDetailsList(projectLinearId : List<String>) = customQueryListWithPagination<AcceptancePackageState, PersistAcceptancePackage>(PersistAcceptancePackage::projectLinearId,projectLinearId)

    fun customQueryCommentsHistoryDetails(linearId: String) = customQueryHistoryWithPagination<CommentState, PersistComments>(PersistComments :: mappedToLinearId, linearId)

    fun customQueryChecklistDetails(projectLinearId : String) = customQueryWithPagination<ChecklistDetailsState, PersistChecklistDetails>(PersistChecklistDetails::projectLinearId,projectLinearId)

    fun customQueryChecklistDetailsByActivity(mappedToLinearId : String) = customQueryWithPagination<ChecklistDetailsState, PersistChecklistDetails>(PersistChecklistDetails::mappedToLinearId,mappedToLinearId)

    fun customQueryChecklistDetailsList(projectLinearId : List<String>) = customQueryListWithPagination<ChecklistDetailsState, PersistChecklistDetails>(PersistChecklistDetails::projectLinearId,projectLinearId)

    fun customQueryApproverStatusDetails(packageLinearId : String) = customQueryWithPagination<ApproverStatusDetailsState, PersistApproverStatusDetails>(PersistApproverStatusDetails::packageLinearId,packageLinearId)

    fun customQueryPackageDetailsByPackId(packageLinearId : String) = customQueryWithPagination<AcceptancePackageState, PersistAcceptancePackage>(PersistAcceptancePackage::packageLinearId,packageLinearId)

    fun customQueryEnrolledUserDetails(emailId: String) = customQueryWithPagination<UserEnrollmentState, PersistUserEnrollment>(PersistUserEnrollment::emailId, emailId)

    fun customQueryProjectUsersDetails(projectLinearId: String) = customQueryWithPagination<ProjectUsersState, PersistProjectUsers>(PersistProjectUsers::projectLinearId, projectLinearId)

    fun customQueryProjectDetails(projectLinearId: String) = customQueryWithPagination<ProjectDetailsState, PersistProjectDetails>(PersistProjectDetails::projectLinearId, projectLinearId)

    fun customQueryActivityDetails(mappedToLinearId: String) = customQueryWithPagination<ActivityDetailsState, PersistActivityDetails>(PersistActivityDetails::mappedToLinearId, mappedToLinearId)

    fun customQueryActivityDetailsByActivityLinearId(activityLinearId: String) = customQueryWithPagination<ActivityDetailsState, PersistActivityDetails>(PersistActivityDetails::activityLinearId, activityLinearId)

    fun customQueryActivityDetailsByProject(projectLinearId: String) = customQueryWithPagination<ActivityDetailsState, PersistActivityDetails>(PersistActivityDetails::projectLinearId, projectLinearId)

    fun customQueryMilestoneDetails(projectLinearId: String) = customQueryWithPagination<MilestoneDetailsState, PersistMilestoneDetails>(PersistMilestoneDetails::projectLinearId, projectLinearId)

    fun customQueryMilestoneDetailsByWorkplan(workplanLinearId: String) = customQueryWithPagination<MilestoneDetailsState, PersistMilestoneDetails>(PersistMilestoneDetails::workplanLinearId, workplanLinearId)

    fun customQueryAllPackageByProjectId(projectLinearId : String) = customQueryWithPagination<ApproverStatusDetailsState, PersistApproverStatusDetails>(PersistApproverStatusDetails::projectLinearId, projectLinearId)


    //QUERY ALL FOR CONTRACT STATE
    inline fun <reified S : ContractState> QueryAll(criteria: QueryCriteria = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)):MutableList<StateAndRef<S>>{
        var pageNumber = DEFAULT_PAGE_NUM
        val pageSize = DEFAULT_PAGE_SIZE
        val states = mutableListOf<StateAndRef<S>>()
        do{
            val pageSpec = PageSpecification(pageNumber = pageNumber, pageSize = pageSize)
            val results = proxy.vaultQueryBy<S>(criteria,pageSpec)
            states.addAll(results.states)
            pageNumber++
        }while ((pageSpec.pageSize * (pageNumber - 1)) <= results.totalStatesAvailable)
        // Caution: A pages maximum size MAX_PAGE_SIZE is defined as Int.MAX_VALUE and should be used with extreme caution as results returned may exceed your JVM’s memory footprint.

        return states
    }

    //CUSTOM QUERY WITH PAGINATION
    inline fun <reified S : QueryableState, T: PersistentState> customQueryWithPagination(column: KProperty1<T, String>, id: String): MutableList<StateAndRef< S >> {

        var pageNumber = DEFAULT_PAGE_NUM
        val pageSize = DEFAULT_PAGE_SIZE
        val expression = builder { column.equal(id) }
        val criteria = QueryCriteria.VaultCustomQueryCriteria(expression = expression)
        val states = mutableListOf<StateAndRef< S >>()
        do {
            val pageSpec = PageSpecification(pageNumber = pageNumber, pageSize = pageSize)
            val results = proxy.vaultQueryBy< S >(criteria, pageSpec)
            states.addAll(results.states)
            pageNumber++
        } while ((pageSpec.pageSize * (pageNumber - 1)) <= results.totalStatesAvailable)

        return states
    }

    inline fun <reified S : QueryableState, T: PersistentState> customQueryListWithPagination(column: KProperty1<T, String>, id: List<String>): MutableList<StateAndRef< S >> {

        var pageNumber = DEFAULT_PAGE_NUM
        val pageSize = DEFAULT_PAGE_SIZE
        val expression = builder { column.equal(id) }
        val criteria = QueryCriteria.VaultCustomQueryCriteria(expression = expression)
        val states = mutableListOf<StateAndRef< S >>()
        do {
            val pageSpec = PageSpecification(pageNumber = pageNumber, pageSize = pageSize)
            val results = proxy.vaultQueryBy< S >(criteria, pageSpec)
            states.addAll(results.states)
            pageNumber++
        } while ((pageSpec.pageSize * (pageNumber - 1)) <= results.totalStatesAvailable)

        return states
    }

    inline fun <reified S : QueryableState> linearStateQueryHistoryWithPagination(linearIdList: List<UniqueIdentifier>): MutableList<StateAndRef< S >> {

        var pageNumber = DEFAULT_PAGE_NUM
        val pageSize = DEFAULT_PAGE_SIZE
        val inputCriteria = QueryCriteria.LinearStateQueryCriteria(linearId = linearIdList, status = Vault.StateStatus.ALL)
        val states = mutableListOf<StateAndRef< S >>()
        do {
            val pageSpec = PageSpecification(pageNumber = pageNumber, pageSize = pageSize)
            val results = proxy.vaultQueryBy< S >(inputCriteria, pageSpec)
            //val results = proxy.queryBy< S >(inputCriteria, pageSpec)
            states.addAll(results.states)
            pageNumber++
        } while ((pageSpec.pageSize * (pageNumber - 1)) <= results.totalStatesAvailable)

        return states
    }


    //LINEAR STATE QUERY
    inline fun <reified S : QueryableState> linearStateQueryWithPagination(linearIdList: List<UniqueIdentifier>): MutableList<StateAndRef< S >> {

        var pageNumber = DEFAULT_PAGE_NUM
        val pageSize = DEFAULT_PAGE_SIZE
        val inputCriteria = QueryCriteria.LinearStateQueryCriteria(linearId = linearIdList)
        val states = mutableListOf<StateAndRef< S >>()
        do {
            val pageSpec = PageSpecification(pageNumber = pageNumber, pageSize = pageSize)
            val results = proxy.vaultQueryBy< S >(inputCriteria, pageSpec)
            //val results = proxy.queryBy< S >(inputCriteria, pageSpec)
            states.addAll(results.states)
            pageNumber++
        } while ((pageSpec.pageSize * (pageNumber - 1)) <= results.totalStatesAvailable)

        return states
    }

    inline fun <reified S : QueryableState, T: PersistentState> customQueryHistoryWithPagination(column: KProperty1<T, String>, id: String): MutableList<StateAndRef< S >> {

        var pageNumber = DEFAULT_PAGE_NUM
        val pageSize = DEFAULT_PAGE_SIZE
        val expression = builder { column.equal(id) }
        val criteria = QueryCriteria.VaultCustomQueryCriteria(expression = expression, status = Vault.StateStatus.ALL)
        val states = mutableListOf<StateAndRef< S >>()
        do {
            val pageSpec = PageSpecification(pageNumber = pageNumber, pageSize = pageSize)
            val results = proxy.vaultQueryBy< S >(criteria, pageSpec)
            states.addAll(results.states)
            pageNumber++
        } while ((pageSpec.pageSize * (pageNumber - 1)) <= results.totalStatesAvailable)

        return states
    }
}
package com.harmonia.Service

import com.harmonia.model.*
import com.harmonia.states.AcceptancePackageState
import com.harmonia.states.ProjectDetailsState
import khttp.post
import net.corda.core.messaging.vaultTrackBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.utilities.getOrThrow
import org.json.JSONObject
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.messaging.simp.SimpMessagingTemplate
import org.springframework.stereotype.Component
import java.time.Instant
import java.time.temporal.ChronoUnit
import javax.annotation.PostConstruct
import javax.annotation.PreDestroy


@Component
open class ClientNotification : AutoCloseable {

    @Autowired
    private lateinit var cordaDataService: CordaDataService
    @Autowired
    private val template: SimpMessagingTemplate? = null


    @PostConstruct
    fun initialiseNotificationConnection() {


        cordaDataService.proxy.vaultTrackBy<AcceptancePackageState>().updates.subscribe { it ->
            val states = it.produced
            val packageDetails = states.single().state.data.packageDetails
            var emailNotification : TaskReminderNotification = TaskReminderNotification()
            if (packageDetails.internalApprovalCompleted) {
                for (j in packageDetails.customerApprovers) {
                    if ( j.noOfRemainders <= 2 ) {
                        emailNotification = TaskReminderNotification(
                                emailId = j.emailId,
                                taskType = "Acceptance Package",
                                taskName = packageDetails.packageName,
                                status = j.overallUserApprovalStatus,
                                dueDate = j.dueDate
                        )
                        post(url = "http://localhost:3001/approvalMail", headers=mapOf("Content-Type" to "application/json"), data = JSONObject(emailNotification))
                    }
                }
            }  else {
                for (i in packageDetails.ericssonApprovers) {
                    if ( i.noOfRemainders <= 2 ) {
                        emailNotification = TaskReminderNotification(
                                emailId = i.emailId,
                                taskType = "Acceptance Package",
                                taskName = packageDetails.packageName,
                                status = i.overallUserApprovalStatus,
                                dueDate = i.dueDate
                        )
                        post(url = "http://localhost:3001/approvalMail", headers=mapOf("Content-Type" to "application/json"), data = JSONObject(emailNotification))
                    }
                }
            }
        }


       /* cordaDataService.proxy.vaultTrackBy<DocumentApprovalState>().updates.subscribe { it ->
            val states = it.produced
            if(!states.filter { it.state.data.docApproval.overAllApprovalStatus.equals("PENDING APPROVAL") }.any()){
                val message = it.produced.map { it.state.data.docApproval }
                if (template != null) {
                    template.convertAndSendToUser("user","/notification", message)
                }
            }

        }*/
    }

    @PreDestroy
    override fun close() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}

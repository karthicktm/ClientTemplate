package com.harmonia.webserver

import com.harmonia.model.PackageUsers
import com.harmonia.model.SLANotification
import com.harmonia.states.AcceptancePackageState
import net.corda.client.rpc.CordaRPCClient
import net.corda.client.rpc.CordaRPCConnection
import net.corda.client.rpc.GracefulReconnect
import net.corda.core.messaging.CordaRPCOps
import net.corda.core.node.services.Vault
import net.corda.core.node.services.vault.DEFAULT_PAGE_NUM
import net.corda.core.node.services.vault.DEFAULT_PAGE_SIZE
import net.corda.core.node.services.vault.PageSpecification
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.utilities.NetworkHostAndPort
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import java.time.Instant
import javax.annotation.PostConstruct
import javax.annotation.PreDestroy

private const val CORDA_USER_NAME = "config.rpc.username"
private const val CORDA_USER_PASSWORD = "config.rpc.password"
private const val CORDA_NODE_HOST = "config.rpc.host"
private const val CORDA_RPC_PORT = "config.rpc.port"

/**
 * Wraps an RPC connection to a Corda node.
 *
 * The RPC connection is configured using command line arguments.
 *
 * @param host The host of the node we are connecting to.
 * @param rpcPort The RPC port of the node we are connecting to.
 * @param username The username for logging into the RPC client.
 * @param password The password for logging into the RPC client.
 * @property proxy The RPC proxy.
 */

@Component
open class NodeRPCConnection(
        @Value("\${$CORDA_NODE_HOST}") private val host: String,
        @Value("\${$CORDA_USER_NAME}") private val username: String,
        @Value("\${$CORDA_USER_PASSWORD}") private val password: String,
        @Value("\${$CORDA_RPC_PORT}") private val rpcPort: Int): AutoCloseable {

    lateinit var rpcConnection: CordaRPCConnection
        private set
    lateinit var proxy: CordaRPCOps
        private set

    private fun onDisconnect() : Unit {
        // Insert implementation
        System.out.print("ERROR:DISCONNECT DETECTED\n")
    }
    private fun onReconnect() : Unit {
        // Insert implementation
        System.out.print("INFO:RECONNECT SUCCESSFULLY\n")
        val criteria = QueryCriteria.VaultQueryCriteria(status = Vault.StateStatus.UNCONSUMED)
        val pageSpec = PageSpecification(pageNumber = DEFAULT_PAGE_NUM, pageSize = DEFAULT_PAGE_SIZE)
        val updates = proxy.vaultTrackByWithPagingSpec(AcceptancePackageState::class.java, paging = pageSpec, criteria = criteria).updates
        val approvers = mutableListOf<PackageUsers>()
        val notificationDetailsList = mutableListOf<SLANotification>()
        updates.asObservable().subscribe { update ->
            update.produced.forEach {
                val currentState = it.state.data.packageDetails
                val ericApprovers = it.state.data.packageDetails.ericssonApprovers.filter { it.slaStart == true && it.noOfRemainders > 0 && it.overallUserApprovalStatus == "AWAITING APPROVAL" }
                val custApprovers = it.state.data.packageDetails.customerApprovers.filter { it.slaStart == true && it.noOfRemainders > 0 && it.overallUserApprovalStatus == "AWAITING APPROVAL" }
                approvers.addAll(ericApprovers)
                approvers.addAll(custApprovers)
                approvers.forEach {
                    val slaNotification = SLANotification(
                            emailId = it.emailId,
                            packageLinearId = currentState.packageLinearId,
                            packageName = currentState.packageName,
                            projectId = currentState.projectId,
                            projectLinearId = currentState.projectLinearId,
                            dueDate = it.dueDate.toString(),
                            currentStatus = it.overallUserApprovalStatus,
                            noOfRemainders = it.noOfRemainders,
                            subject = ""
                    )
                    notificationDetailsList.add(slaNotification)
                }
                approvers.clear()
                if (notificationDetailsList.size > 0) {
                    System.out.println("NotificationList Size:" + notificationDetailsList.size)
                    System.out.println("Notification Details:" + notificationDetailsList)
                    System.out.println("Notification:" + notificationDetailsList.get(0).emailId + "--" + notificationDetailsList.get(0).noOfRemainders + "--" + Instant.now())
                }
                notificationDetailsList.clear()
            }
        }
    }

    @PostConstruct
    fun initialiseNodeRPCConnection() {
        val gracefulReconnect = GracefulReconnect(this::onDisconnect, this::onReconnect, 5)
        val rpcAddress = NetworkHostAndPort(host, rpcPort)
        val rpcClient = CordaRPCClient(rpcAddress)
        val rpcConnection = rpcClient.start(username, password, gracefulReconnect)
            proxy = rpcConnection.proxy
    }

    @PreDestroy
    override fun close() {
        rpcConnection.notifyServerAndClose()
    }
}


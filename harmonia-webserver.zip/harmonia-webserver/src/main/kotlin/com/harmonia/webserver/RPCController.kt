package com.harmonia.webserver

import com.azure.core.util.Context
import com.azure.storage.blob.BlobServiceClientBuilder
import com.azure.storage.blob.options.BlobParallelUploadOptions
import com.google.gson.Gson
import com.harmonia.Service.ClientQueryService
import com.harmonia.flows.AddCommentFlow
import com.harmonia.flows.DocumentContainerDetailsFlow
import com.harmonia.flows.*
import com.harmonia.flows.Approval.*
import com.harmonia.flows.updates.*
import com.harmonia.flows.FileDetailsFlow
import com.harmonia.flows.UserEnrollmentFlow
import com.harmonia.flows.updates.UpdateCommentFlow
import com.harmonia.flows.updates.UpdateContainerDetailsFlow
import com.harmonia.flows.updates.UpdateProjectDetailsFlow
import com.harmonia.model.*
import com.harmonia.service.HarmoniaVaultService
import com.harmonia.states.*
import com.harmonia.webserver.APIUtils.checkForNull
import com.harmonia.webserver.APIUtils.getErisiteProjectDetails
import com.harmonia.webserver.APIUtils.getSiteDetailsFromErisite
import khttp.get
import khttp.post
import net.corda.client.jackson.JacksonSupport
import net.corda.core.contracts.StateAndRef
import net.corda.core.identity.CordaX500Name
import net.corda.core.messaging.startFlow
import net.corda.core.messaging.startTrackedFlow
import net.corda.core.node.services.Vault
import net.corda.core.node.services.vault.DEFAULT_PAGE_NUM
import net.corda.core.node.services.vault.DEFAULT_PAGE_SIZE
import net.corda.core.node.services.vault.PageSpecification
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.serialization.internal._rpcClientSerializationEnv
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Bean
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile
import java.time.Duration
import java.time.Instant
import java.util.*
import javax.servlet.http.HttpServletRequest
import kotlin.concurrent.thread
import kotlin.math.sign
import org.json.JSONArray
import org.json.JSONObject
import org.springframework.core.io.InputStreamResource
import org.springframework.http.HttpHeaders
import org.springframework.mail.javamail.JavaMailSender
import org.springframework.mail.javamail.MimeMessageHelper
import org.springframework.messaging.simp.SimpMessagingTemplate
import java.io.IOException
import javax.mail.MessagingException
import javax.mail.internet.MimeMessage
import khttp.structures.authorization.BasicAuthorization
import javax.persistence.criteria.CriteriaBuilder

/**
 * Define your API endpoints here.
 */

/*@RestController
@RequestMapping("/") // The paths for HTTP requests are relative to this base path.*/
@RestController
@CrossOrigin(origins = ["*"])
@RequestMapping("/api/")
class RPCController(rpc: NodeRPCConnection) {
    @Autowired
    private val template: SimpMessagingTemplate? = null
    @Autowired
    private val javaMailSender: JavaMailSender? = null

    companion object {
        private val logger = LoggerFactory.getLogger(RPCController::class.java)
    }

    @Bean
    open fun mappingJackson2HttpMessageConverter(@Autowired rpcConnection: NodeRPCConnection): MappingJackson2HttpMessageConverter {
        val mapper = JacksonSupport.createDefaultMapper(rpcConnection.proxy)
        val converter = MappingJackson2HttpMessageConverter()
        converter.objectMapper = mapper
        return converter
    }

    private val proxy = rpc.proxy

    //Add User to Harmonia Application
    @PostMapping(value = ["enroll-user"], produces = ["application/json"], consumes = ["application/json"])
    fun enrollUser(@RequestBody userDetails: List<UserEnrollment>): ResponseEntity<List<UserEnrollment>> {
        return try {
            logger.info("ENROLL-USER --- Initiated for users: "+userDetails.map { it.emailId })
            val currentUserList = getAllUsers().body
            userDetails.forEach {
                val userDetail = it
                if(currentUserList.size > 0){
                    if(currentUserList.any {it.emailId == userDetail.emailId}){
                        logger.info("ENROLL-USER --- User already Exists:"+ it.emailId)
                        return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(emptyList())
                    }
                }
            }
            val partyX500NamePartyCust: CordaX500Name
            partyX500NamePartyCust = CordaX500Name.parse("O=Customer A, L=New York, C=US")
            val proposeToParty = proxy.wellKnownPartyFromX500Name(partyX500NamePartyCust)
                    ?: throw IllegalArgumentException("Target string \"$partyX500NamePartyCust\" doesn't match any nodes on the network.")
            val signTxn = proxy.startFlow(::UserEnrollmentFlow, userDetails, proposeToParty).returnValue.getOrThrow()
            val userEnrollmentDetails = signTxn.coreTransaction.outputsOfType<UserEnrollmentState>().map { it.userEnrollmentDetails }
            ResponseEntity.status(HttpStatus.CREATED).body(userEnrollmentDetails)
        } catch (exception: Throwable) {
            logger.error(exception.message, exception)
            ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(emptyList<UserEnrollment>())
        }
    }

    //Get ALL USERS OF HARMONIA APPLICATION
    @GetMapping(value = ["getAllEnrolledUsers"], produces = ["application/json"])
    fun getAllUsers(): ResponseEntity<List<UserEnrollment>> {
        logger.info("GET ALL ENROLLED USERS --- Initiated")
        val userList = ClientQueryService(proxy).queryAllUsers()
        if(userList.size > 0)
            return ResponseEntity.status(200).body(userList.map { it.state.data.userEnrollmentDetails })
        else
            return ResponseEntity.status(200).body(emptyList())
    }

    @GetMapping(value = ["getEnrolledUsers/{emailId}"], produces = ["application/json"])
    fun getEnrolledUsers(@PathVariable emailId: String): ResponseEntity<UserEnrollment> {
        logger.info("GET SPECIFIC ENROLLED USER --- Initiated for user: "+emailId)
        val userList = ClientQueryService(proxy).customQueryEnrolledUserDetails(emailId)
        if(userList.size > 0)
            return ResponseEntity.status(200).body(userList.map { it.state.data.userEnrollmentDetails }.get(0))
        else
            logger.info("GET SPECIFIC ENROLLED USER --- User Not Found")
            throw Exception("GET SPECIFIC ENROLLED USER --- User Not Found")
    }

    @GetMapping(value = ["checkPackageNameExists/{projectLinearId}/{packageName}"], produces = ["application/json"])
    fun checkPackageNameExists(@PathVariable projectLinearId: String, @PathVariable packageName: String): ResponseEntity<Validation> {

        logger.info("CHECK PACKAGE NAME EXISTS  --- Initiated for project: "+projectLinearId)
        val allPackages = ClientQueryService(proxy).customQueryPackageDetails(projectLinearId)
        var found  = Validation()
        if(allPackages.size > 0) {
            val packageNames = allPackages.map { it.state.data.packageDetails.packageName }
            found = Validation(
                    found =  packageNames?.any { it.equals(packageName, true) } ?: false
            )
        }
        return ResponseEntity.ok(found)
    }

    //Import Project Details and its sub-components
    @PostMapping(value = ["importProjectDetails/{projectId}"], produces = ["application/json"])
    private fun importProjectDetails(@PathVariable projectId: String,
                                     @RequestHeader(value = "belongsTo") belongsTo: String,
                                     @RequestHeader(value = "emailId") emailId: String,
                                     @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ProjectImportStatus> {
        logger.info("IMPORT PROJECT DETAILS --- Initiated for id: "+projectId)
        logger.info("IMPORT PROJECT DETAILS --- Import Started at: " + Instant.now())
//        System.out.println("Import Started ---" + Instant.now())
        if (roleName != "CONTRIBUTOR" && belongsTo != "ERICSSON")
            throw Exception("IMPORT PROJECT DETAILS --- Either Role is not mapped to Contributor or not belongs to Ericsson")
        var projectLinearId: String = ""

        var listOfWorkplanTree = mutableListOf<WorkplanTree>()
        return try {
            val projectDetails = APIUtils.getErisiteProjectDetails(projectId)
            projectLinearId = APIUtils.submitProjectDetails(projectDetails, proxy)
            thread {
                logger.info("IMPORT PROJECT DETAILS ---  process all workplans")
                listOfWorkplanTree.addAll(APIUtils.processAllWorkplan(projectId, projectLinearId, proxy))
                val workplanBySiteMap = listOfWorkplanTree.groupBy { it.siteId }
                val workplanBySiteList = mutableListOf<WorkplanBySite>()
                for ((siteId, listOfWp) in workplanBySiteMap) {
                    val workplanBySite = WorkplanBySite(
                            siteId = siteId,
			                siteName = listOfWp.get(0).siteName,
                            workplanDetails = listOfWp
                    )
                    workplanBySiteList.add(workplanBySite)
                }
                val projectTree = ProjectTree(
                        projectId = projectDetails.projectId,
                        projectLinearId = projectLinearId,
                        projectName = projectDetails.projectName,
                        workplanBySite = workplanBySiteList
                )
                val projectStructure = ProjectStructure(
                        projectid = projectLinearId.toString(),
                        data = projectTree
                )
                logger.info("IMPORT PROJECT DETAILS ---  Project Structure: "+projectStructure)
                logger.info("IMPORT PROJECT DETAILS ---  Project Object: "+JSONObject(projectStructure))
//                System.out.println("ProjectStructure:" + projectStructure)
//                System.out.println("ProjectObject:" + JSONObject(projectStructure))
                val submitTreeStructure = post(OFF_CHAIN_WEB_URL + "/submitProject", headers = mapOf("Content-Type" to "application/json"), data = JSONObject(projectStructure))
//                System.out.println("Status :" + submitTreeStructure.statusCode)
                logger.info("IMPORT PROJECT DETAILS ---  Import Status: "+submitTreeStructure.statusCode)
                val updateProjectDetails = UpdateProjectDetails(
                        importStatus = "COMPLETED",
                        projectLinearId = projectLinearId
                )
                val updateProject = proxy.startFlow(::UpdateProjectDetailsFlow, updateProjectDetails).returnValue.getOrThrow()
                sendImportNotification(projectId, projectLinearId, updateProject.coreTransaction.outputsOfType<ProjectDetailsState>().single().projectDetails.importStatus)
                logger.info("IMPORT PROJECT DETAILS ---  Import Ended: "+Instant.now())
            }
            val clientProjectUserModel = ClientProjectUserModel(
                    projectId = projectId,
                    projectLinearId = projectLinearId,
                    projectName = projectDetails.projectName,
                    emailId = emailId,
                    roleName = "CONTRIBUTOR",
                    creationTime = Instant.now(),
                    updationTime = Instant.now()
            )
            addProjectUsers(clientProjectUserModel, belongsTo, emailId, roleName)
            val importStatus = ProjectImportStatus(
                    projectId = projectId,
                    projectLinearId = projectLinearId,
                    projectName = projectDetails.projectName,
                    importStatus = "IN-PROGRESS",
                    user = emailId,
                    message = ""
            )
            ResponseEntity.status(200).body(importStatus)
        } catch (exception: Throwable) {
            logger.error(exception.message, exception)
            val projectStatus = ProjectImportStatus(
                    projectId = projectId,
                    projectLinearId = projectLinearId,
                    importStatus = "FAILED",
                    user = emailId,
                    message = exception.message.toString()
            )
            return ResponseEntity.badRequest().body(projectStatus)
        }
    }

    fun sendImportNotification(projectId : String, projectLinearId : String, importStatus : String){
        val message = ImportProjectNotification(
                projectId = projectId,
                projectLinearId = projectLinearId,
                importStatus = importStatus
        )
        logger.info("SEND IMPORT NOTIFICATION ---  Initiated")
        template?.convertAndSendToUser("user","/import-notification", message)
    }

    @PostMapping(value = ["addProjectUser"], produces = ["application/json"])
    private fun addProjectUsers(@RequestBody userDetails: ClientProjectUserModel,
                                @RequestHeader(value = "belongsTo") belongsTo: String,
                                @RequestHeader(value = "emailId") emailId: String,
                                @RequestHeader(value = "roleName") roleName: String): ResponseEntity<List<UserDetails>> {
        return try {
            logger.info("ADD PROJECT USER ---  Initiated for user: "+userDetails.emailId)
            val enrollmentUserDetails = ClientQueryService(proxy).customQueryEnrolledUserDetails(userDetails.emailId)
            logger.info("ADD PROJECT USER ---  Enrolled user details: "+enrollmentUserDetails)
//            System.out.println("Enrolled User Details:"+ enrollmentUserDetails)
            val projectUsers = ClientQueryService(proxy).customQueryProjectUsersDetails(userDetails.projectLinearId)
//            System.out.println("Project Users List:"+ projectUsers)
            var signTxn: SignedTransaction
            if (enrollmentUserDetails.size <= 0)
                throw Exception("ADD PROJECT USER --- User Not Enrolled")
            else {
                val userInfo = enrollmentUserDetails.get(0).state.data.userEnrollmentDetails
                val mapUserDetails = UserDetails(
                        firstName = userInfo.firstName,
                        belongsTo = userInfo.belongsTo,
                        lastName = userInfo.lastName,
                        emailId = userInfo.emailId,
                        userId = userInfo.userId,
                        roleName = userDetails.roleName,
                        domain = userInfo.emailDomain
                )
                val projectUserDetails = ProjectUserDetails(
                        projectLinearId = userDetails.projectLinearId,
                        projectUsersLinearId = "",
                        userDetails = listOf(mapUserDetails)
                )
                if (projectUsers.size == 0) {
//                    System.out.println("Addd Project users flow:"+projectUsers)
                    signTxn = proxy.startFlow(::AddProjectUsersFlow, projectUserDetails).returnValue.getOrThrow()
                    logger.info("ADD PROJECT USER ---  User added to project successfully")
                } else {
                    signTxn = proxy.startFlow(::UpdateProjectUsersFlow, projectUserDetails).returnValue.getOrThrow()
                }
//                val Status = ProjectImportStatus(
//                        projectId = userDetails.p,
//                        projectLinearId = userDetails.projectLinearId,
//                        projectName = userDetails.projectName,
//                        importStatus = userDetails.roleName,
//                        user = userDetails.emailId,
//                        message = "User Added successfully to Project"
//                )
//                val mailNotification = post("http://20.50.147.243:3001/addUserMail", headers = mapOf("Content-Type" to "application/json"), data = JSONObject(Status))
                val projectDetails = ClientQueryService(proxy).customQueryProjectDetails(userDetails.projectLinearId).get(0)
                sendEmail("USER",userDetails.emailId,userInfo.firstName,projectDetails.state.data.projectDetails.projectName,userDetails.roleName,userDetails.projectLinearId,"","","")
                return ResponseEntity.ok(signTxn.coreTransaction.outputsOfType<ProjectUsersState>().get(0).projectUsersDetails.userDetails)
            }
        } catch (exception: Throwable) {
            ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(emptyList<UserDetails>())
        }

    }

    @GetMapping(value = ["getProjectUsers/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectUsers(@PathVariable projectLinearId: String): ResponseEntity<List<UserDetails>> {
        logger.info("GET PROJECT USERS ---  Initiated for project: "+projectLinearId)
        val projectDetails = ClientQueryService(proxy).customQueryProjectUsersDetails(projectLinearId)
        logger.info("GET PROJECT USER ---  Project users exists? Size: "+ projectDetails.size)
        if (projectDetails.size > 0) {
            return ResponseEntity.ok(projectDetails.get(0).state.data.projectUsersDetails.userDetails)
        } else {
            return ResponseEntity.ok(emptyList<UserDetails>())
        }
    }

    @GetMapping(value = ["getListOfProjectApprovers/{projectLinearId}"], produces = ["application/json"])
    private fun getListOfApprovers(@PathVariable projectLinearId: String): ResponseEntity<List<UserDetails>> {
        logger.info("GET LIST OF PROJECT APPROVERS ---  Initiated for project: "+projectLinearId)
        val userList = ClientQueryService(proxy).customQueryProjectUsersDetails(projectLinearId)
        if (userList.size > 0) {
            val userDetails = userList.get(0).state.data.projectUsersDetails.userDetails
            val roleMap = userDetails.groupBy { it.roleName }
            if (roleMap.get("APPROVER")!!.size > 0)
                return ResponseEntity.ok(roleMap.get("APPROVER"))
            else
                return ResponseEntity.ok(emptyList())
        } else
            return ResponseEntity.ok(emptyList())
    }

    @GetMapping(value = ["getProjectSetupStatus/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectSetupStatus(@PathVariable projectLinearId: String,
                                      @RequestHeader(value = "belongsTo") belongsTo: String,
                                      @RequestHeader(value = "emailId") emailId: String,
                                      @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ProjectSetupStatus> {
        logger.info("GET PROJECT SETUP STATUS  ---  Initiated for project: "+projectLinearId)
        val projectDetails = getProjectDetailsByLinearId(projectLinearId)
        var projectImportState = projectDetails.body.importStatus == "COMPLETED"
        val projectSetupStatus = ProjectSetupStatus(
                projectDetails = projectImportState,
                usersGroups = projectImportState,
                siteStructure = projectImportState,
                approversVisibility = true
        )
        return ResponseEntity.ok(projectSetupStatus)

    }

    @GetMapping(value = ["getProjectDetailsByLinearId/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectDetailsByLinearId(@PathVariable projectLinearId: String): ResponseEntity<ProjectDetails> {
        logger.info("GET PROJECT DETAILS BY LINEARID  ---  Initiated for project: "+projectLinearId)
        val projectDetails = ClientQueryService(proxy).linearStateQueryProject(listOf(projectLinearId))
        if (projectDetails.size != 1)
            throw Exception("GET PROJECT DETAILS BY LINEARID  --- Project Linear Id either does not exist or has duplicate")
        return ResponseEntity.ok(projectDetails.single().state.data.projectDetails)
    }

    @PostMapping(value = ["createDocumentContainer"], produces = ["application/json"], consumes = ["application/json"])
    private fun createDocumentContainer(@RequestBody containerDetails: DocumentContainerDetails,
                                        @RequestHeader(value = "belongsTo") belongsTo: String,
                                        @RequestHeader(value = "emailId") emailId: String,
                                        @RequestHeader(value = "roleName") roleName: String): ResponseEntity<DocumentContainerDetails> {
        try {
            logger.info("CREATE DOCUMENT CONTAINER  ---  Initiated for object: "+containerDetails.mappedToLinearId)
            val updateContainerDetails = containerDetails.copy(
                    containerStoragePath = containerDetails.projectId + "/" + containerDetails.siteId + "/" + containerDetails.workplanId + "/" + containerDetails.mappedToLinearId + "/" + containerDetails.containerName,
                    containerApprovalStatus = APPROVAL_STATUS.PENDING.toString()
            )
            val signtxn = proxy.startFlow(::DocumentContainerDetailsFlow, mutableListOf(updateContainerDetails)).returnValue.getOrThrow()
            return ResponseEntity.accepted().body(signtxn.coreTransaction.outputsOfType<DocumentContainerDetailsState>().single().containerDetails)
        } catch (e: Exception) {
            throw e
        }
    }

    @PostMapping(value = ["addFilesToContainer/{containerLinearId}"])
    private fun addFilesToContainer(@RequestParam("file") file: MultipartFile,
                                    @PathVariable containerLinearId: String,
                                    @RequestHeader(value = "belongsTo") belongsTo: String,
                                    @RequestHeader(value = "emailId") emailId: String,
                                    @RequestHeader(value = "roleName") roleName: String): ResponseEntity<FileUploadResponse> {
        try {
            logger.info("ADD FILES TO CONTAINER  ---  Initiated for container: "+containerLinearId)
            var modified: Boolean = false
            val containerDetails = ClientQueryService(proxy).linearStateQueryContainer(listOf(containerLinearId)).single().state.data.containerDetails
            val connectStr = STORAGE_CONNECTION_STRING
            val blobServiceClient = BlobServiceClientBuilder().connectionString(connectStr).buildClient()
            val containerName = STORAGE_CONTAINER_NAME
            val containerClient = blobServiceClient.getBlobContainerClient(containerName);

            val blobClient = containerClient.getBlobClient(containerDetails.containerStoragePath + "/" + file.originalFilename)
            if (blobClient.exists()) {
                modified = true
                val updateContainerDet = UpdateContainerDetails(
                        isInternal = containerDetails.isInternal,
                        containerType = containerDetails.containerType,
                        containerApprovalStatus = containerDetails.containerApprovalStatus,
                        description = containerDetails.containerDescription,
                        containerLinearId = containerLinearId,
                        isModified = modified
                )
                val txn = proxy.startFlow(::UpdateContainerDetailsFlow, updateContainerDet).returnValue.getOrThrow()
            }
            val uploadResponse = blobClient.uploadWithResponse(BlobParallelUploadOptions(file.inputStream, file.size), Duration.ofMinutes(5), Context.NONE)
            logger.info("ADD FILES TO CONTAINER  ---  Blob response: "+uploadResponse.statusCode)

            val fileDetails = FileDetails(
                    fileLinearId = "",
                    mappedToLinearId = containerLinearId,
                    isInternal = false,
                    fileUrl = blobClient.blobUrl,
                    isFileModified = modified,
                    fileHash = uploadResponse.value.contentMd5.toString(),
                    fileModifiedDate = Instant.now().toString(),
                    fileSize = file.size.toString(),
                    fileStoragePath = blobClient.blobUrl,
                    comment = "",
                    fileVersion = APIUtils.checkForNull(uploadResponse.value.versionId).toString(),
                    fileName = file.originalFilename
            )
            val signTxn = proxy.startFlow(::FileDetailsFlow, mutableListOf(fileDetails)).returnValue.getOrThrow()
            val fileUploadResponse = FileUploadResponse(
                    uploaded = "SUCCESS",
                    fileName = file.originalFilename,
                    fileLinearId = signTxn.coreTransaction.outputsOfType<FileDetailsState>().get(0).fileDetails.fileLinearId
            )
            return ResponseEntity.ok(fileUploadResponse)
        } catch (e: Exception) {
            val fileUploadResponse = FileUploadResponse(
                    uploaded = "FAILED",
                    fileName = file.originalFilename,
                    fileLinearId = ""
            )
            return ResponseEntity.badRequest().body(fileUploadResponse)
        }
    }

    @GetMapping(value = ["getContainerWithFileDetails/{mappedLinearId}"], produces = ["application/json"])
    private fun getContainerWithFileDetails(@PathVariable mappedLinearId : String ) : ResponseEntity<List<ClientDocumentContainer>> {
        logger.info("GET CONTAINER WITH FILE DETAILS  ---   Initiated for container: "+mappedLinearId)
        var containerDetails = mutableListOf<StateAndRef<DocumentContainerDetailsState>>()
        containerDetails = ClientQueryService(proxy).customQueryContainerDetails(mappedLinearId)
        var listOfContainerDetails = mutableListOf<ClientDocumentContainer>()
        if (containerDetails.size > 0) {
            // val fileDetailsRef = ClientQueryService(proxy).linearStateQueryFiles(containerDetails.map { it.state.data.containerDetails.containerLinearId })
            for(i in 0..(containerDetails.size - 1)){
                val fileDetailsRef = ClientQueryService(proxy).customQueryFileDetails(containerDetails.get(i).state.data.containerDetails.containerLinearId)
                if(fileDetailsRef.size > 0){
                    logger.info("GET CONTAINER WITH FILE DETAILS  ---   Container includes files: "+fileDetailsRef.size)
                    val fileMapContainer = fileDetailsRef.map { it.state.data.fileDetails }
                    val docMap = containerDetails.get(i).state.data.containerDetails.copy(
                            filesCount = fileMapContainer.size
                    )
                    val tempClientDocContainer = ClientDocumentContainer(
                            containerDetails = docMap,
                            fileDetails = fileMapContainer
                    )
                    listOfContainerDetails.add(tempClientDocContainer)
                }
                else{
                    val tempCliDocumentContainer = ClientDocumentContainer(
                            containerDetails = containerDetails.get(i).state.data.containerDetails
                    )
                    listOfContainerDetails.add(tempCliDocumentContainer)
                }
            }
        }
        return ResponseEntity.ok(listOfContainerDetails)
    }

//    @GetMapping(value = ["getContainerWithFileDetails/{mappedToLevelName}/{mappedLinearId}"], produces = ["application/json"])
//    private fun getContainerWithFileDetailsByMappedToId(@PathVariable mappedLinearId : String, @PathVariable mappedToLevelName: String ) : ResponseEntity<ClientDocumentDetails> {
//        var containerDetails = mutableListOf<StateAndRef<DocumentContainerDetailsState>>()
//        var mappingDetails = MappingDetails()
//        containerDetails = ClientQueryService(proxy).customQueryContainerDetails(mappedLinearId)
//        var listOfContainerDetails = mutableListOf<ClientDocumentContainer>()
//        if (containerDetails.size > 0) {
//            val fileDetailsRef = ClientQueryService(proxy).linearStateQueryFiles(containerDetails.map { it.state.data.containerDetails.containerLinearId })
//            mappingDetails.projectId = containerDetails.get(0).state.data.containerDetails.projectId
//            mappingDetails.projectLinearId = containerDetails.get(0).state.data.containerDetails.projectLinearId
//            mappingDetails.siteId = containerDetails.get(0).state.data.containerDetails.siteId
//            mappingDetails.siteName = containerDetails.get(0).state.data.containerDetails.siteName
//            mappingDetails.workplanId = containerDetails.get(0).state.data.containerDetails.workplanId
//            mappingDetails.workplanLinearId = containerDetails.get(0).state.data.containerDetails.workplanLinearId
//            for(i in 0..(containerDetails.size - 1)){
//                if(fileDetailsRef.size > 0){
//                    val fileMapContainer = fileDetailsRef.filter { it.state.data.fileDetails.mappedToLinearId == containerDetails.get(i).state.data.containerDetails.containerLinearId }.map { it.state.data.fileDetails }
//                    val docMap = containerDetails.get(i).state.data.containerDetails.copy(
//                            filesCount = fileMapContainer.size
//                    )
//                    val tempClientDocContainer = ClientDocumentContainer(
//                            containerDetails = docMap,
//                            fileDetails = fileMapContainer
//                    )
//                    listOfContainerDetails.add(tempClientDocContainer)
//                }
//                else{
//                    val tempCliDocumentContainer = ClientDocumentContainer(
//                            containerDetails = containerDetails.get(i).state.data.containerDetails
//                    )
//                    listOfContainerDetails.add(tempCliDocumentContainer)
//                }
//            }
//            val clientDocDetails = ClientDocumentDetails(
//                    mappingDetails = mappingDetails,
//                    docDetails = listOfContainerDetails
//            )
//            return ResponseEntity.ok(clientDocDetails)
//        }else{
//            if(mappedToLevelName == "WORKPLAN"){
//                val wpDetails = ClientQueryService(proxy).linearStateQueryWorkplan(listOf(mappedLinearId)).get(0)
//                mappingDetails.projectId = wpDetails.state.data.workplanDetails.projectId
//                mappingDetails.projectLinearId = wpDetails.state.data.workplanDetails.mappedToLinearId
//                mappingDetails.siteId = wpDetails.state.data.workplanDetails.siteId
//                mappingDetails.siteName = wpDetails.state.data.workplanDetails.siteName
//                mappingDetails.workplanId = wpDetails.state.data.workplanDetails.workplanId
//                mappingDetails.workplanLinearId = wpDetails.state.data.workplanDetails.workplanLinearId
//                val clientDocDetails = ClientDocumentDetails(
//                        mappingDetails = mappingDetails,
//                        docDetails = emptyList()
//                )
//                return ResponseEntity.ok(clientDocDetails)
//            }
//            else if(mappedToLevelName == "ACTIVITY"){
//                val actDetails = ClientQueryService(proxy).linearStateQueryActivity(listOf(mappedLinearId)).get(0)
//                mappingDetails.projectId = actDetails.state.data.activityDetails.projectId
//                mappingDetails.projectLinearId = actDetails.state.data.activityDetails.projectLinearId
//                mappingDetails.workplanId = actDetails.state.data.activityDetails.workplanId
//                mappingDetails.workplanLinearId = actDetails.state.data.activityDetails.workplanLinearId
//                mappingDetails.siteName = actDetails.state.data.activityDetails.siteName
//                mappingDetails.siteId = actDetails.state.data.activityDetails.siteId
//                val clientDocDetails = ClientDocumentDetails(
//                        mappingDetails = mappingDetails,
//                        docDetails = emptyList()
//                )
//                return ResponseEntity.ok(clientDocDetails)
//            }
//            else{
//                val msDetails = ClientQueryService(proxy).linearStateQueryMilestone(listOf(mappedLinearId)).get(0)
//                mappingDetails.projectId = msDetails.state.data.milestoneDetails.projectId
//                mappingDetails.projectLinearId = msDetails.state.data.milestoneDetails.projectLinearId
//                mappingDetails.workplanId = msDetails.state.data.milestoneDetails.workplanId
//                mappingDetails.workplanLinearId = msDetails.state.data.milestoneDetails.workplanLinearId
//                mappingDetails.siteName = msDetails.state.data.milestoneDetails.siteName
//                mappingDetails.siteId = msDetails.state.data.milestoneDetails.siteId
//                val clientDocDetails = ClientDocumentDetails(
//                        mappingDetails = mappingDetails,
//                        docDetails = emptyList()
//                )
//                return ResponseEntity.ok(clientDocDetails)
//            }
//        }
//    }

    @GetMapping(value = ["getContainerWithFileDetails/{mappedLinearId}/{containerLinearId}"], produces = ["application/json"])
    private fun getContainerWithFileDetails(@PathVariable mappedLinearId : String, @PathVariable containerLinearId : String ) : ResponseEntity<List<ClientDocumentContainer>> {
        logger.info("GET CONTAINER WITH FILE DETAILS  ---   Initiated for object: "+mappedLinearId+" and container linearId: "+containerLinearId)
        var containerDetails = mutableListOf<StateAndRef<DocumentContainerDetailsState>>()
        containerDetails = ClientQueryService(proxy).linearStateQueryContainer(listOf(containerLinearId))
        var listOfContainerDetails = mutableListOf<ClientDocumentContainer>()
        if (containerDetails.size > 0) {
            val fileDetailsRef = ClientQueryService(proxy).linearStateQueryFiles(containerDetails.map { it.state.data.containerDetails.containerLinearId })
            for(i in 0..(containerDetails.size - 1)){
                if(fileDetailsRef.size > 0){
                    logger.info("GET CONTAINER WITH FILE DETAILS  ---   Container includes files: "+fileDetailsRef.size)
                    val fileMapContainer = fileDetailsRef.filter { it.state.data.fileDetails.mappedToLinearId == containerDetails.get(i).state.data.containerDetails.containerLinearId }.map { it.state.data.fileDetails }
                    val docMap = containerDetails.get(i).state.data.containerDetails.copy(
                            filesCount = fileMapContainer.size
                    )
                    val tempClientDocContainer = ClientDocumentContainer(
                            containerDetails = docMap,
                            fileDetails = fileMapContainer
                    )
                    listOfContainerDetails.add(tempClientDocContainer)
                }
                else{
                    val tempCliDocumentContainer = ClientDocumentContainer(
                            containerDetails = containerDetails.get(i).state.data.containerDetails
                    )
                    listOfContainerDetails.add(tempCliDocumentContainer)
                }
            }
        }
        return ResponseEntity.ok(listOfContainerDetails)
    }

    @GetMapping(value = ["getFileListByContainerId/{containerLinearId}"], produces = ["application/json"])
    private fun getFileListByContainerId(@PathVariable containerLinearId : String) : ResponseEntity<List<FileDetails>>{
        logger.info("GET FILE LIST BY CONTAINER ID  ---   Initiated for container: "+containerLinearId)
        val fileDetails = ClientQueryService(proxy).customQueryFileDetails(containerLinearId)
        var files = mutableListOf<FileDetails>()
        if(fileDetails.size > 0){
            files = fileDetails.map { it.state.data.fileDetails }.toMutableList()
        }
        return ResponseEntity.ok(files)
    }

    @PostMapping(value = ["updateDocumentContainer"], produces = ["application/json"], consumes = ["application/json"])
    private fun updateDocumentContainer(@RequestBody updateContainerDetails : UpdateContainerDetails,
                                        @RequestHeader(value = "belongsTo") belongsTo: String,
                                        @RequestHeader(value = "emailId") emailId: String,
                                        @RequestHeader(value = "roleName") roleName: String): ResponseEntity<DocumentContainerDetails> {
        try{
            logger.info("GET FILE LIST BY CONTAINER ID  ---   Initiated for container"+updateContainerDetails.containerLinearId)
            val signTxn = proxy.startFlow(::UpdateContainerDetailsFlow, updateContainerDetails).returnValue.getOrThrow()
            return ResponseEntity.ok(signTxn.coreTransaction.outputsOfType<DocumentContainerDetailsState>().get(0).containerDetails)
        }catch(e : Exception){
            throw e
        }

    }

    //Changes 18.02.2021

//    @GetMapping(value = ["getListOfSiteWithWorkplans/{projectLinearId}"], produces = ["application/json"])
//    private fun getListOfSitesByProjectLinearId(@PathVariable projectLinearId : String,
//                                                @RequestHeader(value = "belongsTo") belongsTo: String,
//                                                @RequestHeader(value = "emailId") emailId: String,
//                                                @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<Map<String,List<WorkplanDetails>>>{
//        val workplanDetails = ClientQueryService(proxy).customQueryWorkplanDetails(projectLinearId)
//        var siteMapWithWP : Map<String,List<WorkplanDetails>> = emptyMap()
//        if(workplanDetails.size > 0){
//            val workplanList = workplanDetails.map { it.state.data.workplanDetails }
//            siteMapWithWP = workplanList.groupBy { it.siteId }
//        }
//        return ResponseEntity.ok(siteMapWithWP)
//    }

    @PostMapping(value = ["submitComment"], produces = arrayOf("application/JSON"), consumes = arrayOf("application/JSON"))
    private fun submitPackageComment(@RequestBody commentReq: CommentModel,
                                     @RequestHeader(value = "belongsTo") belongsTo : String,
                                     @RequestHeader(value = "emailId") emailId : String,
                                     @RequestHeader(value = "roleName") roleName : String): ResponseEntity<CommentNotification> {
        logger.info("SUBMIT COMMENT  ---   Initiated for LinearId: "+commentReq.mappedToLinearId)
        val linearId = commentReq.mappedToLinearId
        val signTxn : SignedTransaction
        val comments = ClientQueryService(proxy).customQueryCommentsHistoryDetails(linearId)
//        System.out.println("comment history:" + comments)
//        System.out.println("comment history size:" + comments.size)
        var commentLinearId: String = ""
        if (comments.size != 0)
            commentLinearId = comments.get(0).state.data.commentDetails.commentLinearId
        val commentDetailsModel = CommentModel(
                mappedToLinearId = commentReq.mappedToLinearId,
                commentLinearId = commentLinearId,
                comment = commentReq.comment,
                fromEmailId = commentReq.fromEmailId,
                toEmailId = commentReq.toEmailId,
                isInternal = commentReq.isInternal,
                level = commentReq.level
        )
        if (comments.size == 0) {
            signTxn = proxy.startFlow(::AddCommentFlow, commentDetailsModel).returnValue.getOrThrow()
        }
        else {
            signTxn = proxy.startFlow(::UpdateCommentFlow, commentDetailsModel).returnValue.getOrThrow()
        }

        val commentsHistory = ClientQueryService(proxy).customQueryCommentsHistoryDetails(linearId)
        val commentHistoryList = mutableListOf<CommentHistory>()
        if (commentsHistory.size > 0) {
            for (item in commentsHistory) {
                if (item.state.data.commentDetails.comment.isNotEmpty() || item.state.data.commentDetails.comment != "") {
                    var tempState = CommentHistory(
                            comment = item.state.data.commentDetails.comment,
                            fromEmailId = item.state.data.commentDetails.fromEmailId,
                            toEmailId = item.state.data.commentDetails.toEmailId
                    )
                    commentHistoryList.add(tempState)
                }
            }
        }
        val commentState = signTxn.coreTransaction.outputsOfType<CommentState>().get(0).commentDetails //signTxn.coreTransaction.outputsOfType<CommentState>().single().commentDetails //.get(0).commentDetails // .checklistItemDetails
        val message = CommentNotification(
                fromEmailId = commentState.fromEmailId,
                toEmailId = commentState.toEmailId,
                modifiedTime = commentState.modifiedDateTime,
                comment = commentState.comment,
                mappedToLinearId = commentState.mappedToLinearId,
                level = commentState.level,
                isInternal = commentState.isInternal,
                count = if (commentState.level == "CHECKLISTITEM")
                    commentHistoryList.size
                else
                    0
        )
        template?.convertAndSendToUser("user","/comment", message)
        return ResponseEntity.ok(message)
    }

    @GetMapping(value = ["getHistoryOfComments/{linearId}"], produces = arrayOf("application/JSON"))
    fun getHistoryOfComments(@PathVariable linearId: String): ResponseEntity<List<CommentHistory>> {
        logger.info("GET HISTORY OF COMMENTS ---   Initiated for LinearId: "+linearId)
        val details = ClientQueryService(proxy).customQueryCommentsHistoryDetails(linearId)
        val commentHistoryList = mutableListOf<CommentHistory>()

        for (obj in details) {
            if (obj.state.data.commentDetails.comment.isNotEmpty() || obj.state.data.commentDetails.comment != "") {
                var tempState = CommentHistory(
                        fromEmailId = obj.state.data.commentDetails.fromEmailId,
                        toEmailId = obj.state.data.commentDetails.toEmailId,
                        comment = obj.state.data.commentDetails.comment,
                        date = obj.state.data.commentDetails.modifiedDateTime,
                        isInternal = obj.state.data.commentDetails.isInternal,
                        level = obj.state.data.commentDetails.level
                )
                commentHistoryList.add(tempState)
            }
        }
        return ResponseEntity.ok(commentHistoryList)
    }

 @GetMapping(value = ["getListOfProjectByUser"], produces = ["application/json"])
    fun getListOfProjectByUser(@RequestHeader(value = "belongsTo") belongsTo : String,
                               @RequestHeader(value = "emailId") emailId : String,
                               @RequestHeader(value = "roleName") roleName : String): ResponseEntity<List<UserRoleInProjectModel>>{
     logger.info("GET LIST OF PROJECT BY USER ---   Initiated for user: "+emailId)
        val projectLinearIdList = mutableListOf<String>()
        var projectDetailsState = mutableListOf<ProjectDetails>()
        val userRoleInProjectList = mutableListOf<UserRoleInProjectModel>()
        val allProjectUserDetails = ClientQueryService(proxy).queryAllProjectUsers()
        val mapOfProjectUsers = allProjectUserDetails.map { it.state.data.projectUsersDetails }
        if(mapOfProjectUsers.size > 0) {
            mapOfProjectUsers.forEach {
                if (it.userDetails.filter { it.emailId == emailId }.size > 0) {
                    projectLinearIdList.add(it.projectLinearId)
                }
            }
            if(projectLinearIdList.size > 0){
                val projectDetailsList = ClientQueryService(proxy).linearStateQueryProject(projectLinearIdList)
                if(projectDetailsList.size > 0) {
                    projectDetailsState = projectDetailsList.map { it.state.data.projectDetails }.toMutableList()
                    projectDetailsState.forEach {
                        val userRoleInProject = ClientQueryService(proxy).customQueryProjectUsersDetails(it.projectLinearId).get(0).state.data.projectUsersDetails.userDetails
                        val userRoles = userRoleInProject.filter { it.emailId == emailId }.get(0)
                        val userRoleinProject = UserRoleInProjectModel(
                                projectDetails = it,
                                userRoleInProject = userRoles.roleName
                        )
                        userRoleInProjectList.add(userRoleinProject)
                    }
                }
            }
        }else
            projectDetailsState = emptyList<ProjectDetails>().toMutableList()
        return ResponseEntity.ok(userRoleInProjectList)
    }

    @GetMapping(value = ["getTaskSummary"], produces = ["application/json"])
    private fun getTaskSummary(@RequestHeader(value = "belongsTo") belongsTo : String,
                               @RequestHeader(value = "emailId") emailId : String,
                               @RequestHeader(value = "roleName") roleName : String) : ResponseEntity<List<TaskSummary>>{
        logger.info("GET TASK SUMMARY ---   Initiated for user: "+emailId)
        val packages = getListOfProjectByUser(belongsTo,emailId,roleName).body
        val projectLinearIdList = mutableListOf<String>()
        if(packages.size > 0) {
            packages.forEach {
                projectLinearIdList.add(it.projectDetails.projectLinearId)
            }
        }
        logger.info("GET TASK SUMMARY ---   all Package LinearIds: "+projectLinearIdList)
        val packageDetails = mutableListOf<StateAndRef<AcceptancePackageState>>()
        for ( i in projectLinearIdList) {
            val temp = ClientQueryService(proxy).customQueryPackageDetails(i)
            packageDetails.addAll(temp)
        }
//        val packageDetails = ClientQueryService(proxy).customQueryPackageDetailsList(projectLinearIdList)
        var userPackageDetails = packageDetails.filter { it.state.data.packageDetails.ericssonApprovers.any { it.emailId.equals(emailId) } }
        var contributorsPackageDetails = packageDetails.filter { it.state.data.packageDetails.ericssonContributor.any { it.emailId.equals(emailId) } }
        if (userPackageDetails.size == 0)
            userPackageDetails = packageDetails.filter { it.state.data.packageDetails.customerApprovers.any { it.emailId.equals(emailId) } }
        val taskList = mutableListOf<TaskSummary>()
        var tempState : TaskSummary = TaskSummary()
        for (obj in userPackageDetails) {
            if (obj.state.data.packageDetails.internalApprovalCompleted)
            {
                for ( j in obj.state.data.packageDetails.customerApprovers) {
                    tempState = TaskSummary(
                            emailId = emailId,
                            taskType = "Acceptance Package",
                            taskName = obj.state.data.packageDetails.packageName,
                            status = j.overallUserApprovalStatus,
                            dueDate = j.dueDate,
                            slaStart = j.slaStart,
                            noOfRemainders = j.noOfRemainders,
                            projectLinearId = obj.state.data.packageDetails.projectLinearId,
                            packageLinearId = obj.state.data.packageDetails.packageLinearId
                    )
                    taskList.add(tempState)
                }

            } else
            {
                for ( j in obj.state.data.packageDetails.ericssonApprovers) {
                    tempState = TaskSummary(
                            emailId = emailId,
                            taskType = "Acceptance Package",
                            taskName = obj.state.data.packageDetails.packageName,
                            status = j.overallUserApprovalStatus,
                            dueDate = j.dueDate,
                            slaStart = j.slaStart,
                            noOfRemainders = j.noOfRemainders,
                            projectLinearId = obj.state.data.packageDetails.projectLinearId,
                            packageLinearId = obj.state.data.packageDetails.packageLinearId
                    )
                    taskList.add(tempState)
                }

            }
        }
        val allProjectUserDetails = ClientQueryService(proxy).queryAllProjectUsers()
        val allChecklistDetails = mutableListOf<StateAndRef<ChecklistDetailsState>>()
        val mapOfProjectUsers = allProjectUserDetails.map { it.state.data.projectUsersDetails }
        mapOfProjectUsers.forEach {
            if (it.userDetails.filter { it.emailId == emailId && it.roleName == "CONTRIBUTOR" }.size > 0) {
//                val allChecklistDetails = ClientQueryService(proxy).customQueryChecklistDetailsList(projectLinearIdList)
                for (i in projectLinearIdList){
                    val tempChecklist = ClientQueryService(proxy).customQueryChecklistDetails(i)
                    allChecklistDetails.addAll(tempChecklist)
                }
                val executedChecklists = allChecklistDetails.filter { it.state.data.checklistDetails.submittedToExecutionTool }
                for (obj in executedChecklists) {
                    tempState = TaskSummary(
                            emailId = emailId,
                            taskType = "Execution",
                            taskName = obj.state.data.checklistDetails.checklistName,
                            status = obj.state.data.checklistDetails.checklistApprovalStatus,
                            dueDate = obj.state.data.checklistDetails.modifiedTime,
                            slaStart = false,
                            noOfRemainders = 0,
                            projectLinearId = obj.state.data.checklistDetails.projectLinearId,
                            siteId = obj.state.data.checklistDetails.siteId
                    )
                    taskList.add(tempState)
                }
                for (obj in contributorsPackageDetails) {
                    if ( obj.state.data.packageDetails.overallPackageApprovalStatus.equals("INTERNALLY APPROVED") || obj.state.data.packageDetails.overallPackageApprovalStatus.equals("APPROVED") || obj.state.data.packageDetails.overallPackageApprovalStatus.equals("REJECTED")) {
                        tempState = TaskSummary(
                                emailId = emailId,
                                taskType = "Acceptance Package",
                                taskName = obj.state.data.packageDetails.packageName,
                                status = obj.state.data.packageDetails.overallPackageApprovalStatus,
                                projectLinearId = obj.state.data.packageDetails.projectLinearId,
                                packageLinearId = obj.state.data.packageDetails.packageLinearId
                        )
                        taskList.add(tempState)
                    }
                }
            }
        }
        return ResponseEntity.ok(taskList)
    }

    @GetMapping(value = ["getProjectTreeStructure/{projectLinearId}"], produces = ["application/json"])
    fun getProjectTreeStructure(@PathVariable projectLinearId: String,
                                @RequestHeader(value = "belongsTo") belongsTo: String,
                                @RequestHeader(value = "emailId") emailId: String,
                                @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ProjectTree> {
        logger.info("GET PROJECT TREE STRUCTURE   ---   Initiated for LinearId: "+projectLinearId)
        var projectTree = ProjectTree()
        if(belongsTo == "ERICSSON") {
            val response = get(OFF_CHAIN_WEB_URL + "/getProjectStructure/" + projectLinearId, headers = mapOf("Content-Type" to "application/json"))
            logger.info("GET PROJECT TREE STRUCTURE   ---   Response json array: "+response.jsonArray.getJSONObject(0).getJSONObject("data"))
//            System.out.println(response.jsonArray.getJSONObject(0).getJSONObject("data"))
            projectTree = Gson().fromJson(response.jsonArray.getJSONObject(0).getJSONObject("data").toString(), ProjectTree::class.java)
        }
        else {
            val projectDetails = ClientQueryService(proxy).linearStateQueryProject(listOf(projectLinearId))
            val mappedProjectItems = ClientQueryService(proxy).customQueryAllPackageByProjectId(projectLinearId = projectLinearId )
            if(mappedProjectItems.size <= 0){
                throw Exception("GET PROJECT TREE STRUCTURE   ---  No Package details mapped for the provided Project Linear Id")
            }
            val listOfItems = mappedProjectItems.map { it.state.data.approverStatusDetails }
            val listOfWorkplan = listOfItems.filter { it.mappedItemLevel == "WORKPLAN" }

            val workplanTree = APIUtils.processPackageWorkplan(listOfWorkplan.toMutableList(), listOfItems.toMutableList())
            val wpGroupBySite = workplanTree.groupBy { it.siteId }
            val workplanBySite = mutableListOf<WorkplanBySite>()
            for((k,v) in wpGroupBySite){
                val wpBySite = WorkplanBySite(
                        siteId = k,
                        siteName = v.get(0).siteName,
                        workplanDetails = v
                )
                workplanBySite.add(wpBySite)
            }
            projectTree = ProjectTree(
                    projectLinearId = projectDetails.get(0).state.data.projectDetails.projectLinearId,
                    workplanBySite = workplanBySite,
                    projectId = projectDetails.get(0).state.data.projectDetails.projectId,
                    projectName = projectDetails.get(0).state.data.projectDetails.projectName
            )
        }
        return ResponseEntity.ok(projectTree)
    }

    @GetMapping(value = ["getTreeBySiteId/{projectLinearId}/{siteId}"], produces = ["application/json"])
    fun getTreeBySiteId(@PathVariable projectLinearId: String,
                        @PathVariable siteId: String,
                        @RequestHeader(value = "belongsTo") belongsTo: String,
                        @RequestHeader(value = "emailId") emailId: String,
                        @RequestHeader(value = "roleName") roleName: String): ResponseEntity<WorkplanBySite> {
        logger.info("GET TREE BY SITE ID   ---   Initiated for Site: "+siteId+" of project: "+projectLinearId)
        if(belongsTo == "ERICSSON") {
            val projectTree = getProjectTreeStructure(projectLinearId, belongsTo, emailId, roleName)
            val workplansBySite = projectTree.body.workplanBySite.filter { it.siteId == siteId }
            val checklistLinearIdsBySite = mutableListOf<String>()
            thread{
                workplansBySite.forEach {
                    it.workplanDetails.forEach {
                        it.workplanChecklist.forEach {
                            checklistLinearIdsBySite.addAll(ClientQueryService(proxy).linearStateQueryChecklist(listOf(it.checklistLinearId)).map { it.state.data.checklistDetails }.filter { it.submittedToExecutionTool == true }.map{it.checklistLinearId})
                        }
                        it.activities.forEach {
                            it.activityChecklist.forEach {
                                checklistLinearIdsBySite.addAll(ClientQueryService(proxy).linearStateQueryChecklist(listOf(it.checklistLinearId)).map { it.state.data.checklistDetails }.filter { it.submittedToExecutionTool == true }.map{it.checklistLinearId})
                            }
                        }
                        it.milestones.forEach {
                            it.milestoneChecklist.forEach {
                                checklistLinearIdsBySite.addAll(ClientQueryService(proxy).linearStateQueryChecklist(listOf(it.checklistLinearId)).map { it.state.data.checklistDetails }.filter { it.submittedToExecutionTool == true }.map{it.checklistLinearId})
                            }
                        }
                    }
                }
                logger.info("GET TREE BY SITE ID   ---   All checklist linearIds "+checklistLinearIdsBySite)
//                System.out.println("ChecklistLinearIdSize:"+checklistLinearIdsBySite)
                if(checklistLinearIdsBySite.size > 0)
                    APIUtils.getRADetails(checklistLinearIdsBySite, proxy)
            }
            return ResponseEntity.ok(workplansBySite.get(0))
        }else{
            val mappedProjectItems = ClientQueryService(proxy).customQueryAllPackageByProjectId(projectLinearId = projectLinearId )
            if(mappedProjectItems.size <= 0){
                throw Exception("GET TREE BY SITE ID   ---   No Package details mapped for the provided Project Linear Id")
            }
            val listOfItems = mappedProjectItems.map { it.state.data.approverStatusDetails }
            val listOfWorkplan = listOfItems.filter { it.mappedItemLevel == "WORKPLAN" }.filter { it.siteId == siteId }
            val workplanTree = APIUtils.processPackageWorkplan(listOfWorkplan.toMutableList(), listOfItems.toMutableList())
            val wpGroupBySite = workplanTree.groupBy { it.siteId }
            val workplanBySite = mutableListOf<WorkplanBySite>()
            for((k,v) in wpGroupBySite){
                val wpBySite = WorkplanBySite(
                        siteId = k,
                        siteName = v.get(0).siteName,
                        workplanDetails = v
                )
                workplanBySite.add(wpBySite)
            }
            return ResponseEntity.ok(workplanBySite.get(0))
        }
    }

    @GetMapping(value = ["getSiteDetailsBySiteId/{siteId}"], produces = ["application/json"])
    private fun getSiteDetailsBySiteId(@PathVariable siteId: String): ResponseEntity<FullSiteDetails> {
        logger.info("GET SITE DETAILS BY SITE ID   ---   Initiated for Site: "+siteId)
        return ResponseEntity.ok(getSiteDetailsFromErisite(siteId))
    }

    @GetMapping(value = ["getAcceptancePackageList/{projectLinearId}"], produces = ["application/json"])
    fun getAcceptancePackageList(@PathVariable projectLinearId: String,
                                 @RequestHeader(value = "belongsTo") belongsTo: String,
                                 @RequestHeader(value = "emailId") emailId: String,
                                 @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<AcceptancePackageList>> {
        logger.info("GET ACCEPTANCE PACKAGE LIST   ---   Initiated for Project: "+projectLinearId)
        val acceptancePackage = ClientQueryService(proxy).customQueryPackageDetails(projectLinearId).map { it.state.data.packageDetails }
        logger.info("GET ACCEPTANCE PACKAGE LIST   ---   Package details: "+acceptancePackage)
//        System.out.println("acceptance package:"+ acceptancePackage)
        var AcceptanceList = mutableListOf<AcceptancePackageList>()
        for (i in acceptancePackage) {
            var tempState = AcceptancePackageList(
                    packageName = i.packageName,
                    packageLinearId = i.packageLinearId,
                    status = i.overallPackageApprovalStatus,
                    typeOfAcceptance = i.typeOfAcceptance,
                    dateOfApproval = Instant.now(),
                    dateOfSubmission = i.dateOfSubmission
            )
            AcceptanceList.add(tempState)
        }
        return ResponseEntity.ok(AcceptanceList)
    }

    @GetMapping(value = ["getAcceptancePackageHistory/{packageLinearId}"], produces = ["application/json"])
    fun getAcceptancePackageHistory(@PathVariable packageLinearId: String,
                                    @RequestHeader(value = "belongsTo") belongsTo: String,
                                    @RequestHeader(value = "emailId") emailId: String,
                                    @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<AcceptancePackageHistory>> {
        logger.info("GET ACCEPTANCE PACKAGE HISTORY   ---   Initiated for Package: "+packageLinearId)
        val approverStatusDetails = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }
        logger.info("GET ACCEPTANCE PACKAGE HISTORY   ---   Package components: "+approverStatusDetails)
        System.out.println("approverStatusDetails :"+ approverStatusDetails)
        var AcceptanceList = mutableListOf<AcceptancePackageHistory>()
        for (i in approverStatusDetails) {
            var tempState = AcceptancePackageHistory(
                    itemCategory = i.mappedItemLevel,
                    itemName = i.mappedItemName,
                    itemOverallStatus = i.overallApprovalStatus,
                    siteName = i.siteName,
                    approvers = i.approverStatus
            )
            AcceptanceList.add(tempState)
        }
        return ResponseEntity.ok(AcceptanceList)
    }

    @GetMapping(value = ["getAllProjects"], produces = ["application/json"])
    private fun getAllProjects(): ResponseEntity<List<ProjectDetails>>{
        logger.info("GET ALL PROJECTS   ---   Initiated")
        val details = ClientQueryService(proxy).queryAllProject()
        val projectDetails = details.map { it.state.data.projectDetails }
        return ResponseEntity.ok(projectDetails)
    }

    @GetMapping(value = ["getActivityDetailsByLinearId/{activityLinearId}"], produces = ["application/json"])
    private fun getActivityByLinearId(@PathVariable activityLinearId: String): ResponseEntity<ActivityDetailsModel> {
        logger.info("GET ACTIVITY DETAILS BY LINEAR ID   ---   Initiated for activity: "+activityLinearId)
        val details = ClientQueryService(proxy).linearStateQueryActivity(listOf(activityLinearId))
        //System.out.println(details)
        //System.out.println(details)
        logger.info("GET ACTIVITY DETAILS BY LINEAR ID   ---   Activity details found? size : "+details.size)
        if (details.size != 1)
            throw Exception("GET ACTIVITY DETAILS BY LINEAR ID   ---   Invalid Id provided")
        val activityDetails = details.map { it.state.data.activityDetails }
        return ResponseEntity.ok(activityDetails.get(0))
    }

    @GetMapping(value = ["getWorkplanByLinearId/{workplanLinearId}"], produces = ["application/json"])
    private fun getWorkplanByLinearId(@PathVariable workplanLinearId: String): ResponseEntity<WorkplanDetails> {
        logger.info("GET WORKPLAN DETAILS BY LINEAR ID   ---   Initiated for workplan: "+workplanLinearId)
        val details = ClientQueryService(proxy).linearStateQueryWorkplan(listOf(workplanLinearId))
        logger.info("GET WORKPLAN DETAILS BY LINEAR ID   ---   workplan details found? size : "+details.size)
        if (details.size != 1)
            throw Exception("GET WORKPLAN DETAILS BY LINEAR ID  Invalid Id provided")
        val workPlanDetails = details.map { it.state.data.workplanDetails }
        return ResponseEntity.ok(workPlanDetails.single())
    }

    @GetMapping(value = ["getMilestoneDetailsByLinearId/{milestoneLinearId}"], produces = ["application/json"])
    private fun getMilestoneDetailsByLinearId(@PathVariable milestoneLinearId: String): ResponseEntity<MilestoneDetails> {
        logger.info("GET MILESTONE DETAILS BY LINEAR ID   ---   Initiated for milestone: "+milestoneLinearId)
        val details = ClientQueryService(proxy).linearStateQueryMilestone(listOf(milestoneLinearId))
        logger.info("GET MILESTONE DETAILS BY LINEAR ID   ---   Milestone details found? size : "+details.size)
        if (details.size != 1)
            throw Exception("GET MILESTONE DETAILS BY LINEAR ID   ---   Invalid Id Provided")
        val milestoneDetails = details.map { it.state.data.milestoneDetails }
        return ResponseEntity.ok(milestoneDetails.get(0))
    }

    @PostMapping("importChecklist/{mappedToLinearId}/{checklistName}/{internal}")
    fun importChecklist(@RequestParam("uploadfile") file: MultipartFile,@PathVariable mappedToLinearId: String,@PathVariable checklistName: String,@PathVariable internal: Boolean,
                        @RequestHeader(value = "belongsTo") belongsTo : String,
                        @RequestHeader(value = "emailId") emailId : String,
                        @RequestHeader(value = "roleName") roleName : String): ResponseEntity<ChecklistDetails> {
        logger.info("IMPORT CHECKLIST   ---   Initiated for LinearId: "+mappedToLinearId)
        val details1 = ClientQueryService(proxy).linearStateQueryWorkplan(listOf(mappedToLinearId))
        val details2 = ClientQueryService(proxy).linearStateQueryMilestone(listOf(mappedToLinearId))
        val details3 = ClientQueryService(proxy).customQueryActivityDetailsByActivityLinearId(mappedToLinearId)
        var projectLinearId = ""
        var projectId = ""
        var workplanId = ""
        var workplanLinearId = ""
        var siteId = ""
        var siteName  = ""
        logger.info("IMPORT CHECKLIST   ---   Workplan: "+details1.size)
        logger.info("IMPORT CHECKLIST   ---   Milestone: "+details2.size)
        logger.info("IMPORT CHECKLIST   ---   Activity: "+details3.size)
        if(details1.size >0){
            projectLinearId = details1.get(0).state.data.workplanDetails.mappedToLinearId
            projectId = details1.get(0).state.data.workplanDetails.projectId
            workplanId = details1.get(0).state.data.workplanDetails.workplanId
            workplanLinearId = details1.get(0).state.data.workplanDetails.workplanLinearId
            siteId = details1.get(0).state.data.workplanDetails.siteId
            siteName = details1.get(0).state.data.workplanDetails.siteName
        }else if(details2.size > 0){
            projectLinearId = details2.get(0).state.data.milestoneDetails.projectLinearId
            projectId = details2.get(0).state.data.milestoneDetails.projectId
            workplanId = details2.get(0).state.data.milestoneDetails.workplanId
            workplanLinearId = details2.get(0).state.data.milestoneDetails.workplanLinearId
            siteId = details2.get(0).state.data.milestoneDetails.siteId
            siteName = details2.get(0).state.data.milestoneDetails.siteName
        }else{
            projectLinearId = details3.get(0).state.data.activityDetails.projectLinearId
            projectId = details3.get(0).state.data.activityDetails.projectId
            workplanId = details3.get(0).state.data.activityDetails.workplanId
            workplanLinearId = details3.get(0).state.data.activityDetails.workplanLinearId
            siteId = details3.get(0).state.data.activityDetails.siteId
            siteName = details3.get(0).state.data.activityDetails.siteName
        }
        val checklistItemsList = mutableListOf<ChecklistItem>()
        var xlWb = WorkbookFactory.create(file.getInputStream())
        val checklistModel = ChecklistDetails(
                checklistId = checkForNull(checklistName).toString(),
                checklistLinearId = "",
                checklistName = checkForNull(checklistName).toString(),
                checklistStatus = "DRAFT",
                mappedToLinearId = mappedToLinearId,
                projectLinearId = projectLinearId,
                projectId = projectId ,
                workplanId = workplanId,
                workplanLinearId = workplanLinearId ,
                checklistType = "HARMONIA",
                modifiedTime = Instant.now(),
                siteId = siteId,
                siteName = siteName,
                checklistApprovalStatus = "PENDING",
                isInternal = internal
        )
        val checklistSignTxn = proxy.startFlow(::ChecklistDetailsFlow, checklistModel).returnValue.getOrThrow()
        //Row index specifies the row in the worksheet (starting at 0):
        val rowNumber = 0
        //Cell index specifies the column within the chosen row (starting at 0):
        val columnNumber = 0
        //Get reference to first sheet:
        val xlWs = xlWb.getSheetAt(0)
        // var cell5 String;
//        System.out.println("------------------")
        logger.info("IMPORT CHECKLIST   ---   Workbook: "+xlWb.numberOfSheets)
//        System.out.println(xlWb.numberOfSheets)
        for(i in 1..xlWb.numberOfSheets) {
            val categoryDetails = ChecklistCategory(
                    checklistCategoryLinearId = "",
                    checklistCategoryStatus = "DRAFT",
                    checklistCategoryName =  checkForNull(xlWb.getSheetName(i-1)).toString(),
                    checklistCategoryApprovalStatus = APPROVAL_STATUS.PENDING.toString(),
                    mappedToLinearId = checklistSignTxn.coreTransaction.outputsOfType<ChecklistDetailsState>().single().checklistDetails.checklistLinearId
            )
            val categorySignTxn = proxy.startFlow(::ChecklistCategoryDetailsFlow, mutableListOf(categoryDetails)).returnValue.getOrThrow()
            val categoryLinearId = categorySignTxn.coreTransaction.outputsOfType<ChecklistCategoryDetailsState>().single().linearId
            for (j in 1..xlWb.getSheetAt(i-1).getPhysicalNumberOfRows() - 1) {
                System.out.println(xlWb.getSheetAt(i-1).getRow(j).getCell(0))
                val checklistItems = ChecklistItem(
                        itemLinearId  = "",
                        itemId  = checkForNull(xlWb.getSheetAt(i-1).getRow(j).getCell(0)).toString(),
                        itemDescription  = checkForNull(xlWb.getSheetAt(i-1).getRow(j).getCell(1)).toString(),
                        criteria = checkForNull(xlWb.getSheetAt(i-1).getRow(j).getCell(2)).toString(),
                        executionStatus = checkForNull(xlWb.getSheetAt(i-1).getRow(j).getCell(3)).toString(),
                        mappedToLinearId = categoryLinearId.toString()
//                        comment = checkForNull(xlWb.getSheetAt(i-1).getRow(j).getCell(4)).toString()
                )
                checklistItemsList.add(checklistItems)
            }
        }
        val itemSignTxn = proxy.startFlow(::ChecklistItemDetailsFlow, checklistItemsList).returnValue.getOrThrow()
        updateProjectStructure(checklistSignTxn.coreTransaction.outputsOfType<ChecklistDetailsState>().single().checklistDetails.checklistLinearId,mappedToLinearId)
        return ResponseEntity.ok(checklistSignTxn.coreTransaction.outputsOfType<ChecklistDetailsState>().single().checklistDetails)
    }

    @PostMapping(value = ["createCheckListItem"], produces = ["application/json"], consumes = ["application/json"])
    private fun createCheckListItem(@RequestBody checkListItem : ChecklistItemInput,
                                    @RequestHeader(value = "belongsTo") belongsTo: String,
                                    @RequestHeader(value = "emailId") emailId: String,
                                    @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ChecklistItem> {
        try {
            logger.info("CREATE CHECKLIST ITEM   ---   Initiated for Category LinearId: "+checkListItem.categoryLinearId)
            val checklistItems = ChecklistItem(
                    itemLinearId  = "",
                    itemId  = "" ,
                    itemDescription  = checkListItem.itemDescription,
                    criteria = checkListItem.criteria,
                    mappedToLinearId = checkListItem.categoryLinearId
            )
            val itemSignTxn = proxy.startFlow(::ChecklistItemDetailsFlow, mutableListOf(checklistItems)).returnValue.getOrThrow()
            return ResponseEntity.ok(itemSignTxn.coreTransaction.outputsOfType<ChecklistItemDetailsState>().single().checklistItemDetails)
            //return ResponseEntity.accepted().body(signtxn.coreTransaction.outputsOfType<AcceptancePackageState>().single().packageDetails)
        }catch(e : Exception){
            throw e
        }
    }

    @PostMapping(value = ["updateCheckListItem"], produces = ["application/json"], consumes = ["application/json"])
    private fun updateCheckListItem(@RequestBody checkListItem : UpdateChecklistItem,
                                    @RequestHeader(value = "belongsTo") belongsTo: String,
                                    @RequestHeader(value = "emailId") emailId: String,
                                    @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ChecklistItem> {
        try {
            logger.info("UPDATE CHECKLIST ITEM   ---   Initiated for LinearId: "+checkListItem.itemLinearId)
            val itemSignTxn = proxy.startFlow(::UpdateChecklistItemDetailsFlow, checkListItem).returnValue.getOrThrow()
            return ResponseEntity.ok(itemSignTxn.coreTransaction.outputsOfType<ChecklistItemDetailsState>().single().checklistItemDetails)
        }catch(e : Exception){
            throw e
        }
    }


    @GetMapping(value = ["getCategoriesByChecklistLinearId/{checklistLinearId}"], produces = ["application/json"])
    private fun getCategoriesByChecklistLinearId(@PathVariable checklistLinearId : String,
                                                 @RequestHeader(value = "belongsTo") belongsTo: String,
                                                 @RequestHeader(value = "emailId") emailId: String,
                                                 @RequestHeader(value = "roleName") roleName: String)  : ResponseEntity<List<ChecklistCategory>> {
        logger.info("GET CATEGORIES BY CHECKLIST LINEARID   ---   Initiated for Checklist: "+checklistLinearId)
        val checklistDetailsRef = ClientQueryService(proxy).customQueryChecklistCategory(checklistLinearId)
        return ResponseEntity.ok(checklistDetailsRef.map { it.state.data.checklistCategoryDetails })
    }

    @GetMapping(value = ["getChecklistDetailsByLinearId/{checklistLinearId}"], produces = ["application/json"])
    private fun getChecklistDetailsByLinearId(@PathVariable checklistLinearId : String,
                                                 @RequestHeader(value = "belongsTo") belongsTo: String,
                                                 @RequestHeader(value = "emailId") emailId: String,
                                                 @RequestHeader(value = "roleName") roleName: String)  : ResponseEntity<ChecklistDetails> {
        logger.info("GET CHECKLIST DETAILS BY LINEARID   ---   Initiated for Checklist: "+checklistLinearId)
        val checklistDetailsRef = ClientQueryService(proxy).linearStateQueryChecklist(listOf(checklistLinearId))
        return ResponseEntity.ok(checklistDetailsRef.map { it.state.data.checklistDetails }.get(0))
    }


    @GetMapping(value = ["getItemsByCategoryLinearId/{categoryLinearId}"], produces = ["application/json"])
    private fun getItemsByCategoryLinearId(@PathVariable categoryLinearId : String,
                                           @RequestHeader(value = "belongsTo") belongsTo: String,
                                           @RequestHeader(value = "emailId") emailId: String,
                                           @RequestHeader(value = "roleName") roleName: String)  : ResponseEntity<List<ChecklistItem>> {
        logger.info("GET ITEMS BY CATEGORY LINEARID   ---   Initiated for Category: "+categoryLinearId)
        val checklistDetailsRef = ClientQueryService(proxy).customQueryChecklistItemDetailsByCategory(categoryLinearId)
        val checklists = mutableListOf<ChecklistItem>()
        checklistDetailsRef.forEach {
            val temp = ChecklistItem(
                    itemLinearId = it.state.data.checklistItemDetails.itemLinearId,
                    mappedToLinearId = it.state.data.checklistItemDetails.mappedToLinearId,
                    itemId = it.state.data.checklistItemDetails.itemId,
                    criteria = it.state.data.checklistItemDetails.criteria,
                    itemDescription = it.state.data.checklistItemDetails.itemDescription,
                    executionStatus = it.state.data.checklistItemDetails.executionStatus,
                    commentCount = getHistoryOfComments(it.state.data.checklistItemDetails.itemLinearId).body.map { it }.size,
                    itemApprovalStatus = it.state.data.checklistItemDetails.itemApprovalStatus,
                    itemProof = it.state.data.checklistItemDetails.itemProof,
                    levelName = it.state.data.checklistItemDetails.levelName
            )
            checklists.add(temp)
        }
        return ResponseEntity.ok(checklists.toList())
    }

    @PostMapping(value = ["updateChecklistForRejection "], produces = ["application/json"], consumes = ["application/json"])
    private fun updateChecklistForRejection (@RequestBody checkListItems : List<String>,
                                             @RequestHeader(value = "belongsTo") belongsTo: String,
                                             @RequestHeader(value = "emailId") emailId: String,
                                             @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ChecklistItem> {
        try {
            logger.info("UPDATE CHECKLIST FOR REJECTION   ---   Initiated for checklists: "+checkListItems)
            val itemSignTxn = proxy.startFlow(::UpdateChecklistItemDetailStatusFlow, checkListItems).returnValue.getOrThrow()
            return ResponseEntity.ok(itemSignTxn.coreTransaction.outputsOfType<ChecklistItemDetailsState>().single().checklistItemDetails)
        }catch(e : Exception){
            throw e
        }
    }

    @PostMapping(value = ["submitChecklistToRA"])
    fun submitChecklistToRA(@RequestBody checkListSession : RA_Session) : ResponseEntity<RAResponse>{
        logger.info("SUBMIT CHECKLIST TO RA   ---   Initiated for SSO linearId: "+checkListSession.ssoLinearId)
        val checkListItems = APIUtils.getRAChecklistItems(checkListSession.ssoLinearId, proxy);
//        val ra_payload = APIUtils.getRAHeader(checkListLinearId,checkListItems);
        val ra_payload = listOf(RA_Base(
                ssoLinearId = checkListSession.ssoLinearId,
                sessionId = checkListSession.sessionId,
                sessionStatus= checkListSession.sessionStatus,
                sessionName = checkListSession.sessionName,
                compiledURL = checkListSession.compiledURL,
                sessionType = checkListSession.sessionType,
                sessionHost = checkListSession.sessionHost,
                sessionGroup = checkListSession.sessionGroup,
                sessionAltHost = checkListSession.sessionAltHost,
                sessionParticipants = checkListSession.sessionParticipants,
                sessionEditors= checkListSession.sessionEditors,
                sessionGuests = checkListSession.sessionGuests,
                sessionCustomers = checkListSession.sessionCustomers,
                sessionCus = checkListSession.sessionCus,
                sessionSup = checkListSession.sessionSup,
                sessionStart = checkListSession.sessionStart,
                sessionEnd = checkListSession.sessionEnd,
                sessionProject = checkListSession.sessionProject,
                sessionSite = checkListSession.sessionSite,
                sessionLocation = checkListSession.sessionLocation,
                sessionCrewPhone= checkListSession.sessionCrewPhone,
                sessionCrewName = checkListSession.sessionCrewName,
                sessionCrewEmail = checkListSession.sessionCrewEmail,
                sessionScope = checkListSession.sessionScope,
                sessionESubj = checkListSession.sessionESubj,
                sessionEContent = checkListSession.sessionEContent,
                sessionComment = checkListSession.sessionComment,
                marketArea = checkListSession.marketArea,
                notify = checkListSession.notify,
                checklist = checkListItems
        ))
        val ra = post(API_RA_QA_POST_URL, headers=mapOf("Content-Type" to "application/json"), data= JSONArray(ra_payload), auth= BasicAuthorization(RA_USERNAME, RA_PASSWORD))
        logger.info("SUBMIT CHECKLIST TO RA   ---   RA response: "+ra)
//        System.out.println(ra)
        val response = RAResponse(
                RAResponseCode = ra.statusCode,
                message = ra.text,
                submittedToRA = if(ra.statusCode == 200)
                    true
                else
                    false
        )
        if(ra.statusCode == 200){
            val signTxn = proxy.startFlow(::UpdateChecklistFlow, checkListSession.ssoLinearId, true).returnValue.getOrThrow()
            val message = signTxn.coreTransaction.outputsOfType<ChecklistDetailsState>().get(0).checklistDetails
            template?.convertAndSendToUser("user","/submitChecklistNotification", message)
        }
        return ResponseEntity.ok(response)
    }

    @GetMapping(value = ["getSessionHistory/{checkListLinearId}"])
    fun getSessionHistory(@PathVariable checkListLinearId : String) : ResponseEntity<raResp> {
        logger.info("GET SESSION HISTORY   ---   Initiated for checklist: "+checkListLinearId)
        val url2 = API_RA_QA_GET_URL + listOf(checkListLinearId);
        val r1 = get(url2, headers = mapOf("Content-Type" to "application/json"),auth= BasicAuthorization(RA_USERNAME, RA_PASSWORD))
        val topic1 = Gson().fromJson(r1.jsonObject.toString(), raResp::class.java)
        return ResponseEntity.ok(topic1)
    }



    @GetMapping(value = ["getProjectEricssonApprovers/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectEricssonApprovers(@PathVariable projectLinearId : String,
                                            @RequestHeader(value = "belongsTo") belongsTo: String,
                                            @RequestHeader(value = "emailId") emailId: String,
                                            @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<UserDetails>>{
        logger.info("GET PROJECT ERICSSON APPROVER   ---   Initiated for project: "+projectLinearId)
        val projectUsers = ClientQueryService(proxy).customQueryProjectUsersDetails(projectLinearId)
        logger.info("GET PROJECT ERICSSON APPROVER   ---   Approvers found? size: "+projectUsers.size)
        if(projectUsers.size > 0){
            val ericApprovers = projectUsers.single().state.data.projectUsersDetails.userDetails.filter { it.belongsTo == "ERICSSON" && it.roleName == "APPROVER" }
            return ResponseEntity.ok(ericApprovers)
        }else
            return ResponseEntity.ok(emptyList())
    }

    @GetMapping(value = ["getProjectCustomerApprovers/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectCustomerApprovers(@PathVariable projectLinearId : String,
                                            @RequestHeader(value = "belongsTo") belongsTo: String,
                                            @RequestHeader(value = "emailId") emailId: String,
                                            @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<UserDetails>>{
        logger.info("GET PROJECT CUSTOMER APPROVER   ---   Initiated for project: "+projectLinearId)
        val projectUsers = ClientQueryService(proxy).customQueryProjectUsersDetails(projectLinearId)
        logger.info("GET PROJECT CUSTOMER APPROVER   ---   Approvers found? size: "+projectUsers.size)
        if(projectUsers.size > 0){
            val custApprovers = projectUsers.single().state.data.projectUsersDetails.userDetails.filter { it.belongsTo == "CUSTOMER" && it.roleName == "APPROVER" }
            return ResponseEntity.ok(custApprovers)
        }else
            return ResponseEntity.ok(emptyList())
    }

    @GetMapping(value = ["getProjectEricssonObservers/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectEricssonObservers(@PathVariable projectLinearId : String,
                                            @RequestHeader(value = "belongsTo") belongsTo: String,
                                            @RequestHeader(value = "emailId") emailId: String,
                                            @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<UserDetails>>{
        logger.info("GET PROJECT ERICSSON OBSERVERS   ---   Initiated for project: "+projectLinearId)
        val projectUsers = ClientQueryService(proxy).customQueryProjectUsersDetails(projectLinearId)
        logger.info("GET PROJECT ERICSSON OBSERVERS   ---   Observers found? size: "+projectUsers.size)
        if(projectUsers.size > 0){
            val ericObservers = projectUsers.single().state.data.projectUsersDetails.userDetails.filter { it.belongsTo == "ERICSSON" && it.roleName == "OBSERVER" }
            return ResponseEntity.ok(ericObservers)
        }else
            return ResponseEntity.ok(emptyList())
    }

    @GetMapping(value = ["getProjectCustomerObservers/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectCustomerObservers(@PathVariable projectLinearId : String,
                                            @RequestHeader(value = "belongsTo") belongsTo: String,
                                            @RequestHeader(value = "emailId") emailId: String,
                                            @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<UserDetails>>{
        logger.info("GET PROJECT CUSTOMER OBSERVERS   ---   Initiated for project: "+projectLinearId)
        val projectUsers = ClientQueryService(proxy).customQueryProjectUsersDetails(projectLinearId)
        logger.info("GET PROJECT CUSTOMER OBSERVERS   ---   Observers found? size: "+projectUsers.size)
        if(projectUsers.size > 0){
            val custObservers = projectUsers.single().state.data.projectUsersDetails.userDetails.filter { it.belongsTo == "CUSTOMER" && it.roleName == "OBSERVER" }
            return ResponseEntity.ok(custObservers)
        }else
            return ResponseEntity.ok(emptyList())
    }

    @PostMapping(value = ["updateVisibilityDetails"], consumes = ["application/json"])
    private fun updateVisibilityDetails(@RequestBody updateVisibility : UpdateVisibility,
                                        @RequestHeader(value = "belongsTo") belongsTo: String,
                                        @RequestHeader(value = "emailId") emailId: String,
                                        @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<UpdateVisibility>{
        try {
            logger.info("UPDATE VISIBILITY DETAILS   ---   Initiated for LinearId: "+updateVisibility.linearId)
            val signTxn = proxy.startFlow(::UpdateVisibilityFlow, updateVisibility).returnValue.getOrThrow()
            updateVisibility.isUpdateSuccess = true
            return ResponseEntity.ok(updateVisibility)
        }catch(e : Exception){
            throw e
        }
    }

    @GetMapping(value = ["getSiteAndStructureByLinearId/{projectLinearId}"], produces = ["application/json"])
    private fun getSiteAndStructureByLinearId (@PathVariable projectLinearId : String,
                                               @RequestHeader(value = "belongsTo") belongsTo: String,
                                               @RequestHeader(value = "emailId") emailId: String,
                                               @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<MutableList<SiteAndStructureDetails>>{
        logger.info("GET SITE AND STRUCTURE BY LINEARID   ---   Initiated for project: "+projectLinearId)
        val workplanDetails = ClientQueryService(proxy).customQueryWorkplanDetails(projectLinearId)
        val siteAStructureList = mutableListOf<SiteAndStructureDetails>()
        if(workplanDetails.size<=0)
            throw Exception("GET SITE AND STRUCTURE BY LINEARID   ---   No Workplans available for this ID")
        val workplans = workplanDetails.map { it.state.data.workplanDetails }
        for(i in 0..(workplans.size - 1)){
            val workplan = workplans.get(i)
            val temp = SiteAndStructureDetails(
                    siteId = workplan.siteId,
                    siteName = workplan.siteName,
                    systemGeography = workplan.systemGeography,
                    workplanLinearId = workplan.workplanLinearId,
                    workplanId = workplan.workplanId,
                    workplanName = workplan.workplanName,
                    workplanStatus = workplan.workplanStatus,
                    workplanActualEndDate = workplan.workplanActualEndDate,
                    workplanActualStartDate = workplan.workplanActualStartDate
            )
            siteAStructureList.add(temp)
        }
        return ResponseEntity.ok(siteAStructureList)
    }

    @GetMapping(value = ["getSiteListInProject/{projectLinearId}"], produces = ["application/json"])
    private fun getSiteListInProject (@PathVariable projectLinearId : String,
                                      @RequestHeader(value = "belongsTo") belongsTo: String,
                                      @RequestHeader(value = "emailId") emailId: String,
                                      @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<String>>{
        logger.info("GET SITE LIST IN PROJECT   ---   Initiated for project: "+projectLinearId)
        if(belongsTo == "ERICSSON") {
            val projectTree = getProjectTreeStructure(projectLinearId, belongsTo, emailId, roleName)
            val mapSite = projectTree.body.workplanBySite.map { it.siteId }
            return ResponseEntity.ok(mapSite)
        }else{
            val mappedProjectItems = ClientQueryService(proxy).customQueryAllPackageByProjectId(projectLinearId = projectLinearId )
            if(mappedProjectItems.size <= 0){
                throw Exception("GET SITE LIST IN PROJECT   ---   No Package details mapped for the provided Project Linear Id")
            }
            val listOfSite =mappedProjectItems.map { it.state.data.approverStatusDetails.siteId }.distinct()
            return ResponseEntity.ok(listOfSite)
        }
    }

    @PostMapping(value = ["createAcceptancePackage"], produces = ["application/json"], consumes = ["application/json"])
    private fun createAcceptancePackage(@RequestBody completePackageDetails : AcceptancePackageModel,
                                        @RequestHeader(value = "belongsTo") belongsTo: String,
                                        @RequestHeader(value = "emailId") emailId: String,
                                        @RequestHeader(value = "roleName") roleName: String): ResponseEntity<AcceptancePackageStatus> {
        try {
            logger.info("CREATE ACCEPTANCE PACKAGE   ---   Initiated for project: "+completePackageDetails.packageDetails.projectLinearId)
            val parts : List<String> = emailId.split('@')
            var firstName : String = ""
            var lastName : String = ""
            if (parts.size > 1) {
                var names : List<String> = parts[0].split('.')
                if (names.size > 0) {
                        firstName = names.get(0)
                        lastName = names.get(names.size-1)
                }
            }
            val contributor = PackageUsers(
                    emailId = emailId,
                    belongsTo = belongsTo,
                    roleName = roleName,
                    firstName = firstName,
                    lastName = lastName
            )
            /////////////////enhancement
//            completePackageDetails.packageDetails.ericssonContributor.add(contributor)
//            var listOfApproverStatus = mutableListOf<ApproverStatusDetails>()
//            var itemLevel = completePackageDetails.projectComponents.map { it.mappedItemLevel }
//            if  (itemLevel.contains("WORKPLAN")) {
//                val comp = completePackageDetails.projectComponents.filter { it.mappedItemLevel.equals("WORKPLAN") }
//                listOfApproverStatus.addAll(APIUtils.mapWorkplanDetailsOfPackageCreation(completePackageDetails.packageDetails.projectLinearId, proxy, comp))
//                completePackageDetails.projectComponents.addAll(listOfApproverStatus)
//            } else if (itemLevel.contains("ACTIVITY")) {
//                val comp = completePackageDetails.projectComponents.filter { it.mappedItemLevel.equals("ACTIVITY") }
//                listOfApproverStatus.addAll(APIUtils.mapActivityDetailsOfPackageCreation(completePackageDetails.packageDetails.projectLinearId, proxy, comp))
//                completePackageDetails.projectComponents.addAll(listOfApproverStatus)
//            } else if (itemLevel.contains("MILESTONE")) {
//                val comp = completePackageDetails.projectComponents.filter { it.mappedItemLevel.equals("MILESTONE") }
//                listOfApproverStatus.addAll(APIUtils.mapMilestoneDetailsOfPackageCreation(completePackageDetails.packageDetails.projectLinearId, proxy, comp))
//                completePackageDetails.projectComponents.addAll(listOfApproverStatus)
//            } else {
//                throw Exception("Invalid level name")
//            }
            completePackageDetails.packageDetails.ericssonContributor.add(contributor)
            val comp = completePackageDetails.projectComponents.filter { it.mappedItemLevel.equals("ACTIVITY") }
            val compMilestone = completePackageDetails.projectComponents.filter { it.mappedItemLevel.equals("MILESTONE") }
            var listOfApproverStatusActivity = mutableListOf<ApproverStatusDetails>()
            var listOfApproverStatusMilestone = mutableListOf<ApproverStatusDetails>()
            if (comp.size > 0) {
                listOfApproverStatusActivity.addAll(APIUtils.mapActivityDetailsOfPackageCreation(completePackageDetails.packageDetails.projectLinearId, proxy, comp))
                completePackageDetails.projectComponents.addAll(listOfApproverStatusActivity)
            }
            if (compMilestone.size >0) {
                listOfApproverStatusMilestone.addAll(APIUtils.mapMilestoneDetailsOfPackageCreation(completePackageDetails.packageDetails.projectLinearId, proxy, compMilestone))
                completePackageDetails.projectComponents.addAll(listOfApproverStatusMilestone)
            }
//            System.out.println("updated acceptance input==="+completePackageDetails)
            val signtxn = proxy.startFlow(::SubmitPackageInternalFlow, completePackageDetails.packageDetails).returnValue.getOrThrow()
            var packageResults = signtxn.coreTransaction.outputsOfType<AcceptancePackageState>().single().packageDetails
            logger.info("CREATE ACCEPTANCE PACKAGE   ---   SubmitPackageInternalFlow result: "+packageResults)
//            System.out.println("SubmitPackageInternalFlow result"+packageResults)
            val partyX500NamePartyCust : CordaX500Name
            partyX500NamePartyCust = CordaX500Name.parse("O=Customer A, L=New York, C=US")
            var approversList = mutableListOf<ApproverStatus>()
            val proposeToParty = proxy.wellKnownPartyFromX500Name(partyX500NamePartyCust)
                    ?: throw IllegalArgumentException("Target string \"$partyX500NamePartyCust\" doesn't match any nodes on the network.")
            for ( j in packageResults.ericssonApprovers) {
                var tempState = ApproverStatus (
                        approvedBy = j.emailId,
                        verdict = if (j.orderIndex == 1)
                            "AWAITING APPROVAL"
                        else
                            "TO BE INITIATED",
                        belongsTo = j.belongsTo
                )
//                System.out.println("tempstate"+tempState)
                approversList.add(tempState)
            }
            for ( j in packageResults.customerApprovers) {
                var tempState = ApproverStatus (
                        approvedBy = j.emailId,
                        verdict = "TO BE INITIATED",
                        belongsTo = j.belongsTo
                )
                approversList.add(tempState)
            }
            logger.info("CREATE ACCEPTANCE PACKAGE   ---   approver status: "+approversList)

            for ( i in completePackageDetails.projectComponents) {
                i.packageLinearId = packageResults.packageLinearId
                i.approverStatus = approversList
            }
            logger.info("CREATE ACCEPTANCE PACKAGE   ---   approver status: "+approversList)
            logger.info("CREATE ACCEPTANCE PACKAGE   ---   Post adding the children of components: "+completePackageDetails.projectComponents)
            var fullySignTxn = proxy.startFlow (::SubmitApproverStatusDetailsFlow, completePackageDetails.projectComponents.toMutableList()).returnValue.getOrThrow()
            logger.info("CREATE ACCEPTANCE PACKAGE   ---   SubmitApproverStatusDetailsFlow result: "+fullySignTxn.coreTransaction.outputsOfType<ApproverStatusDetailsState>())
            val packageStatus = AcceptancePackageStatus(
                    packageLinearId = packageResults.packageLinearId,
                    message = "Acceptance Package Successfully Submitted!"
            )

            val allApprovers = mutableListOf<PackageUsers>()
            val allObservers = mutableListOf<PackageUsers>()
            allApprovers.addAll(packageResults.ericssonApprovers)
            allApprovers.addAll(packageResults.customerApprovers)
            allObservers.addAll(packageResults.ericssonObservers)
            allObservers.addAll(packageResults.customerObservers)

            val projectDetails = ClientQueryService(proxy).customQueryProjectDetails(packageResults.projectLinearId).map { it.state.data.projectDetails }.get(0)

            allApprovers.forEach {
                sendEmail("ROLE",it.emailId,it.firstName,projectDetails.projectName,it.roleName,packageResults.projectLinearId,packageResults.packageName,packageResults.packageLinearId,"")
            }
            allObservers.forEach {
                sendEmail("ROLE",it.emailId,it.firstName,projectDetails.projectName,it.roleName,packageResults.projectLinearId,packageResults.packageName,packageResults.packageLinearId,"")
            }

            if (packageResults.ericssonPreserveOrder) {
                val firstApprover = packageResults.ericssonApprovers.sortedBy { it.orderIndex }.get(0)
                sendEmail("APPROVER", firstApprover.emailId, firstApprover.firstName, projectDetails.projectName, firstApprover.roleName, packageResults.projectLinearId, packageResults.packageName, packageResults.packageLinearId, "")
            } else {
                packageResults.ericssonApprovers.forEach {
                    sendEmail("APPROVER",it.emailId,it.firstName,projectDetails.projectName,it.roleName,packageResults.projectLinearId,packageResults.packageName,packageResults.packageLinearId,"")
                }
            }

            //TrackBy
            val criteria = QueryCriteria.VaultQueryCriteria(status = Vault.StateStatus.UNCONSUMED)
            val pageSpec = PageSpecification(pageNumber = DEFAULT_PAGE_NUM, pageSize = DEFAULT_PAGE_SIZE)
            val updates = proxy.vaultTrackByWithPagingSpec(AcceptancePackageState::class.java, paging = pageSpec, criteria = criteria).updates
            val approvers = mutableListOf<PackageUsers>()
            val notificationDetailsList = mutableListOf<SLANotification>()
            updates.asObservable().subscribe { update ->
                update.produced.forEach {
                    val currentState = it.state.data.packageDetails
                    val ericApprovers = it.state.data.packageDetails.ericssonApprovers.filter { it.slaStart == true && it.noOfRemainders > 0 && it.overallUserApprovalStatus == "AWAITING APPROVAL" }
                    val custApprovers = it.state.data.packageDetails.customerApprovers.filter { it.slaStart == true && it.noOfRemainders > 0 && it.overallUserApprovalStatus == "AWAITING APPROVAL" }
                    approvers.addAll(ericApprovers)
                    approvers.addAll(custApprovers)
                    approvers.forEach {
                        val slaNotification = SLANotification(
                                emailId = it.emailId,
                                packageLinearId = currentState.packageLinearId,
                                packageName = currentState.packageName,
                                projectId = currentState.projectId,
                                projectLinearId = currentState.projectLinearId,
                                dueDate = it.dueDate.toString(),
                                currentStatus = it.overallUserApprovalStatus,
                                noOfRemainders = it.noOfRemainders,
                                subject = ""
                        )
                        notificationDetailsList.add(slaNotification)
                    }
                    approvers.clear()
                    if (notificationDetailsList.size > 0) {
                        logger.info("CREATE ACCEPTANCE PACKAGE   ---   NotificationList Size: " + notificationDetailsList.size)
//                        System.out.println("Notification Details:" + notificationDetailsList)
//                        System.out.println("Notification:" + notificationDetailsList.get(0).emailId + "--" + notificationDetailsList.get(0).noOfRemainders + "--" + Instant.now())
                    }
                    notificationDetailsList.clear()
                }

            }
//            sendEmail("APPROVER",userDetails.emailId,userInfo.firstName,userDetails.projectName,userDetails.roleName,userDetails.projectLinearId,"","","")
            return ResponseEntity.ok(packageStatus) //.status(HttpStatus.CREATED).body(enrollmentStatus)
        }catch(e : Exception){
            throw e
        }
    }

    @PostMapping(value = ["submitVerdict"], produces = ["application/json"], consumes = ["application/json"])
    private fun submitVerdict(@RequestBody verdictDet : SubmitVerdictDetails,
                                      @RequestHeader(value = "belongsTo") belongsTo: String,
                                      @RequestHeader(value = "emailId") emailId: String,
                                      @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ApprovalMessage>{
        try {
            logger.info("SUBMIT VERDICT   ---   Initiated for package: "+verdictDet.packageLinearId)
            if ( belongsTo == "ERICSSON") {
                logger.info("SUBMIT VERDICT   ---   Ericsson approval")
//                System.out.println("inside func submit verdict internal" + verdictDet)
//                var inputWorkplans = verdictDet.packageComponents.filter { it.mappedToLevel.equals("WORKPLAN") }
//                val approvedWorkplans = mutableListOf<ApproverStatusDetails>()
//                for (i in inputWorkplans) {
//                    if (i.approverStatus.filter { it.approvedBy.equals("APPROVED") }.size > 0)
//                    {
//                        approvedWorkplans.add(i)
//                    }
//                }
                var comps = ClientQueryService(proxy).customQueryApproverStatusDetails(verdictDet.packageLinearId).map { it.state.data.approverStatusDetails }
                for (i in verdictDet.packageComponents) {
                    for (j in comps) {
                        if (i.mappedItemLinearId == j.mappedItemLinearId) {
                            i.siteId = j.siteId
                            i.siteName = j.siteName
                            i.mappedToLevel = j.mappedToLevel
                            i.mappedToName = j.mappedToName
                            i.approverStatusLinearId = j.approverStatusLinearId
                        }
                    }
                }
                var signtxn = proxy.startFlow(::SubmitVerdictInternalFlow, verdictDet).returnValue.getOrThrow()
                var packageResults = signtxn.coreTransaction.outputsOfType<AcceptancePackageState>().single().packageDetails
                var allApprovers = mutableListOf<PackageUsers>()
                allApprovers.addAll(packageResults.ericssonApprovers)
                allApprovers.addAll(packageResults.customerApprovers)
                var packageComponents = signtxn.coreTransaction.outputsOfType<ApproverStatusDetailsState>().map { it.approverStatusDetails }
                val message = ApprovalMessage(
                        projectLinearId = packageResults.projectLinearId,
                        packageLinearId = packageResults.packageLinearId,
                        packageName = packageResults.packageName,
                        projectId = packageResults.projectId,
                        approverDetails = allApprovers
                )
                val emailUpdateNotification = EmailNotificationModel(
                        projectLinearId = packageResults.projectLinearId,
                        projectId = packageResults.projectId,
                        packageName = packageResults.packageName,
                        packageLinearId = packageResults.packageLinearId,
                        status = (if (packageResults.ericssonApprovers.filter { it.overallUserApprovalStatus.equals("AWAITING APPROVAL") }.size > 0 )
                            packageResults.ericssonApprovers.filter { it.overallUserApprovalStatus.equals("AWAITING APPROVAL") }.get(0).overallUserApprovalStatus
                        else
                            ""),
                        senderAddress = if (packageResults.ericssonApprovers.filter { it.overallUserApprovalStatus.equals("AWAIING APPROVAL") }.size > 0)
                            packageResults.ericssonApprovers.filter { it.overallUserApprovalStatus.equals("AWAIING APPROVAL") }.map { it.emailId }
                else
                            emptyList<String>()
                )
//                post(url = "http://20.50.147.243:3001/approvalMail", headers=mapOf("Content-Type" to "application/json"), data = JSONObject(emailUpdateNotification))
                template?.convertAndSendToUser("user", "/approvalNotification", message)
                logger.info("SUBMIT VERDICT   ---   SubmitVerdictInternalFlow result package: "+packageResults)
                logger.info("SUBMIT VERDICT   ---   SubmitVerdictInternalFlow result components: "+packageComponents)
                val currentApprover = packageResults.ericssonApprovers.filter { it.emailId.equals(verdictDet.approverEmailId) }.get(0)
                val nextApprovers = packageResults.ericssonApprovers.filter { it.overallUserApprovalStatus.equals("AWAITING APPROVAL") }
                nextApprovers
                val projectDetails = ClientQueryService(proxy).customQueryProjectDetails(packageResults.projectLinearId).get(0)
                if (nextApprovers.size > 0 ) {
                    val nextApprover = nextApprovers.sortedBy { it.orderIndex }
                    sendEmail("UPDATESTATUS", nextApprover.get(0).emailId, nextApprover.get(0).firstName, projectDetails.state.data.projectDetails.projectName, nextApprover.get(0).roleName, packageResults.projectLinearId, packageResults.packageName, packageResults.packageLinearId, currentApprover.emailId)
                }
                val partyX500NamePartyCust: CordaX500Name
                partyX500NamePartyCust = CordaX500Name.parse("O=Customer A, L=New York, C=US")
                val proposeToParty = proxy.wellKnownPartyFromX500Name(partyX500NamePartyCust)
                        ?: throw IllegalArgumentException("SUBMIT VERDICT   ---   Target string \"$partyX500NamePartyCust\" doesn't match any nodes on the network.")
                System.out.println("inside func submit verdict internal----- calling UpdateApprovalStatusFlow")
                if (packageResults.internalApprovalCompleted) {
                    logger.info("SUBMIT VERDICT   ---   Internal approval completed ")
                    var signedTxn = proxy.startFlow(::UpdateApprovalStatusFlow, verdictDet, proposeToParty,false).returnValue.getOrThrow()
                    System.out.println("UpdateApprovalStatusFlow result" + signedTxn.coreTransaction.outputsOfType<ApproverStatusDetailsState>())
                }
                return ResponseEntity.ok(message)
            } else {
                logger.info("SUBMIT VERDICT   ---   Ericsson approval")
//                System.out.println("query sys oyt" + ClientQueryService(proxy).customQueryApproverStatusDetails(verdictDet.packageLinearId))
                var comps = ClientQueryService(proxy).customQueryApproverStatusDetails(verdictDet.packageLinearId).map { it.state.data.approverStatusDetails }
                for (i in verdictDet.packageComponents) {
                    for (j in comps) {
                        if (i.mappedItemLinearId == j.mappedItemLinearId) {
                            i.siteId = j.siteId
                            i.siteName = j.siteName
                            i.mappedToLevel = j.mappedToLevel
                            i.mappedToName = j.mappedToName
                            i.approverStatusLinearId = j.approverStatusLinearId
                        }
                    }
                }
                logger.info("SUBMIT VERDICT   ---   Updated input: "+verdictDet)
                val partyX500NamePartyCust : CordaX500Name
                partyX500NamePartyCust = CordaX500Name.parse("O=Ericsson A, L=Stockholm, C=SE")
                val proposeToParty = proxy.wellKnownPartyFromX500Name(partyX500NamePartyCust)
                        ?: throw IllegalArgumentException("Target string \"$partyX500NamePartyCust\" doesn't match any nodes on the network.")
                val signtxn = proxy.startFlow(::SubmitVerdictExternalFlow, verdictDet,proposeToParty).returnValue.getOrThrow()
                var packageResults = signtxn.coreTransaction.outputsOfType<AcceptancePackageState>().get(0).packageDetails
                logger.info("SUBMIT VERDICT   ---   SubmitVerdictExternalFlow result package: "+packageResults)
                var packageComponents = signtxn.coreTransaction.outputsOfType<ApproverStatusDetailsState>().map { it.approverStatusDetails }
                logger.info("SUBMIT VERDICT   ---   SubmitVerdictExternalFlow result components: "+packageComponents)
                val currentApprover = packageResults.customerApprovers.filter { it.emailId.equals(verdictDet.approverEmailId) }.get(0)
                val nextApprovers = packageResults.customerApprovers.filter { it.overallUserApprovalStatus.equals("AWAITING APPROVAL") }
                val projectDetails = ClientQueryService(proxy).customQueryProjectDetails(packageResults.projectLinearId).get(0)
                if (nextApprovers.size > 0 ) {
                    val nextApprover = nextApprovers.sortedBy { it.orderIndex }
                    sendEmail("UPDATESTATUS", nextApprover.get(0).emailId, nextApprover.get(0).firstName, projectDetails.state.data.projectDetails.projectName, nextApprover.get(0).roleName, packageResults.projectLinearId, packageResults.packageName, packageResults.packageLinearId, currentApprover.emailId)
                }
                var allApprovers = mutableListOf<PackageUsers>()
                allApprovers.addAll(packageResults.ericssonApprovers)
                allApprovers.addAll(packageResults.customerApprovers)
                val message = ApprovalMessage(
                        projectLinearId = packageResults.projectLinearId,
                        packageLinearId = packageResults.packageLinearId,
                        packageName = packageResults.packageName,
                        projectId = packageResults.projectId,
                        approverDetails = allApprovers
                )
                val emailUpdateNotification = EmailNotificationModel(
                        projectLinearId = packageResults.projectLinearId,
                        projectId = packageResults.projectId,
                        packageName = packageResults.packageName,
                        packageLinearId = packageResults.packageLinearId,
                        status = (if (packageResults.customerApprovers.filter { it.overallUserApprovalStatus.equals("AWAITING APPROVAL") }.size > 0 )
                            packageResults.customerApprovers.filter { it.overallUserApprovalStatus.equals("AWAITING APPROVAL") }.get(0).overallUserApprovalStatus
                        else
                            ""),
                        senderAddress = if (packageResults.customerApprovers.filter { it.overallUserApprovalStatus.equals("AWAIING APPROVAL") }.size > 0)
                            packageResults.customerApprovers.filter { it.overallUserApprovalStatus.equals("AWAIING APPROVAL") }.map { it.emailId }
                        else
                            emptyList<String>()
                )
                post(url = "http://20.50.147.243:3001/approvalMail", headers=mapOf("Content-Type" to "application/json"), data = JSONObject(emailUpdateNotification))
                template?.convertAndSendToUser("user", "/approvalNotification", message)
                var fullySigntxn  = proxy.startFlow (::UpdateApprovalStatusFlow, verdictDet, proposeToParty, true ).returnValue.getOrThrow()
                logger.info("SUBMIT VERDICT   ---   UpdateApprovalStatusFlow result: "+fullySigntxn.coreTransaction.outputsOfType<ApproverStatusDetailsState>())
                return ResponseEntity.ok(message)
            }
        }catch(e : Exception){
            throw e
        }
    }

    @PostMapping(value = ["initiateExternalApproval/{packageLinearId}"], produces = ["application/json"])
    private fun initiateExternalApproval(@PathVariable packageLinearId: String,
                                         @RequestHeader(value = "belongsTo") belongsTo: String,
                                         @RequestHeader(value = "emailId") emailId: String,
                                         @RequestHeader(value = "roleName") roleName: String): ResponseEntity<PackageDetailsModel>{
        try {
            logger.info("INITIATE EXTERNAL APPROVAL   ---   Initiated for package: "+packageLinearId)
            val partyX500NamePartyCust : CordaX500Name
            partyX500NamePartyCust = CordaX500Name.parse("O=Customer A, L=New York, C=US")
            val proposeToParty = proxy.wellKnownPartyFromX500Name(partyX500NamePartyCust)
                    ?: throw IllegalArgumentException("Target string \"$partyX500NamePartyCust\" doesn't match any nodes on the network.")
            val signtxn = proxy.startFlow(::SubmitAcceptancePackageFlow, packageLinearId,proposeToParty).returnValue.getOrThrow()
            var packageResults = signtxn.coreTransaction.outputsOfType<AcceptancePackageState>().single().packageDetails
            var packageComponents = signtxn.coreTransaction.outputsOfType<ApproverStatusDetailsState>().map { it.approverStatusDetails }
            logger.info("INITIATE EXTERNAL APPROVAL   ---   SubmitAcceptancePackageFlow result package: "+packageResults)
            logger.info("INITIATE EXTERNAL APPROVAL   ---   SubmitAcceptancePackageFlow result components: "+packageResults)
            val projectDetails = ClientQueryService(proxy).customQueryProjectDetails(packageResults.projectLinearId).get(0)
            val nextApprover = packageResults.customerApprovers.filter { it.overallUserApprovalStatus.equals("AWAITING APPROVAL") }
            val lastApprover = packageResults.ericssonApprovers.sortedByDescending { it.orderIndex }
            sendEmail("UPDATESTATUS", nextApprover.get(0).emailId, nextApprover.get(0).firstName, projectDetails.state.data.projectDetails.projectName, nextApprover.get(0).roleName, packageResults.projectLinearId, packageResults.packageName, packageResults.packageLinearId, lastApprover.get(0).emailId)
            return ResponseEntity.ok(signtxn.coreTransaction.outputsOfType<AcceptancePackageState>().single().packageDetails)
        }catch(e : Exception){
            throw e
        }
    }

    @GetMapping(value = ["getProjectByProjectId/{projectId}"], produces = ["application/json"])
    private fun getProjectByProjectId (@PathVariable projectId : String
    ) : ResponseEntity<ProjectDetails>{
        logger.info("GET PROJECT BY PROJECT ID   ---   Initiated for project: "+projectId)
        val response = getErisiteProjectDetails(projectId)
        return ResponseEntity.ok(response)
    }


    @GetMapping(value = ["getProofByItemLinearId/{itemLinearId}"], produces = ["application/json"])
    private fun getProofByItemLinearId( @PathVariable itemLinearId : String)  : ResponseEntity<List<ItemProof>>{
        logger.info("GET PROOF BY ITEM LINEAR ID   ---   Initiated for Item: "+itemLinearId)
        val proofList = mutableListOf<ItemProof>()
        val itemState = ClientQueryService(proxy).linearStateQueryHistoryItemProof(listOf(itemLinearId))
        if(itemState.size > 0){
            itemState.forEach {
                proofList.addAll(it.state.data.checklistItemDetails.itemProof)
            }
        }

        return ResponseEntity.ok(proofList)
    }

    @GetMapping("/downloadTemplate")
    fun downloadTemplate(): ResponseEntity<InputStreamResource> {
        val bis = APIUtils.Template();
        val headers = HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=template.xlsx");
        return ResponseEntity
                .ok()
                .headers(headers)
                .body(InputStreamResource(bis));
    }

    @GetMapping(value = ["getAcceptancePackage/{packageLinearId}"], produces = ["application/json"])
    fun getAcceptancePackage(@PathVariable packageLinearId: String,
                                 @RequestHeader(value = "belongsTo") belongsTo: String,
                                 @RequestHeader(value = "emailId") emailId: String,
                                 @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<PackageTree> {
        logger.info("GET ACCEPTANCE PACKAGE   ---   Initiated for package: "+packageLinearId)
        val acceptancePackage = ClientQueryService(proxy).customQueryPackageDetailsByPackId(packageLinearId).map { it.state.data.packageDetails }.get(0)
        logger.info("GET ACCEPTANCE PACKAGE   ---   Package: "+acceptancePackage)
        val approverStatusDetails= ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }
        logger.info("GET ACCEPTANCE PACKAGE   ---   Components: "+approverStatusDetails)
        var comp= mutableListOf<Components>()
        var listOfUsers = mutableListOf<PkgUsers>()
        for ( i in acceptancePackage.ericssonApprovers) {
            var temp = PkgUsers(
                    user = i.firstName + " " + i.lastName,
                    belongsTo = i.belongsTo,
                    roleName = i.roleName,
                    status = i.overallUserApprovalStatus,
                    emailId = i.emailId
            )
            listOfUsers.add(temp)
        }
        for ( i in acceptancePackage.customerApprovers) {
            var temp = PkgUsers(
                    user = i.firstName + " " + i.lastName,
                    belongsTo = i.belongsTo,
                    roleName = i.roleName,
                    status = i.overallUserApprovalStatus,
                    emailId = i.emailId
            )
            listOfUsers.add(temp)
        }
        for ( i in acceptancePackage.ericssonObservers) {
            var temp = PkgUsers(
                    user = i.firstName + " " + i.lastName,
                    belongsTo = i.belongsTo,
                    roleName = i.roleName,
                    status = i.overallUserApprovalStatus,
                    emailId = i.emailId
            )
            listOfUsers.add(temp)
        }
        for ( i in acceptancePackage.customerObservers) {
            var temp = PkgUsers(
                    user = i.firstName + " " + i.lastName,
                    belongsTo = i.belongsTo,
                    roleName = i.roleName,
                    status = i.overallUserApprovalStatus,
                    emailId = i.emailId
            )
            listOfUsers.add(temp)
        }
        for ( i in acceptancePackage.ericssonContributor) {
            var temp = PkgUsers(
                    user = i.firstName + " " + i.lastName,
                    belongsTo = i.belongsTo,
                    roleName = i.roleName,
                    status = i.overallUserApprovalStatus,
                    emailId = i.emailId
            )
            listOfUsers.add(temp)
        }
        val listOfWorkplanTree = mutableListOf<WorkplanTreePackage>()
        listOfWorkplanTree.addAll(APIUtils.processAllWorkplanOfPackage(packageLinearId, acceptancePackage.projectLinearId, proxy, emailId))
        val workplanBySiteMap = listOfWorkplanTree.groupBy { it.siteId }
        val workplanBySiteList = mutableListOf<WorkplanBySitePackage>()
        for ((siteId, listOfWp) in workplanBySiteMap) {
            var siteStatus : String = ""
            siteStatus = if (listOfWp.all { it.status.equals("APPROVED") })
                "APPROVED"
            else if (listOfWp.all { it.status.equals("INTERNALLY APPROVED") })
                "INTERNALLY APPROVED"
            else if (listOfWp.any { it.status.equals("REJECTED") })
                "REJECTED"
            else
                "PENDING"
            val workplanBySite = WorkplanBySitePackage(
                    siteId = siteId,
                    siteName = listOfWp.get(0).siteName,
                    status = siteStatus,
                    workplanDetails = listOfWp
            )
            workplanBySiteList.add(workplanBySite)
        }
        val components = approverStatusDetails.toMutableList().groupBy { it.siteId }
        var packageDetails = PackageTree(
                packageLinearId = acceptancePackage.packageLinearId,
                packageName = acceptancePackage.packageName,
                packageDescription = acceptancePackage.packageDescription,
                slaDays = acceptancePackage.slaDays,
                typeOfAcceptance = acceptancePackage.typeOfAcceptance,
                autoApproval = acceptancePackage.autoApproval,
                internalApprovalCompleted = acceptancePackage.internalApprovalCompleted,
                pkgUsers = listOfUsers,
                workplanBySite = workplanBySiteList
        )
        return ResponseEntity.ok(packageDetails)
    }

    @GetMapping(value = ["getProjectStatistics/{projectLinearId}"], produces = ["application/json"])
    private fun getProjectStatistics( @PathVariable projectLinearId : String ) : ResponseEntity<ProjectStatisticsModel> {
        logger.info("GET PROJECT STATISTICS   ---   Initiated for project: "+projectLinearId)
        var sites = mutableListOf<Sites>()
        val workplans = ClientQueryService(proxy).customQueryWorkplanDetails(projectLinearId).map { it.state.data.workplanDetails }
        logger.info("GET PROJECT STATISTICS   ---   Workplans: "+workplans)
        val respectiveSites = workplans.groupBy { it.siteId }
        logger.info("GET PROJECT STATISTICS   ---   Respective sites: "+respectiveSites)
        for((k,v) in respectiveSites){
            var details = mutableListOf<StatusDetails>()
            var activityCount  : Int = 0
            var milestoneCount : Int = 0
            var activityApproved  : Int = 0
            var milestoneApproved : Int = 0
            var activityRejected : Int = 0
            var milestoneRejected : Int = 0
            var activityPending : Int = 0
            var milestonePending : Int = 0
            var activityInternallyApproved : Int = 0
            var milestoneInternallyApproved : Int = 0
            for (i in v){
                val activitesOutput = ClientQueryService(proxy).customQueryActivityDetails(i.workplanLinearId)
                logger.info("GET PROJECT STATISTICS   ---   Activites: "+activitesOutput)
                if (activitesOutput.size > 0) {
                    val activites = activitesOutput.map { it.state.data.activityDetails }
                    val count = activites.count()
                    activityApproved += activites.filter { it.activityApprovalStatus.equals("APPROVED") }.count()
                    activityRejected += activites.filter { it.activityApprovalStatus.equals("REJECTED") }.count()
                    activityPending += activites.filter { it.activityApprovalStatus.equals("PENDING") }.count()
                    activityInternallyApproved += activites.filter { it.activityApprovalStatus.equals("INTERNALLY APPROVED") }.count()
                    activityCount += count
                }
                val milestonesOutput = ClientQueryService(proxy).customQueryMilestoneDetailsByWorkplan(i.workplanLinearId)
                logger.info("GET PROJECT STATISTICS   ---   Milestones: "+milestonesOutput)
                if (milestonesOutput.size > 0) {
                    val milestones = milestonesOutput.map { it.state.data.milestoneDetails }
                    val count1 = milestones.count()
                    milestoneApproved += milestones.filter { it.milestoneApprovalStatus.equals("APPROVED") }.count()
                    milestoneRejected += milestones.filter { it.milestoneApprovalStatus.equals("REJECTED") }.count()
                    milestonePending += milestones.filter { it.milestoneApprovalStatus.equals("PENDING") }.count()
                    milestoneInternallyApproved += milestones.filter { it.milestoneApprovalStatus.equals("INTERNALLY APPROVED") }.count()
                    milestoneCount += count1
                }
            }
            val tempWorkplan = StatusDetails(
                    level = "WORKPLAN",
                    total = v.count(),
                    approved = v.filter { it.workplanApprovalStatus.equals("APPROVED") }.count(),
                    internallyApproved = v.filter { it.workplanApprovalStatus.equals("INTERNALLY APPROVED") }.count(),
                    rejected = v.filter { it.workplanApprovalStatus.equals("REJECTED") }.count(),
                    pending = v.filter { it.workplanApprovalStatus.equals("PENDING") }.count()

            )
            details.add(tempWorkplan)
            val tempActivity = StatusDetails(
                    level = "ACTIVITY",
                    total = activityCount,
                    approved = activityApproved,
                    internallyApproved = activityInternallyApproved,
                    rejected = activityRejected,
                    pending = activityPending
            )
            details.add(tempActivity)
            val tempMilestone = StatusDetails(
                    level = "MILESTONE",
                    total = milestoneCount,
                    approved = milestoneApproved,
                    internallyApproved = milestoneInternallyApproved,
                    rejected = milestoneRejected,
                    pending = milestonePending
            )
            details.add(tempMilestone)
            val tempSite = Sites(
                    siteName = k,
                    status = if(v.all { it.workplanApprovalStatus.equals("INTERNALLY APPROVED") })
                        "INTERNALLY APPROVED"
                    else if(v.all { it.workplanApprovalStatus.equals("APPROVED") })
                        "APPROVED"
                    else if(v.any { it.workplanApprovalStatus.equals("REJECTED") })
                        "REJECTED"
                    else
                        "PENDING",
                    totalWorkplanCount = v.count(),
                    totalActivityCount = activityCount,
                    statusDetails = details
            )
            sites.add(tempSite)
        }

        var projectStatistics: ProjectStatisticsModel
        projectStatistics = ProjectStatisticsModel (
                projectLinearId = projectLinearId,
                totalCount = sites.count(),
                totalApprovedCount = sites.filter { it.status.equals("APPROVED") }.count(),
                totalRejectedCount = sites.filter { it.status.equals("REJECTED") }.count(),
                pendingEricssonCount = sites.filter { it.status.equals("PENDING") }.count(),
                pendingCustomerCount = sites.filter { it.status.equals("INTERNALLY APPROVED") }.count(),
                sites = sites
        )
        logger.info("GET PROJECT STATISTICS   ---   Statistics: "+projectStatistics)
        return ResponseEntity.ok(projectStatistics)
    }

    @GetMapping(value = ["getAcceptancePackageComponents/{packageLinearId}/{siteId}"], produces = ["application/json"])
    private fun getAcceptancePackageComponents(@PathVariable packageLinearId: String, @PathVariable siteId: String,
                             @RequestHeader(value = "belongsTo") belongsTo: String,
                             @RequestHeader(value = "emailId") emailId: String,
                             @RequestHeader(value = "roleName") roleName: String) : ResponseEntity<List<ApproverStatusDetails>> {
        logger.info("GET ACCEPTANCE PACKAGE COMPONENTS   ---   Initiated for package: "+packageLinearId+" and site: "+siteId)
        val approverStatusDetailsWithoutsitefilter = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }
        val approverStatusDetails = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.siteId.equals(siteId) }
        val approverStat = approverStatusDetails.get(0).approverStatus
        val result = mutableListOf<ApproverStatusDetails>()
        logger.info("GET ACCEPTANCE PACKAGE COMPONENTS   ---   All approver status: "+approverStat)
        val currentApproverStat = approverStat.filter { it.approvedBy.equals(emailId) }
        logger.info("GET ACCEPTANCE PACKAGE COMPONENTS   ---   Current approver status: "+currentApproverStat)
        for(i in approverStatusDetails){
            val temp = ApproverStatusDetails(
                    approverStatusLinearId = i.approverStatusLinearId,
                    mappedToLinearId = i.mappedToLinearId,
                    mappedToLevel = i.mappedToLevel,
                    mappedToName = i.mappedToName,
                    mappedItemLevel = i.mappedItemLevel,
                    mappedItemLinearId = i.mappedItemLinearId,
                    mappedItemId = i.mappedItemId,
                    mappedItemName = i.mappedItemName,
                    siteId = i.siteId,
                    siteName = i.siteName,
                    packageLinearId = i.packageLinearId,
                    projectLinearId = i.projectLinearId,
                    overallApprovalStatus = i.overallApprovalStatus,
                    siteLevelApproval = i.siteLevelApproval,
                    approverStatus = currentApproverStat
            )
            result.add(temp)
        }
        logger.info("GET ACCEPTANCE PACKAGE COMPONENTS   ---   All components: "+result)
        return ResponseEntity.ok(result.toList())
    }

    @PostMapping(value = ["updateChecklistAllForRejection"], produces = ["application/json"], consumes = ["application/json"])
    private fun updateChecklistAllForRejection (@RequestBody categoryLinearId : List<String>,
                                                @RequestHeader(value = "belongsTo") belongsTo: String,
                                                @RequestHeader(value = "emailId") emailId: String,
                                                @RequestHeader(value = "roleName") roleName: String): ResponseEntity<ChecklistItem> {
        try {
            logger.info("UPDATE CHECKLIST ALL FOR REJECTION   ---   Initiated for Category: "+categoryLinearId)
            val checkListItems = mutableListOf<String>()
            for( det in categoryLinearId){
                val checklistDetailsRef = ClientQueryService(proxy).customQueryChecklistItemDetailsByCategory(det)
                val checkListItem = checklistDetailsRef.map { it.state.data.checklistItemDetails.itemLinearId }
                checkListItems.addAll(checkListItem)
            }
            val itemSignTxn = proxy.startFlow(::UpdateChecklistItemDetailStatusFlow, checkListItems).returnValue.getOrThrow()
            return ResponseEntity.ok(itemSignTxn.coreTransaction.outputsOfType<ChecklistItemDetailsState>().single().checklistItemDetails)
        }catch(e : Exception){
            throw e
        }
    }

    private fun updateProjectStructure(@PathVariable checkListLinearId: String,@PathVariable mappedLinearId: String) : ResponseEntity<ProjectTree> {
        logger.info("UPDATE PROJECT STRUCTURE   ---   Initiated for checklist: "+checkListLinearId+" and its parent: "+mappedLinearId)
        var wrkplanChecklist = mutableListOf<ChecklistTree>()
        var actChecklist = mutableListOf<ChecklistTree>()
        var milCheckLists = mutableListOf<ChecklistTree>()
        var wrkPlanDetails = mutableListOf<WorkplanTree>()
        var wrkPlanBySites = mutableListOf<WorkplanBySite>()
        var actTrees = mutableListOf<ActivityTree>()
        var milTrees = mutableListOf<MilestoneTree>()
        val details = ClientQueryService(proxy).linearStateQueryChecklist(listOf(checkListLinearId))
        var projectTree = getProjectTreeStructure(details.get(0).state.data.checklistDetails.projectLinearId, "ERICSSON", "rohit.seetha@ericsson.com", "CONTRIBUTOR")
        var resultant = projectTree.body.copy()

        resultant.workplanBySite.toMutableList().forEach {
            wrkPlanDetails.clear()
            it.workplanDetails.forEach {
                wrkplanChecklist.clear();
                wrkplanChecklist.addAll(it.workplanChecklist)
                if(it.workplanLinearId == mappedLinearId){
                    wrkplanChecklist.add(getCheckListTree(checkListLinearId))
                }
                milTrees.clear()
                it.milestones.forEach {
                    milCheckLists.clear();
                    milCheckLists.addAll(it.milestoneChecklist)
                    if(it.milestoneLinearId == mappedLinearId){
                        milCheckLists.add(getCheckListTree(checkListLinearId))
                    }
                    milTrees.add(MilestoneTree(
                            milestoneLinearId = it.milestoneLinearId,
                            milestoneId  = it.milestoneId,
                            milestoneName = it.milestoneName,
                            milestoneDocContainer = it.milestoneDocContainer,
                            milestoneChecklist = milCheckLists.toList()
                    ))
                }
                actTrees.clear()
                it.activities.forEach {
                    actChecklist.clear()
                    actChecklist.addAll(it.activityChecklist)
                    if(it.activityLinearId == mappedLinearId){
                        actChecklist.add(getCheckListTree(checkListLinearId))
                    }
                    actTrees.add(ActivityTree(
                            activityLinearId = it.activityLinearId,
                            activityId = it.activityId,
                            activityName  = it.activityName,
                            activityDocContainer  = it.activityDocContainer,
                            activityChecklist  = actChecklist.toList()
                    ))
                }
                wrkPlanDetails.add(WorkplanTree(
                        siteId =it.siteId,
                        siteName  = it.siteName,
                        workplanLinearId = it.workplanLinearId,
                        workplanId  = it.workplanId,
                        workplanName = it.workplanName,
                        activities  = actTrees.toList(),
                        milestones  = milTrees.toList(),
                        workplanDocs  = it.workplanDocs,
                        workplanChecklist = wrkplanChecklist.toList()
                ))
            }
            wrkPlanBySites.add(WorkplanBySite(
                    siteId = it.siteId,
                    workplanDetails = wrkPlanDetails.toList()
            ))
        }

        val res = ProjectTree(
                projectId = resultant.projectId,
                projectName =resultant.projectName,
                projectLinearId= resultant.projectLinearId,
                workplanBySite = wrkPlanBySites
        )
        val projectStructure = ProjectStructure(
                        projectid = resultant.projectLinearId.toString(),
                        data = res
        )
        val submitTreeStructure = post(OFF_CHAIN_WEB_URL + "/updateProject", headers = mapOf("Content-Type" to "application/json"), data = JSONObject(projectStructure))
        logger.info("UPDATE PROJECT STRUCTURE   ---   Update tree structure: "+submitTreeStructure)
        return ResponseEntity.ok(res)
    }

    private fun getCheckListTree(checkListLinearId : String): ChecklistTree {
        logger.info("GET CHECKLIST TREE   ---   Initiated for checklist: "+checkListLinearId)
        val chklistTree = mutableListOf<ChecklistTree>()
        val chklistCategory = mutableListOf<ChecklistCategoryTree>()
        val chklistCategoryItem = mutableListOf<ChecklistCategoryItemsTree>()
        val details = ClientQueryService(proxy).linearStateQueryChecklist(listOf(checkListLinearId))
        val checklistCategoryItems = ClientQueryService(proxy).customQueryChecklistCategory(checkListLinearId).map { it.state.data.checklistCategoryDetails }
        checklistCategoryItems.forEach {
            val checklistCategoryItems = ClientQueryService(proxy).customQueryChecklistItemDetailsByCategory(it.checklistCategoryLinearId).map { it.state.data.checklistItemDetails }
            checklistCategoryItems.forEach {

                val checklistCategoryItems = ChecklistCategoryItemsTree(
                        checklistItemId = it.itemId,
                        checklistItemLinearId = it.itemLinearId
                )
                chklistCategoryItem.add(checklistCategoryItems)
            }
            val checklistCategoryTree = ChecklistCategoryTree(
                    checklistCategoryName = it.checklistCategoryName,
                    checklistCategoryLinearId = it.checklistCategoryLinearId,
                    checklistCategoryItems =  chklistCategoryItem           )
            chklistCategory.add(checklistCategoryTree)
        }
        val checklistTree = ChecklistTree(
                checklistLinearId = checkListLinearId,
                checklistName = details.get(0).state.data.checklistDetails.checklistName,
                checklistCategory = chklistCategory
        )
        chklistTree.add(checklistTree)
        return checklistTree
    }

    @Throws(MessagingException::class, IOException::class)
    fun sendEmail(notificationType: String,emailId: String,name : String,projectName: String,roleName: String,projectLinearId: String,packageName: String,packageLinearId : String,approver: String) {
        logger.info("SEND EMAIL   ---   Initiated for user: "+emailId)
        val msg: MimeMessage = javaMailSender!!.createMimeMessage()
        val helper = MimeMessageHelper(msg, true)
        helper.setFrom("no-reply.harmonia@ericsson.com")
        helper.setTo(emailId)
        helper.setSubject("Ericsson Customer Acceptance Notification")
        val html = APIUtils.mailText(notificationType,name, projectName, roleName, projectLinearId,packageName,packageLinearId,approver)
        helper.setText(APIUtils.mailText(notificationType,name, projectName, roleName, projectLinearId,packageName,packageLinearId,approver), true)
        javaMailSender?.send(msg)
    }

}

package com.harmonia.webserver

import com.google.gson.Gson
import com.harmonia.Service.ClientQueryService
import com.harmonia.flows.*
import com.harmonia.flows.updates.UpdateChecklistItemRAFlow
import com.harmonia.model.*
import com.harmonia.states.*
import khttp.get
import khttp.post
import khttp.responses.Response
import net.corda.core.messaging.CordaRPCOps
import net.corda.core.messaging.startFlow
import net.corda.core.utilities.getOrThrow
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.json.JSONArray
import org.json.JSONObject
import org.slf4j.LoggerFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.Instant
import khttp.structures.authorization.BasicAuthorization

object APIUtils {
//    object {
        private val logger = LoggerFactory.getLogger(RPCController::class.java)

//        })
    fun generateErisiteAPIToken(): String {
        var token = ""
        try {
            val auth: String = "Basic SWhmYmY0ZDM1bW9MNDZ6cERmUnhEWkxxUGJRYTo1TzBuUEthVUJCN29yWDJoOXNmOTh2M3c1ZTBh"
            var erisiteAuthResponse: Response
            do {
                erisiteAuthResponse = post(API_ERISITE_SB2_AUTH_URL, headers = mapOf("Authorization" to auth), data = mapOf("grant_type" to "client_credentials"))
            } while (erisiteAuthResponse.statusCode == 401)
            token = "Bearer " + erisiteAuthResponse.jsonObject.get("access_token").toString()
        }catch(e : Exception){
            throw e
        }
        return token
    }

    fun getErisiteAPIResponse(token : String, url : String) : Response{
        return try{
            get(url, headers = mapOf("Content-Type" to "application/json",
                    "Authorization" to token))
        }catch(exception : Exception){
            throw exception
        }
    }

    fun getErisiteProjectDetails(projectId : String) : ProjectDetails{
        try{
            val token = generateErisiteAPIToken()
            val projectUrl = API_ERISITE_SB2_URL+"projects?ProjectID="+projectId
            val erisiteResponse = getErisiteAPIResponse(token, projectUrl )
            logger.info("API UTILS   ---   erisiteResponse: "+erisiteResponse)
            val projectDetails = erisiteResponse.jsonObject.getJSONArray("data")
            if(projectDetails.length() == 0)
                throw Exception("API UTILS   ---   Empty Response from Erisite")
            val txProjectDetails = ProjectDetails(
                    projectId = checkForNull(projectDetails.getJSONObject(0).getString("ProjectID")).toString(),
                    projectStatus = checkForNull(projectDetails.getJSONObject(0).getString("Status")).toString(),
                    customer = checkForNull(projectDetails.getJSONObject(0).getString("Customer")).toString(),
                    FASID = checkForNull(projectDetails.getJSONObject(0).getString("FASID")).toString(),
                    projectName = checkForNull(projectDetails.getJSONObject(0).getString("ProjectName")).toString(),
                    projectLinearId = "",
                    projectExecutionCountry = checkForNull(projectDetails.getJSONObject(0).getString("ProjectExecutionCountry")).toString(),
                    projectActualStartDate = checkForNull(projectDetails.getJSONObject(0).get("ActualStartDateTime")).toString(),
                    projectActualEndDate = checkForNull(projectDetails.getJSONObject(0).get("ActualEndDateTime")).toString(),
                    projectPlannedStartDate = checkForNull(projectDetails.getJSONObject(0).get("PlannedEndDateTime")).toString(),
                    projectPlannedEndDate = checkForNull(projectDetails.getJSONObject(0).get("PlannedStartDateTime")).toString(),
                    projectCreatedDate = checkForNull(projectDetails.getJSONObject(0).get("ProjectCreatedDate")).toString(),
                    projectType =checkForNull(projectDetails.getJSONObject(0).get("ProjectType")).toString(),
                    modifiedTime = Instant.now(),
                    isCriteriaApproved = true,
                    importStatus = "IN-PROGRESS",
                    projectApprovalStatus = "PENDING",
                    creationTime = Instant.now()
            )
            return txProjectDetails
        }catch(e : Exception){
            throw e
        }
    }

    fun submitProjectDetails(projectDetails : ProjectDetails, proxy : CordaRPCOps) : String{
        logger.info("API UTILS   ---   SubmitProjectDetails Initiated")
        val signTxn = proxy.startFlow(::ProjectDetailsFlow,projectDetails ).returnValue.getOrThrow()
        return signTxn.coreTransaction.outputsOfType<ProjectDetailsState>().single().linearId.toString()
    }

    fun processAllWorkplan(projectId : String, projectLinearId : String, proxy : CordaRPCOps) : MutableList<WorkplanTree>{
        logger.info("API UTILS   ---   processAllWorkplan Initiated")
        var listOfWorkplanTree = mutableListOf<WorkplanTree>()
        try{
            var currentPage : Int = 0
            var totalPages : Int = 1

            do{
                currentPage = currentPage + 1
                val token = APIUtils.generateErisiteAPIToken()
                val baseUrl = API_ERISITE_SB2_URL + "workplans/fullstructure?page="+currentPage+"&ProjectID="+projectId
                val workplanDetails = get(baseUrl, headers = mapOf("Content-Type" to "application/json", "Authorization" to token))
                logger.info("API UTILS   ---   workplan response: "+workplanDetails)
                val records = workplanDetails.jsonObject.getJSONArray("data")
                listOfWorkplanTree = mapWorkPlanDetails(records, proxy, projectLinearId, projectId)
                totalPages = workplanDetails.jsonObject.get("totalPages").toString().toInt()
            }while(currentPage < totalPages)
        }catch(e : Exception){
            throw e
        }
        return listOfWorkplanTree
    }

    fun mapWorkPlanDetails(response : JSONArray,proxy : CordaRPCOps, projectLinearId : String, projectId : String) : MutableList<WorkplanTree>{
        logger.info("API UTILS   ---   mapWorkPlanDetails Initiated")
        if(response.length() == 0)
            throw Exception("API UTILS   ---   Process Workplan Exception For Project:"+ projectLinearId)
        val workplanTreeList = mutableListOf<WorkplanTree>()
        try {
            for (i in 0..(response.length() - 1)) {
                val jsonDetails = response.getJSONObject(i)
                ////System.out.println(response.getJSONObject(0).get("WorkPlanID"))
                val workplanDetails = WorkplanDetails(
                        workplanId = checkForNull(jsonDetails.get("WorkPlanID")).toString(),
                        workplanName = checkForNull(jsonDetails.get("WorkPlanName")).toString(),
                        workplanStatus = checkForNull(jsonDetails.get("Status")).toString(),
                        systemGeography = checkForNull(jsonDetails.get("SystemGeography")).toString(),
                        language = checkForNull(jsonDetails.get("Language")).toString(),
                        workplanType = checkForNull(jsonDetails.get("WorkPlanType")).toString(),
                        description = checkForNull(jsonDetails.get("Description")).toString(),
                        workplanPlannedStartDate = checkForNull(jsonDetails.get("PlannedStartDate")).toString(),
                        workplanPlannedEndDate = checkForNull(jsonDetails.get("PlannedEndDate")).toString(),
                        workplanActualStartDate = checkForNull(jsonDetails.get("ActualStartDate")).toString(),
                        workplanActualEndDate = checkForNull(jsonDetails.get("ActualEndDate")).toString(),
                        mappedToLinearId = projectLinearId,
                        workplanLinearId = "",
                        siteId = checkForNull(jsonDetails.getJSONObject("Site").get("ID")).toString(),
                        siteName = checkForNull(jsonDetails.getJSONObject("Site").get("Name")).toString(),
                        siteHierrachyPath = checkForNull(jsonDetails.getJSONObject("Site").get("HierarchyPath")).toString(),
                        projectId = projectId,
                        isInternal = false,
                        creationTime = Instant.now(),
                        modifiedTime = Instant.now(),
                        workplanMappedTo = "SITE",
                        workplanApprovalStatus = APPROVAL_STATUS.PENDING.toString()
                )
                val signTxn = proxy.startFlow(::WorkplanDetailsFlow, workplanDetails).returnValue.getOrThrow()
                val workplanLinearId = signTxn.coreTransaction.outputsOfType<WorkplanDetailsState>().single().linearId.toString()
                logger.info("API UTILS   ---   WorkplanLinearId: "+workplanLinearId)
                var checklistTree = mutableListOf<ChecklistTree>()
                val docContainerTree = mutableListOf<DocumentTree>()
                val activityTree = mutableListOf<ActivityTree>()
                val milestoneTree = mutableListOf<MilestoneTree>()
                if (jsonDetails.has("Checklist")) {
                    checklistTree.addAll(mapChecklistDetails(jsonDetails.getJSONArray("Checklist"), workplanLinearId, proxy,
                            workplanDetails.projectId, workplanDetails.mappedToLinearId, workplanDetails.workplanId,
                            workplanLinearId, workplanDetails.siteId, workplanDetails.siteName))
                }
                if (jsonDetails.has("RequiredDocContainer") && jsonDetails.get("RequiredDocContainer") is JSONArray) {
                    docContainerTree.addAll(retriveDocDetails(jsonDetails.getJSONArray("RequiredDocContainer"), "RequiredDocContainer", workplanLinearId, proxy,
                            workplanDetails.projectId, workplanDetails.mappedToLinearId, workplanDetails.workplanId,
                            workplanLinearId, workplanDetails.siteId, workplanDetails.siteName))
                }
                if (jsonDetails.has("OptionalDocContainer") && jsonDetails.getJSONArray("OptionalDocContainer") is JSONArray) {
                    docContainerTree.addAll(retriveDocDetails(jsonDetails.getJSONArray("OptionalDocContainer"), "OptionalDocContainer", workplanLinearId, proxy,
                            workplanDetails.projectId, workplanDetails.mappedToLinearId, workplanDetails.workplanId,
                            workplanLinearId, workplanDetails.siteId, workplanDetails.siteName))
                }
                if (jsonDetails.has("AcceptanceDocContainer") && jsonDetails.getJSONArray("AcceptanceDocContainer") is JSONArray) {
                    docContainerTree.addAll(retriveDocDetails(jsonDetails.getJSONArray("AcceptanceDocContainer"), "AcceptanceDocContainer", workplanLinearId, proxy,
                            workplanDetails.projectId, workplanDetails.mappedToLinearId, workplanDetails.workplanId,
                            workplanLinearId, workplanDetails.siteId, workplanDetails.siteName))
                }
                if (jsonDetails.has("Activity") && jsonDetails.get("Activity") is JSONArray) {
                    activityTree.addAll(mapActivityDetails(jsonDetails.getJSONArray("Activity"), workplanLinearId, proxy, workplanDetails.projectId,workplanDetails.mappedToLinearId,
                            workplanDetails.workplanId, workplanLinearId,workplanDetails.siteId, workplanDetails.siteName))
                }
                if (jsonDetails.has("Milestone") && jsonDetails.get("Milestone") is JSONArray) {
                    milestoneTree.addAll(mapMilestoneDetails(jsonDetails.getJSONArray("Milestone"), workplanLinearId, proxy, workplanDetails.projectId,workplanDetails.mappedToLinearId,
                            workplanDetails.workplanId, workplanLinearId,workplanDetails.siteId, workplanDetails.siteName))
                }

                val workplanTree  = WorkplanTree(
                        workplanLinearId = workplanLinearId,
                        workplanName = workplanDetails.workplanName,
                        workplanId = workplanDetails.workplanId,
                        siteName = workplanDetails.siteName,
                        siteId = workplanDetails.siteId,
                        activities = activityTree,
                        milestones = milestoneTree,
                        workplanChecklist = checklistTree,
                        workplanDocs = docContainerTree
                )
                workplanTreeList.add(workplanTree)
            }
        }catch(e : Exception){
            throw e
        }
        return workplanTreeList
    }

    fun mapChecklistDetails(checklistArray : JSONArray, mappedToLinearId : String, proxy : CordaRPCOps,
                            projectId : String, projectLinearId : String, workplanId : String,
                            workplanLinearId : String, siteId : String, siteName : String) : MutableList<ChecklistTree>{
        logger.info("API UTILS   ---   mapChecklistDetails Initiated")
        //val chkList = mutableListOf<ChecklistDetails>()
        val chkListItems = mutableListOf<ChecklistItem>()
        val chklistTree = mutableListOf<ChecklistTree>()


        for(i in 0..(checklistArray.length() - 1)) {
            val checklistDetails = ChecklistDetails(
                    checklistId = checkForNull(checklistArray.getJSONObject(i).get("ChecklistID")).toString(),
                    checklistLinearId = "",
                    checklistName = checkForNull(checklistArray.getJSONObject(i).get("Name")).toString(),
                    checklistStatus = checkForNull(checklistArray.getJSONObject(i).get("ChecklistStatus")).toString(),
                    mappedToLinearId = mappedToLinearId,
                    checklistType = "ERISITE",
                    isInternal = false,
                    modifiedTime = Instant.now(),
                    creationTime = Instant.now(),
                    projectId =  projectId,
                    workplanLinearId = workplanLinearId,
                    compiledUrl = "",
                    checklistApprovalStatus = APPROVAL_STATUS.PENDING.toString(),
                    workplanId = workplanId,
                    siteName = siteName,
                    projectLinearId = projectLinearId,
                    siteId = siteId,
                    submittedToExecutionTool = false
            )
            val chklstSignTxn = proxy.startFlow(::ChecklistDetailsFlow, checklistDetails).returnValue.getOrThrow()
            val chklstLinearId = chklstSignTxn.coreTransaction.outputsOfType<ChecklistDetailsState>().single().checklistDetails.checklistLinearId
            val chklistCategory = mutableListOf<ChecklistCategoryTree>()
            logger.info("API UTILS   ---   ChecklistLinearId: "+chklstLinearId)
            ////System.out.println("ChecklistName:" + checklistArray.getJSONObject(i).get("Name"))
            if (checklistArray.getJSONObject(i).has("CheckListCategory")) {
                if (checklistArray.getJSONObject(i).get("CheckListCategory") is JSONArray) {
                    val categories = checklistArray.getJSONObject(i).getJSONArray("CheckListCategory")
                    for(j in 0..(categories.length() - 1)){
                        val categoryDetails = ChecklistCategory(
                                checklistCategoryLinearId = "",
                                checklistCategoryStatus = checkForNull(categories.getJSONObject(j).get("ChecklistCategoryStatus")).toString(),
                                checklistCategoryName = checkForNull(categories.getJSONObject(j).get("Name")).toString(),
                                checklistCategoryId = checkForNull(categories.getJSONObject(j).get("ChecklistCategoryID")).toString(),
                                checklistCategoryApprovalStatus = APPROVAL_STATUS.PENDING.toString(),
                                mappedToLinearId = chklstLinearId
                        )
                        val categorySignTxn = proxy.startFlow(::ChecklistCategoryDetailsFlow, mutableListOf(categoryDetails)).returnValue.getOrThrow()
                        val categoryLinearId = categorySignTxn.coreTransaction.outputsOfType<ChecklistCategoryDetailsState>().get(0).linearId
                        val chklistCategoryItem = mutableListOf<ChecklistCategoryItemsTree>()
                        if (categories.getJSONObject(j).has("CheckListItems") && categories.getJSONObject(j).get("CheckListItems") is JSONArray){

                            val items = categories.getJSONObject(j).getJSONArray("CheckListItems")
                            for(k in 0..(items.length() -1)){
                                val checklistItems = ChecklistItem(
                                        itemLinearId = "",
                                        mappedToLinearId = categoryLinearId.toString(),
                                        commentCount = 0,
                                        itemProof = emptyList(),
                                        criteria = if(items.getJSONObject(k).has("DataValue"))
                                            checkForNull(items.getJSONObject(k).get("DataValue")).toString()
                                        else
                                            "",
                                        executionStatus = "",
                                        itemApprovalStatus = APPROVAL_STATUS.PENDING.toString(),
                                        itemDescription = checkForNull(items.getJSONObject(k).get("Name")).toString(),
                                        itemId = checkForNull(items.getJSONObject(k).get("ChecklistItemID")).toString()
                                )
                                chkListItems.add(checklistItems)
                            }
                            var itemSignTxn = proxy.startFlow(::ChecklistItemDetailsFlow, chkListItems).returnValue.getOrThrow()
                            val itemDetails = itemSignTxn.coreTransaction.outputsOfType<ChecklistItemDetailsState>().map { it.checklistItemDetails }
                            itemDetails.forEach {
                                val checklistCategoryItems = ChecklistCategoryItemsTree(
                                        checklistItemId = it.itemId,
                                        checklistItemLinearId = it.itemLinearId
                                )
                                chklistCategoryItem.add(checklistCategoryItems)
                            }
                        }
                        val checklistCategoryTree = ChecklistCategoryTree(
                                checklistCategoryName = categorySignTxn.coreTransaction.outputsOfType<ChecklistCategoryDetailsState>().get(0).checklistCategoryDetails.checklistCategoryName,
                                checklistCategoryLinearId = categorySignTxn.coreTransaction.outputsOfType<ChecklistCategoryDetailsState>().get(0).checklistCategoryDetails.checklistCategoryLinearId,
                                checklistCategoryItems = chklistCategoryItem
                        )
                        chklistCategory.add(checklistCategoryTree)
                    }
                }
            }
            val checklistTree = ChecklistTree(
                    checklistLinearId = chklstLinearId,
                    checklistName = checklistDetails.checklistName,
                    checklistCategory = chklistCategory
            )
            chklistTree.add(checklistTree)
        }
        return chklistTree
    }

    fun retriveDocDetails(docArray : JSONArray, containerType : String, mappedToLinearId : String, proxy : CordaRPCOps,projectId : String, projectLinearId : String, workplanId : String,
                          workplanLinearId : String, siteId : String, siteName : String) : MutableList<DocumentTree>{
        logger.info("API UTILS   ---   retriveDocDetails Initiated")
        /*   val documentArrayList = mutableListOf<ErisiteDocumentContainer>()
           val docFileArrayList = mutableListOf<Files>()*/
        val fileList = mutableListOf<FileDetails>()
        val documentContainerTreeList = mutableListOf<DocumentTree>()
        for( i in 0..(docArray.length() - 1)){
            val documentContainer = DocumentContainerDetails(
                    containerLinearId = "",
                    mappedToLinearId = mappedToLinearId,
                    siteId = siteId,
                    projectLinearId = projectLinearId,
                    siteName = siteName,
                    projectId = projectId,
                    creationTime = Instant.now(),
                    modifiedTime = Instant.now(),
                    isInternal = false,
                    comment = "",
                    containerApprovalStatus = APPROVAL_STATUS.PENDING.toString(),
                    containerId =  checkForNull(docArray.getJSONObject(i).get("ID")).toString(),
                    containerName = checkForNull(docArray.getJSONObject(i).get("Name")).toString(),
                    containerType = containerType,
                    containerStatus = checkForNull(docArray.getJSONObject(i).get("Status")).toString(),
                    containerDescription = "",
                    containerStoragePath = projectId+"/"+siteId+"/"+workplanId+"/"+mappedToLinearId+"/"+checkForNull(docArray.getJSONObject(i).get("Name")).toString(),
                    workplanLinearId = workplanLinearId,
                    workplanId = workplanId
            )
            val signTxn = proxy.startFlow(::DocumentContainerDetailsFlow, mutableListOf(documentContainer)).returnValue.getOrThrow()
            val containerDetails = signTxn.coreTransaction.outputsOfType<DocumentContainerDetailsState>().single().containerDetails
            val containerTree = DocumentTree(
                    documentContainerLinearId = containerDetails.containerLinearId,
                    containerName = containerDetails.containerName
            )
            documentContainerTreeList.add(containerTree)
            val documentDetails = docArray.getJSONObject(i).getJSONObject("Documents")
            if(documentDetails.has("DocumentList") && documentDetails.get("DocumentList") is JSONArray) {
                val documentArray = documentDetails.getJSONArray("DocumentList")
                for (j in 0..(documentArray.length() - 1)) {
                    val documentItem = documentArray.getJSONObject(j).getJSONObject("Document")
                    val fileItems = FileDetails(
                            fileName = checkForNull(documentItem.get("FileName")).toString(),
                            fileVersion = checkForNull(documentItem.get("Revision")).toString(),
                            comment = "",
                            isInternal = false,
                            mappedToLinearId = containerDetails.containerLinearId,
                            fileStoragePath = containerDetails.containerStoragePath,
                            fileSize = checkForNull(documentItem.get("Size")).toString(),
                            fileModifiedDate = checkForNull(documentItem.get("RevisionDate")).toString(),
                            fileHash = "",
                            isFileModified = false,
                            fileLinearId = "",
                            fileUrl = checkForNull(documentArray.getJSONObject(j).get("DocumentContentURL")).toString()
                    )
                    fileList.add(fileItems)
                }
                val fileSignTxn = proxy.startFlow(::FileDetailsFlow, fileList).returnValue.getOrThrow()
            }
        }
        return documentContainerTreeList
    }

    fun mapActivityDetails(activityArray : JSONArray, mappedToLinearId : String, proxy : CordaRPCOps,projectId : String, projectLinearId : String, workplanId : String,
                           workplanLinearId : String, siteId : String, siteName : String) : MutableList<ActivityTree>{
        logger.info("API UTILS   ---   mapActivityDetails Initiated")
        val activityTreeList = mutableListOf<ActivityTree>()
        try{
            for(i in 0..(activityArray.length() - 1)){
                val activityDetails = ActivityDetailsModel(
                        activityId = checkForNull(activityArray.getJSONObject(i).get("ActivityID")).toString(),
                        activityName = checkForNull(activityArray.getJSONObject(i).get("Name")).toString(),
                        typeOfWork = checkForNull(activityArray.getJSONObject(i).get("TypeOfWork")).toString(),
                        globalProcessStep = checkForNull(activityArray.getJSONObject(i).get("GlobalProcessStep")).toString(),
                        globalPOName = checkForNull(activityArray.getJSONObject(i).get("GlobalPOName")).toString(),
                        sessionType = checkForNull(activityArray.getJSONObject(i).get("SessionType")).toString(),
                        workplanLinearId = workplanLinearId,
                        projectLinearId = projectLinearId,
                        activityLinearId = "",
                        siteId = siteId,
                        activityApprovalStatus = APPROVAL_STATUS.PENDING.toString(),
                        workplanId = workplanId,
                        isInternal = false,
                        modifiedTime = Instant.now(),
                        creationTime = Instant.now(),
                        projectId = projectId,
                        siteName = siteName,
                        activityDescription = "",
                        activityStatus = "",
                        mappedToLinearId = mappedToLinearId,
                        levelName = "ACTIVITY"
                )
                val activitySignTxn = proxy.startFlow(::ActivityDetailsFlow, activityDetails).returnValue.getOrThrow()
                val activityLinearId = activitySignTxn.coreTransaction.outputsOfType<ActivityDetailsState>().get(0).linearId.toString()
                val checklistTreeList = mutableListOf<ChecklistTree>()
                val containerTreeList = mutableListOf<DocumentTree>()
                if (activityArray.getJSONObject(i).has("Checklist") && activityArray.getJSONObject(i).get("Checklist") is JSONArray) {
                    checklistTreeList.addAll(mapChecklistDetails(activityArray.getJSONObject(i).getJSONArray("Checklist"), activityLinearId, proxy,
                            projectId, projectLinearId, workplanId, workplanLinearId, siteId, siteName))
                }
                if (activityArray.getJSONObject(i).has("RequiredDocContainer") && activityArray.getJSONObject(i).get("RequiredDocContainer") is JSONArray) {
                    containerTreeList.addAll(retriveDocDetails(activityArray.getJSONObject(i).getJSONArray("RequiredDocContainer"), "RequiredDocContainer", activityLinearId,proxy,
                            projectId, projectLinearId, workplanId,workplanLinearId, siteId, siteName))
                }
                if (activityArray.getJSONObject(i).has("OptionalDocContainer") && activityArray.getJSONObject(i).getJSONArray("OptionalDocContainer") is JSONArray) {
                    containerTreeList.addAll(retriveDocDetails(activityArray.getJSONObject(i).getJSONArray("OptionalDocContainer"), "OptionalDocContainer", activityLinearId,proxy,
                            projectId, projectLinearId, workplanId,workplanLinearId, siteId, siteName))
                }
                if (activityArray.getJSONObject(i).has("AcceptanceDocContainer") && activityArray.getJSONObject(i).getJSONArray("AcceptanceDocContainer") is JSONArray) {
                    containerTreeList.addAll(retriveDocDetails(activityArray.getJSONObject(i).getJSONArray("AcceptanceDocContainer"), "AcceptanceDocContainer", activityLinearId,proxy,
                            projectId, projectLinearId, workplanId,workplanLinearId, siteId, siteName))
                }
                val activityTree = ActivityTree(
                        activityLinearId = activityLinearId,
                        activityChecklist = checklistTreeList,
                        activityId = activityDetails.activityId,
                        activityName = activityDetails.activityName,
                        activityDocContainer = containerTreeList
                )
                activityTreeList.add(activityTree)
            }
        }catch(e : Exception){
            throw e
        }
        return activityTreeList
    }

    fun getSiteDetailsFromErisite(siteId: String) : FullSiteDetails{
        logger.info("API UTILS   ---   getSiteDetailsFromErisite Initiated")
        val url = API_ERISITE_SB2_URL+"sites/fullstructure?ID="+siteId
        val token = generateErisiteAPIToken()
        val erisiteResp = getErisiteAPIResponse(token, url)
        logger.info("API UTILS   ---   erisite response: "+erisiteResp)
        val data = erisiteResp.jsonObject.getJSONArray("data")
        val siteDetails = FullSiteDetails(
                siteId = checkForNull(data.getJSONObject(0).get("ID")).toString(),
                siteName = checkForNull(data.getJSONObject(0).get("Name")).toString(),
                customer = checkForNull(data.getJSONObject(0).get("Customer")).toString(),
                siteStatus = checkForNull(data.getJSONObject(0).get("SiteStatus")).toString(),
                customerRegion = if (data.getJSONObject(0).has("CustomerRegion"))
                    checkForNull(data.getJSONObject(0).get("CustomerRegion")).toString()
                else
                    "",
                IDByCustomer = checkForNull(data.getJSONObject(0).get("IDByCustomer")).toString(),
                latitudeDecimal = checkForNull(data.getJSONObject(0).get("LatitudeDecimal")).toString(),
                longitudeDecimal = checkForNull(data.getJSONObject(0).get("LongitudeDecimal")).toString(),
                latitudeDMS = checkForNull(data.getJSONObject(0).get("LatitudeDMS")).toString(),
                longitudeDMS = checkForNull(data.getJSONObject(0).get("LongitudeDMS")).toString(),
                nameByCustomer = checkForNull(data.getJSONObject(0).get("NameByCustomer")).toString(),
                region = checkForNull(data.getJSONObject(0).get("Region")).toString(),
                siteType = checkForNull(data.getJSONObject(0).get("SiteType")).toString(),
                subRegion = checkForNull(data.getJSONObject(0).get("SubRegion")).toString()
        )
        return siteDetails
    }

    fun mapMilestoneDetails(milestoneArray : JSONArray, mappedToLinearId : String, proxy : CordaRPCOps,projectId : String, projectLinearId : String, workplanId : String,
                            workplanLinearId : String, siteId : String, siteName : String) : MutableList<MilestoneTree>{
        logger.info("API UTILS   ---   mapMilestoneDetails Initiated")
        val milestoneTreeList = mutableListOf<MilestoneTree>()
        try{
            for(i in 0..(milestoneArray.length() - 1)){
                val milestoneDetails = MilestoneDetails(
                        milestoneLinearId = "",
                        milestoneId = checkForNull(milestoneArray.getJSONObject(i).get("ErisiteMilestoneID")).toString(),
                        milestoneName = checkForNull(milestoneArray.getJSONObject(i).get("MilestoneName")).toString(),
                        typeOfWork = checkForNull(milestoneArray.getJSONObject(i).get("TypeOfWork")).toString(),
                        globalProcessStep = checkForNull(milestoneArray.getJSONObject(i).get("GlobalProcessStep")).toString(),
                        globalPOName = checkForNull(milestoneArray.getJSONObject(i).get("GlobalPOName")).toString(),
                        projectLinearId = projectLinearId,
                        workplanLinearId = workplanLinearId,
                        milestoneApprovalStatus = APPROVAL_STATUS.PENDING.toString(),
                        siteId = siteId,
                        siteName = siteName,
                        projectId = projectId,
                        creationTime = Instant.now(),
                        modifiedTime = Instant.now(),
                        isInternal = false,
                        workplanId = workplanId,
                        milestoneStatus ="",
                        mappedToLinearId = workplanLinearId,
                        levelName = "MILESTONE",
                        mappedToPackageLinearId = ""
                )
                val mileSignTxn = proxy.startFlow(::MilestoneDetailsFlow, milestoneDetails).returnValue.getOrThrow()
                val milestoneLinearId = mileSignTxn.coreTransaction.outputsOfType<MilestoneDetailsState>().single().linearId.toString()
                val checklistTreeList = mutableListOf<ChecklistTree>()
                val containerTreeList = mutableListOf<DocumentTree>()
                if (milestoneArray.getJSONObject(i).has("Checklist") && milestoneArray.getJSONObject(i).get("Checklist") is JSONArray) {
                    checklistTreeList.addAll(mapChecklistDetails(milestoneArray.getJSONObject(i).getJSONArray("Checklist"), milestoneLinearId, proxy,
                            projectId, projectLinearId, workplanId, workplanLinearId, siteId, siteName))
                }
                if (milestoneArray.getJSONObject(i).has("RequiredDocContainer") && milestoneArray.getJSONObject(i).get("RequiredDocContainer") is JSONArray) {
                    containerTreeList.addAll(retriveDocDetails(milestoneArray.getJSONObject(i).getJSONArray("RequiredDocContainer"), "RequiredDocContainer", milestoneLinearId,proxy,
                            projectId, projectLinearId, workplanId,workplanLinearId, siteId, siteName))
                }
                if (milestoneArray.getJSONObject(i).has("OptionalDocContainer") && milestoneArray.getJSONObject(i).getJSONArray("OptionalDocContainer") is JSONArray) {
                    containerTreeList.addAll(retriveDocDetails(milestoneArray.getJSONObject(i).getJSONArray("OptionalDocContainer"), "OptionalDocContainer", milestoneLinearId,proxy,
                            projectId, projectLinearId, workplanId,workplanLinearId, siteId, siteName))
                }
                if (milestoneArray.getJSONObject(i).has("AcceptanceDocContainer") && milestoneArray.getJSONObject(i).getJSONArray("AcceptanceDocContainer") is JSONArray) {
                    containerTreeList.addAll(retriveDocDetails(milestoneArray.getJSONObject(i).getJSONArray("AcceptanceDocContainer"), "AcceptanceDocContainer", milestoneLinearId,proxy,
                            projectId, projectLinearId, workplanId,workplanLinearId, siteId, siteName))
                }
                val milestoneTree = MilestoneTree(
                        milestoneLinearId = milestoneLinearId,
                        milestoneId = milestoneDetails.milestoneId,
                        milestoneChecklist = checklistTreeList,
                        milestoneDocContainer = containerTreeList,
                        milestoneName = milestoneDetails.milestoneName
                )
                milestoneTreeList.add(milestoneTree)
            }
        }catch(e : Exception){
            throw e
        }
        return milestoneTreeList
    }

    fun getRAChecklistItems(checklistLinearId: String, proxy: CordaRPCOps) : List<ItemAcceptanceRA>{
        logger.info("API UTILS   ---   getRAChecklistItems Initiated")
        val checklistCategoryItems = ClientQueryService(proxy).customQueryChecklistCategory(checklistLinearId).map { it.state.data.checklistCategoryDetails }
        val checkListWithItems = mutableListOf<ItemAcceptanceRA>()
        checklistCategoryItems.forEach {c->
            val checklistItems = ClientQueryService(proxy).customQueryChecklistItemDetailsByCategory(c.checklistCategoryLinearId).map { it.state.data.checklistItemDetails }
            checklistItems.forEach {
                var temp = ItemAcceptanceRA(
                        itemId = it.itemId,
                        itemLinearId = it.itemLinearId,
                        itemLabel = c.checklistCategoryName,
                        itemDescription = c.checklistCategoryName + "::" + it.itemDescription,
                        itemCriteria = it.criteria,
                        itemAcceptanceStatus = "",
                        itemAcceptanceComment = "",
                        itemExecutionStatus = "",
                        itemExecutionStatusComment = "",
                        itemExecutionAcceptanceStatus = "",
                        itemExecutionAcceptanceComment = "",
                        itemAcceptanceProof = emptyList(),
                        itemCreationTime = Instant.now().toString(),
                        itemUpdationTime = Instant.now().toString()
                )
                checkListWithItems.add(temp)
            }
        }
        return checkListWithItems;
    }

    fun getRADetails(linearIdList : List<String>, proxy: CordaRPCOps) : MutableList<ChecklistItem> {
        logger.info("API UTILS   ---   getRADetails Initiated")
        val checklistItemList = mutableListOf<ChecklistItem>()
        val url2 =API_RA_QA_GET_URL+linearIdList;
        val r1 = get(url2, headers=mapOf("Content-Type" to "application/json"),auth= BasicAuthorization(RA_USERNAME, RA_PASSWORD))
        val topic1 = Gson().fromJson(r1.jsonObject.toString(), raResp::class.java)
        for(det in topic1.data.orEmpty()){
            logger.info("API UTILS   ---   getRADetails --- Inside Loop")
            var checklistItems : List<ChecklistItem> = emptyList()
            val checklistCategoryItems = ClientQueryService(proxy).customQueryChecklistCategory(det.ssoLinearId).map { it.state.data.checklistCategoryDetails }
            logger.info("API UTILS   ---   getRADetails --- Querying Checklist"+checklistCategoryItems.size)
            if(checklistCategoryItems.isNotEmpty()) {
                checklistCategoryItems.forEach { c ->
                    checklistItems =
                            ClientQueryService(proxy).customQueryChecklistItemDetailsByCategory(c.checklistCategoryLinearId)
                                    .map { it.state.data.checklistItemDetails }
                    logger.info("API UTILS   ---   getRADetails --- Querying checklistItems")
                }
                val checklistItemsMap = checklistItems.map { it.itemLinearId to it }.toMap()
                val raChecklistmap = det.checklist.map { it.itemLinearId to it }.toMap()

                det.checklist.forEach {
                    val itemLinearId = it.itemLinearId
                    logger.info("API UTILS   ---   getRADetails --- Querying checklistItems Inside loop" + checklistItemsMap.size)
                    if (checklistItemsMap.containsKey(it.itemLinearId)) {
                        if (checklistItemsMap[it.itemLinearId]!!.executionStatus == "pass" && checklistItemsMap[it.itemLinearId]!!.itemProof.isNotEmpty()) {
                            logger.info("API UTILS   ---   getRADetails --- Querying checklistItems Inside Map loop")
                            val itemProofs = mutableListOf<ItemProof>()
                            val checklistItemProof = checklistItemsMap[it.itemLinearId]!!.itemProof.sortedBy { it.link }
                            val itemMapProof = it.itemAcceptanceProof.sortedBy { it.link }
                            for (i in itemMapProof.indices) {
                                val itemProofList = ItemProof(
                                        link = itemMapProof[i].link,
                                        hash = itemMapProof[i].hash,
                                        itemValid = false
                                )
                                if (checklistItemProof[i].link != itemMapProof[i].link)
                                    itemProofs.add(itemProofList)
                            }

                            val updatedItem = checklistItemsMap[it.itemLinearId]!!.copy(
                                    itemProof = itemProofs,
                                    executionStatus = it.itemExecutionStatus
                            )
                            if (updatedItem.itemProof.isNotEmpty())
                                checklistItemList.add(updatedItem)
                        }

                        if (checklistItemsMap[it.itemLinearId]?.executionStatus.isNullOrEmpty()) {
                            val itemProofs = mutableListOf<ItemProof>()
                            it.itemAcceptanceProof.forEach {
                                val itemProofList = ItemProof(
                                        link = it.link,
                                        hash = it.hash,
                                        itemValid = true
                                )
                                itemProofs.add(itemProofList);
                            }
                            val checklistItems = checklistItemsMap[it.itemLinearId]!!.copy(
                                    executionStatus = it.itemExecutionStatus,
                                    itemProof = itemProofs
                            )
                            checklistItemList.add(checklistItems)
                        }
                    }
                }
            }
            //System.out.println(checklistItemList)
        }
        logger.info("API UTILS   ---   getRADetails --- Submiting To Corda"+checklistItemList.size)
        if(checklistItemList.isNotEmpty()) {
            var itemSignTxn = proxy.startFlow(::UpdateChecklistItemRAFlow, checklistItemList).returnValue.getOrThrow()
        }
        logger.info("API UTILS   ---   getRADetails --- Return from Corda")
        return checklistItemList
    }



    fun checkForNull(obj : Any?) : Any{
        if(obj == null || obj == "null")
            return ""
        else
            return obj
    }

    fun Template() : ByteArrayInputStream {
        val COLUMNs = arrayOf<String>("Sl.No.", "Description", "Criteria", "Status","Comments")
        val workbook = XSSFWorkbook()
        val createHelper = workbook.getCreationHelper()
        val sheet = workbook.createSheet("Category_Name")
        val headerFont = workbook.createFont()
        headerFont.setBold(true)
        headerFont.setColor(IndexedColors.BLUE.getIndex())
        val headerCellStyle = workbook.createCellStyle()
        headerCellStyle.setFont(headerFont)
        // Row for Header
        val headerRow = sheet.createRow(0)
        // Header
        for (col in COLUMNs.indices) {
            val cell = headerRow.createCell(col)
            cell.setCellValue(COLUMNs[col])
            cell.setCellStyle(headerCellStyle)
        }

        var out = ByteArrayOutputStream()
        workbook.write(out)
        // workbook.close()
        return ByteArrayInputStream(out.toByteArray());
    }

    fun processAllWorkplanOfPackage(packageLinearId : String, projectLinearId : String, proxy : CordaRPCOps, emailId : String) : MutableList<WorkplanTreePackage> {
        logger.info("API UTILS   ---   processAllWorkplanOfPackage Initiated")
        val workplans = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.mappedItemLevel.equals("WORKPLAN") }
        val workplanTreeList = mutableListOf<WorkplanTreePackage>()
        try {
            for (i in 0..(workplans.size - 1)) {
                val workplanDetails = workplans.get(i)

//                val signTxn = proxy.startFlow(::WorkplanDetailsFlow, workplanDetails).returnValue.getOrThrow()
                val workplanLinearId = workplanDetails.mappedItemLinearId
                logger.info("API UTILS   ---   WorkplanLinearId: "+workplanLinearId)
                var checklistTreePackageWorkplan = mutableListOf<ChecklistTreePackage>()
                val docContainerTreePackageWorkplan = mutableListOf<DocumentTreePackage>()
                val activityTreePackageWorkplan = mutableListOf<ActivityTreePackage>()
                val milestoneTreePackageWorkplan = mutableListOf<MilestoneTreePackage>()
                checklistTreePackageWorkplan.addAll(mapChecklistDetailsOfPackage(packageLinearId, proxy,
                            workplanDetails.projectLinearId, workplanLinearId, workplanDetails.siteId, workplanDetails.siteName, emailId))
                docContainerTreePackageWorkplan.addAll(retriveDocDetailsOfPackage(packageLinearId, proxy,
                            workplanDetails.projectLinearId, workplanLinearId, workplanDetails.siteId, workplanDetails.siteName, emailId))
                activityTreePackageWorkplan.addAll(mapActivityDetailsOfPackage(packageLinearId, proxy,
                        workplanDetails.projectLinearId, workplanLinearId ,workplanDetails.siteId, workplanDetails.siteName, emailId))
                milestoneTreePackageWorkplan.addAll(mapMilestoneDetailsOfPackage(packageLinearId, proxy,
                        workplanDetails.projectLinearId, workplanLinearId ,workplanDetails.siteId, workplanDetails.siteName, emailId))
                val workplanTree  = WorkplanTreePackage(
                        workplanLinearId = workplanDetails.mappedItemLinearId,
                        workplanName = workplanDetails.mappedItemName,
                        workplanId = workplanDetails.mappedItemLinearId,
                        siteName = workplanDetails.siteName,
                        siteId = workplanDetails.siteId,
                        activities = activityTreePackageWorkplan,
                        milestones = milestoneTreePackageWorkplan,
                        workplanChecklist = checklistTreePackageWorkplan,
                        workplanDocs = docContainerTreePackageWorkplan,
//                        status = workplanDetails.approverStatus.filter { it.approvedBy.equals(emailId) }.get(0).verdict
                        status = workplanDetails.overallApprovalStatus
                )
                workplanTreeList.add(workplanTree)
            }
        }catch(e : Exception){
            throw e
        }
        return workplanTreeList
    }

    fun mapChecklistDetailsOfPackage(packageLinearId : String, proxy : CordaRPCOps,
                            projectLinearId : String, mappedToLinearId : String, siteId : String, siteName : String, emailId: String) : MutableList<ChecklistTreePackage> {
        logger.info("API UTILS   ---   mapChecklistDetailsOfPackage Initiated")
        val chklistTree = mutableListOf<ChecklistTreePackage>()
        val chklistCategoryItem = mutableListOf<ChecklistCategoryItemsTreePackage>()
        val chklistCategory = mutableListOf<ChecklistCategoryTreePackage>()
        val checklists = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.mappedItemLevel.equals("CHECKLIST") && it.mappedToLinearId.equals(mappedToLinearId) }
        for (j in 0..(checklists.size - 1)) {
            val checklistDetails = checklists.get(j)
            val checklistLinearId = checklistDetails.mappedItemLinearId
            logger.info("API UTILS   ---   ChecklistLinearId: "+checklistLinearId)
            val checklistCategories = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.mappedItemLevel.equals("CHECKLISTCATEGORY") && it.mappedToLinearId.equals(checklistLinearId) }
            for (k in 0..(checklistCategories.size - 1)) {
                val checklistCategory = checklistCategories.get(k)
                val checklistCategoryLinearId = checklistCategory.mappedItemLinearId
                logger.info("API UTILS   ---   ChecklistCategoryLinearId: "+checklistCategoryLinearId)
                val checklistItems = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.mappedItemLevel.equals("CHECKLISTITEM") && it.mappedToLinearId.equals(checklistCategoryLinearId) }
                for (l in 0..(checklistItems.size - 1)) {
                    val checklistItem = checklistItems.get(l)
                    val checklistCategoryItems = ChecklistCategoryItemsTreePackage(
                            checklistItemId = checklistItem.mappedItemId,
                            checklistItemLinearId = checklistItem.mappedItemLinearId,
                            status = checklistItem.overallApprovalStatus
//                            status = checklistItem.approverStatus.filter { it.approvedBy.equals(emailId) }.get(0).verdict
                    )
                    chklistCategoryItem.add(checklistCategoryItems)
                }
                val checklistCategoryTree = ChecklistCategoryTreePackage(
                        checklistCategoryName = checklistCategory.mappedItemName,
                        checklistCategoryLinearId = checklistCategory.mappedItemLinearId,
                        checklistCategoryItems = chklistCategoryItem,
                        status = checklistCategory.overallApprovalStatus
//                        status = checklistCategory.approverStatus.filter { it.approvedBy.equals(emailId) }.get(0).verdict
                )
                chklistCategory.add(checklistCategoryTree)
            }
            val checklistTree = ChecklistTreePackage(
                    checklistLinearId = checklistDetails.mappedItemLinearId,
                    checklistName = checklistDetails.mappedItemName,
                    checklistCategory = chklistCategory,
                    status = checklistDetails.overallApprovalStatus
//                    status = checklistDetails.approverStatus.filter { it.approvedBy.equals(emailId) }.get(0).verdict
            )
            chklistTree.add(checklistTree)
        }
        return chklistTree
    }

    fun retriveDocDetailsOfPackage(packageLinearId : String, proxy : CordaRPCOps,projectLinearId : String,
                          mappedToLinearId : String, siteId : String, siteName : String, emailId: String) : MutableList<DocumentTreePackage>{
        logger.info("API UTILS   ---   retriveDocDetailsOfPackage Initiated")
        val containers = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.mappedItemLevel.equals("CONTAINER") && it.mappedToLinearId.equals(mappedToLinearId) }
        val fileList = mutableListOf<FileDetails>()
        val documentContainerTreeList = mutableListOf<DocumentTreePackage>()
        for (i in 0..(containers.size - 1)) {
            val containerDetails = containers.get(i)
            val containerTree = DocumentTreePackage(
                    documentContainerLinearId = containerDetails.mappedItemLinearId,
                    containerName = containerDetails.mappedItemName,
                    status = containerDetails.overallApprovalStatus
//                    status = containerDetails.approverStatus.filter { it.approvedBy.equals(emailId) }.get(0).verdict
            )
            documentContainerTreeList.add(containerTree)
        }
        return documentContainerTreeList
    }

    fun mapActivityDetailsOfPackage(packageLinearId : String, proxy : CordaRPCOps,projectLinearId : String,
                                    workplanLinearId : String, siteId : String, siteName : String, emailId: String) : MutableList<ActivityTreePackage>{
        logger.info("API UTILS   ---   mapActivityDetailsOfPackage Initiated")
        val activityTreeList = mutableListOf<ActivityTreePackage>()
        try{
            val activites = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.mappedItemLevel.equals("ACTIVITY") && it.mappedToLinearId.equals(workplanLinearId) }
            for(i in 0..(activites.size - 1)){
                val activityDetails = activites.get(i)
                val activityLinearId = activityDetails.mappedItemLinearId
                val checklistTreeListPackageActivity = mutableListOf<ChecklistTreePackage>()
                val containerTreeListPackageActivity = mutableListOf<DocumentTreePackage>()
                checklistTreeListPackageActivity.addAll(mapChecklistDetailsOfPackage(packageLinearId, proxy,
                        projectLinearId, activityLinearId, siteId, siteName, emailId))
                containerTreeListPackageActivity.addAll(retriveDocDetailsOfPackage(packageLinearId, proxy,
                        projectLinearId, activityLinearId, siteId, siteName, emailId))
                val activityTree = ActivityTreePackage(
                        activityLinearId = activityDetails.mappedItemLinearId,
                        activityChecklist = checklistTreeListPackageActivity,
                        activityId = activityDetails.mappedItemId,
                        activityName = activityDetails.mappedItemName,
                        activityDocContainer = containerTreeListPackageActivity,
                        status = activityDetails.overallApprovalStatus
//                        status = activityDetails.approverStatus.filter { it.approvedBy.equals(emailId) }.get(0).verdict
                )
                activityTreeList.add(activityTree)
            }
        }catch(e : Exception){
            throw e
        }
        return activityTreeList
    }

    fun mapMilestoneDetailsOfPackage(packageLinearId : String, proxy : CordaRPCOps,projectLinearId : String,
                                     workplanLinearId : String, siteId : String, siteName : String, emailId: String) : MutableList<MilestoneTreePackage>{
        logger.info("API UTILS   ---   mapMilestoneDetailsOfPackage Initiated")
        val milestoneTreeList = mutableListOf<MilestoneTreePackage>()
        try{
            val milestones = ClientQueryService(proxy).customQueryApproverStatusDetails(packageLinearId).map { it.state.data.approverStatusDetails }.filter { it.mappedItemLevel.equals("MILESTONE") && it.mappedToLinearId.equals(workplanLinearId) }
            for(i in 0..(milestones.size - 1)){
                val milestoneDetails = milestones.get(i)
                val milestoneLinearId = milestoneDetails.mappedItemLinearId
                val checklistTreeListPackageMilestone = mutableListOf<ChecklistTreePackage>()
                val containerTreeListPackageMilestone = mutableListOf<DocumentTreePackage>()
                checklistTreeListPackageMilestone.addAll(mapChecklistDetailsOfPackage(packageLinearId, proxy,
                        projectLinearId, milestoneLinearId, siteId, siteName, emailId))
                containerTreeListPackageMilestone.addAll(retriveDocDetailsOfPackage(packageLinearId, proxy,
                        projectLinearId, milestoneLinearId, siteId, siteName, emailId))
                val milestoneTree = MilestoneTreePackage(
                        milestoneLinearId = milestoneDetails.mappedItemLinearId,
                        milestoneId = milestoneDetails.mappedItemId,
                        milestoneChecklist = checklistTreeListPackageMilestone,
                        milestoneDocContainer = containerTreeListPackageMilestone,
                        milestoneName = milestoneDetails.mappedItemName,
                        status = milestoneDetails.overallApprovalStatus
//                        status = milestoneDetails.approverStatus.filter { it.approvedBy.equals(emailId) }.get(0).verdict
                )
                milestoneTreeList.add(milestoneTree)
            }
        }catch(e : Exception){
            throw e
        }
        return milestoneTreeList
    }
    fun mapActivityDetailsOfPackageCreation(projectLinearId: String, proxy : CordaRPCOps, activities: List<ApproverStatusDetails>) : MutableList<ApproverStatusDetails>{
        logger.info("API UTILS   ---   mapActivityDetailsOfPackageCreation Initiated")
        val comps = mutableListOf<ApproverStatusDetails>()
        try{
            if ( activities.size > 0 )
            {
                activities.forEach {
                    val checklistList = mutableListOf<ApproverStatusDetails>()
                    val containerList = mutableListOf<ApproverStatusDetails>()
                    checklistList.addAll(mapChecklistDetailsOfPackageCreation(projectLinearId, proxy, it, "ACTIVITY"))
                    logger.info("API UTILS   ---   mapActivityDetailsOfPackageCreation checklists: "+checklistList)
                    containerList.addAll(retriveDocDetailsOfPackageCreation(projectLinearId, proxy, it, "ACTIVITY"))
                    logger.info("API UTILS   ---   mapActivityDetailsOfPackageCreation containers: "+containerList)
                    comps.addAll(checklistList)
                    comps.addAll(containerList)
                }
            }
        }catch(e : Exception){
            throw e
        }
        return comps
    }

    fun mapMilestoneDetailsOfPackageCreation(projectLinearId: String, proxy : CordaRPCOps, milestones: List<ApproverStatusDetails>) : MutableList<ApproverStatusDetails>{
        logger.info("API UTILS   ---   mapMilestoneDetailsOfPackageCreation Initiated")
        val comps = mutableListOf<ApproverStatusDetails>()
        try{
            if ( milestones.size > 0 )
            {
                milestones.forEach {
                    val checklistList = mutableListOf<ApproverStatusDetails>()
                    val containerList = mutableListOf<ApproverStatusDetails>()
                    checklistList.addAll(mapChecklistDetailsOfPackageCreation(projectLinearId, proxy, it, "MILESTONE"))
                    logger.info("API UTILS   ---   mapMilestoneDetailsOfPackageCreation checklists: "+checklistList)
                    containerList.addAll(retriveDocDetailsOfPackageCreation(projectLinearId, proxy, it, "MILESTONE"))
                    logger.info("API UTILS   ---   mapMilestoneDetailsOfPackageCreation containers: "+containerList)
                    comps.addAll(checklistList)
                    comps.addAll(containerList)
                }
            }
        }catch(e : Exception){
            throw e
        }
        return comps
    }

    fun mapWorkplanDetailsOfPackageCreation(projectLinearId: String, proxy : CordaRPCOps, workplans: List<ApproverStatusDetails>) : MutableList<ApproverStatusDetails>{
        logger.info("API UTILS   ---   mapWorkplanDetailsOfPackageCreation Initiated")
        val comps = mutableListOf<ApproverStatusDetails>()
        try{
            if ( workplans.size > 0 )
            {
                workplans.forEach {
                    val activityList = mutableListOf<ApproverStatusDetails>()
                    val milestoneList = mutableListOf<ApproverStatusDetails>()
                    val checklistList = mutableListOf<ApproverStatusDetails>()
                    val containerList = mutableListOf<ApproverStatusDetails>()
//                    val actComps = ClientQueryService(proxy).cu(it.mappedItemLinearId).map { it.state.data }
                    val activities = ClientQueryService(proxy).customQueryActivityDetails(it.mappedItemLinearId).map { it.state.data.activityDetails }
                    if (activities.size > 0) {
                        for (i in 0..(activities.size - 1)) {
                            val activityDetails = activities.get(i)
                            val activity = ApproverStatusDetails(
                                    siteName = activityDetails.siteName,
                                    siteId = activityDetails.siteId,
                                    mappedItemName = activityDetails.activityName,
                                    mappedItemId = activityDetails.activityId,
                                    mappedItemLevel = "ACTIVIY",
                                    mappedItemLinearId = activityDetails.activityLinearId,
                                    mappedToLevel = "WORKPLAN",
                                    mappedToLinearId = activityDetails.mappedToLinearId,
                                    mappedToName = it.mappedItemName,
                                    projectLinearId = projectLinearId
                            )
                            activityList.add(activity)
                        }
                    }
                    comps.addAll(mapActivityDetailsOfPackageCreation(projectLinearId, proxy, activityList.toList() ))
                    val milestones = ClientQueryService(proxy).customQueryMilestoneDetailsByWorkplan(it.mappedItemLinearId).map { it.state.data.milestoneDetails }
                    if (milestones.size > 0) {
                        for (i in 0..(milestones.size - 1)) {
                            val milestoneDetails = milestones.get(i)
                            val milestone = ApproverStatusDetails(
                                    siteName = milestoneDetails.siteName,
                                    siteId = milestoneDetails.siteId,
                                    mappedItemName = milestoneDetails.milestoneName,
                                    mappedItemId = milestoneDetails.milestoneId,
                                    mappedItemLevel = "ACTIVIY",
                                    mappedItemLinearId = milestoneDetails.milestoneLinearId,
                                    mappedToLevel = "WORKPLAN",
                                    mappedToLinearId = milestoneDetails.mappedToLinearId,
                                    mappedToName = it.mappedItemName,
                                    projectLinearId = projectLinearId
                            )
                            milestoneList.add(milestone)
                        }
                    }
                    comps.addAll(mapMilestoneDetailsOfPackageCreation(projectLinearId, proxy, milestoneList.toList() ))
                    checklistList.addAll(mapChecklistDetailsOfPackageCreation(projectLinearId, proxy, it, "WORKPLAN"))
                    logger.info("API UTILS   ---   mapWorkplanDetailsOfPackageCreation checklists: "+checklistList)
                    containerList.addAll(retriveDocDetailsOfPackageCreation(projectLinearId, proxy, it, "WORKPLAN"))
                    logger.info("API UTILS   ---   mapWorkplanDetailsOfPackageCreation containers: "+containerList)
                    comps.addAll(checklistList)
                    comps.addAll(containerList)
                }
            }
        }catch(e : Exception){
            throw e
        }
        return comps
    }

    fun mapChecklistDetailsOfPackageCreation(projectLinearId: String, proxy : CordaRPCOps, approverStatusDet: ApproverStatusDetails, levelName : String) : MutableList<ApproverStatusDetails> {
        logger.info("API UTILS   ---   mapChecklistDetailsOfPackageCreation Initiated")
        val chklistTree = mutableListOf<ApproverStatusDetails>()
//        val chklistCategoryItem = mutableListOf<ChecklistCategoryItemsTreePackage>()
//        val chklistCategory = mutableListOf<ChecklistCategoryTreePackage>()
        val checklists = ClientQueryService(proxy).customQueryChecklistDetailsByActivity(approverStatusDet.mappedItemLinearId).map { it.state.data.checklistDetails }
        if (checklists.size > 0) {
            for (j in 0..(checklists.size - 1)) {
                val checklistDetails = checklists.get(j)
                val checklistLinearId = checklistDetails.checklistLinearId
                logger.info("API UTILS   ---   mapChecklistDetailsOfPackageCreation ChecklistLinearId: "+checklistLinearId)
                val checklistCategories = ClientQueryService(proxy).customQueryChecklistCategory(checklistLinearId).map { it.state.data.checklistCategoryDetails }
                for (k in 0..(checklistCategories.size - 1)) {
                    val checklistCategory = checklistCategories.get(k)
                    val checklistCategoryLinearId = checklistCategory.checklistCategoryLinearId
                    logger.info("API UTILS   ---   mapChecklistDetailsOfPackageCreation checklistCategoryLinearId: "+checklistCategoryLinearId)
                    val checklistItems = ClientQueryService(proxy).customQueryChecklistItemDetailsByCategory(checklistCategoryLinearId).map { it.state.data.checklistItemDetails }
                    for (l in 0..(checklistItems.size - 1)) {
                        val checklistItem = checklistItems.get(l)
                        val checklistCategoryItems = ApproverStatusDetails(
                                siteName = checklistDetails.siteName,
                                siteId = checklistDetails.siteId,
                                mappedItemName = checklistItem.itemDescription,
                                mappedItemId = checklistItem.itemId,
                                mappedItemLevel = "CHECKLISTITEM",
                                mappedItemLinearId = checklistItem.itemLinearId,
                                mappedToLevel = "CHECKLISTCATEGORY",
                                mappedToLinearId = checklistItem.mappedToLinearId,
                                mappedToName = checklistCategory.checklistCategoryName,
                                projectLinearId = projectLinearId
                        )
                        chklistTree.add(checklistCategoryItems)
                    }
                    val checklistCategoryTree = ApproverStatusDetails(
                            siteName = checklistDetails.siteName,
                            siteId = checklistDetails.siteId,
                            mappedItemName = checklistCategory.checklistCategoryName,
                            mappedItemId = checklistCategory.checklistCategoryId,
                            mappedItemLevel = "CHECKLISTCATEGORY",
                            mappedItemLinearId = checklistCategory.checklistCategoryLinearId,
                            mappedToLevel = "CHECKLIST",
                            mappedToLinearId = checklistCategory.mappedToLinearId,
                            mappedToName = checklistDetails.checklistName,
                            projectLinearId = projectLinearId
                    )
                    chklistTree.add(checklistCategoryTree)
                }
                val checklistTree = ApproverStatusDetails(
                        siteName = checklistDetails.siteName,
                        siteId = checklistDetails.siteId,
                        mappedItemName = checklistDetails.checklistName,
                        mappedItemId = checklistDetails.checklistId,
                        mappedItemLevel = "CHECKLIST",
                        mappedItemLinearId = checklistDetails.checklistLinearId,
                        mappedToLevel = levelName,
                        mappedToLinearId = checklistDetails.mappedToLinearId,
                        mappedToName = approverStatusDet.mappedItemName,
                        projectLinearId = projectLinearId
                )
                chklistTree.add(checklistTree)
            }
        }
        return chklistTree
    }

    fun retriveDocDetailsOfPackageCreation(projectLinearId: String, proxy : CordaRPCOps, approverStatusDet: ApproverStatusDetails, levelName : String) : MutableList<ApproverStatusDetails> {
        logger.info("API UTILS   ---   retriveDocDetailsOfPackageCreation Initiated")
        val containers = ClientQueryService(proxy).customQueryContainerDetails(approverStatusDet.mappedItemLinearId).map { it.state.data.containerDetails }
        val documentContainerTreeList = mutableListOf<ApproverStatusDetails>()
        if (containers.size > 0) {
            for (i in 0..(containers.size - 1)) {
                val containerDetails = containers.get(i)
                val containerTree = ApproverStatusDetails(
                        siteName = containerDetails.siteName,
                        siteId = containerDetails.siteId,
                        mappedItemName = containerDetails.containerName,
                        mappedItemId = containerDetails.containerId,
                        mappedItemLevel = "CONTAINER",
                        mappedItemLinearId = containerDetails.containerLinearId,
                        mappedToLevel = levelName,
                        mappedToLinearId = containerDetails.mappedToLinearId,
                        mappedToName = approverStatusDet.mappedItemName,
                        projectLinearId = projectLinearId
                )
                documentContainerTreeList.add(containerTree)
            }
        }
        return documentContainerTreeList
    }

    fun processPackageWorkplan(workplanList: MutableList<ApproverStatusDetails>, allItemList: MutableList<ApproverStatusDetails>) : MutableList<WorkplanTree> {
        logger.info("API UTILS   ---   processPackageWorkplan Initiated")
        val workplanTree = mutableListOf<WorkplanTree>()
        try {
            for(workplan in 0..(workplanList.size - 1)){
                val workplanContainerTree = mutableListOf<DocumentTree>()
                val workplanChecklistTree = mutableListOf<ChecklistTree>()
                val workplanActivityTree = mutableListOf<ActivityTree>()
                val workplanMilestoneTree = mutableListOf<MilestoneTree>()
                val filteredWorkplanItems = allItemList.filter { it.mappedToLinearId == workplanList.get(workplan).mappedItemLinearId }
                val filterWorkplanContainers = filteredWorkplanItems.filter { it.mappedItemLevel == "CONTAINER" }
                if(filterWorkplanContainers.size > 0) {
                    workplanContainerTree.addAll(processPackageContainer(filterWorkplanContainers))
                }
                val filterWorkplanChecklist = filteredWorkplanItems.filter { it.mappedItemLevel == "CHECKLIST" }
                if(filterWorkplanChecklist.size > 0){
                    workplanChecklistTree.addAll(processPackageChecklist(filterWorkplanChecklist, allItemList))
                }
                val filterWorkplanActivity = filteredWorkplanItems.filter { it.mappedItemLevel == "ACTIVITY" }
                if(filterWorkplanActivity.size > 0){
                    workplanActivityTree.addAll(processWorkplanActivity(filterWorkplanActivity, allItemList))
                }
                val filterWorkplanMilestone = filteredWorkplanItems.filter { it.mappedItemLevel == "MILESTONE" }
                if(filterWorkplanMilestone.size > 0){
                    workplanMilestoneTree.addAll(processWorkplanMilestone(filterWorkplanMilestone, allItemList))
                }
                val wpTree = WorkplanTree(
                        workplanLinearId = workplanList.get(workplan).mappedItemLinearId,
                        levelName = workplanList.get(workplan).mappedItemLevel,
                        siteName = workplanList.get(workplan).siteName,
                        siteId = workplanList.get(workplan).siteId,
                        workplanId = workplanList.get(workplan).mappedItemId,
                        workplanDocs = workplanContainerTree,
                        workplanChecklist = workplanChecklistTree,
                        milestones = workplanMilestoneTree,
                        activities = workplanActivityTree,
                        workplanName = workplanList.get(workplan).mappedItemName

                )
                workplanTree.add(wpTree)
            }
            return workplanTree
        } catch (e: Exception) {
            throw e
        }
    }

    fun processWorkplanActivity(childElementList : List<ApproverStatusDetails>, allItemList: MutableList<ApproverStatusDetails>) : MutableList<ActivityTree>{
        logger.info("API UTILS   ---   processWorkplanActivity Initiated")
        val activityTree = mutableListOf<ActivityTree>()
        try{

            for(i in 0..(childElementList.size - 1)){
                val childElementContainerTree = mutableListOf<DocumentTree>()
                val childElementChecklistTree = mutableListOf<ChecklistTree>()
                val filteredActivityItems = allItemList.filter { it.mappedToLinearId == childElementList.get(i).mappedItemLinearId }
                val filterChildElementContainers = filteredActivityItems.filter { it.mappedItemLevel == "CONTAINER" }
                if(filterChildElementContainers.size > 0){
                    childElementContainerTree.addAll(processPackageContainer(filterChildElementContainers))
                }
                val filterChildElementChecklist = filteredActivityItems.filter { it.mappedItemLevel == "CHECKLIST" }
                if(filterChildElementChecklist.size > 0){
                    childElementChecklistTree.addAll(processPackageChecklist(filterChildElementChecklist, allItemList))
                }
                val actTree = ActivityTree(
                        activityLinearId = childElementList.get(i).mappedItemLinearId,
                        levelName = childElementList.get(i).mappedItemLevel,
                        activityDocContainer = childElementContainerTree,
                        activityChecklist = childElementChecklistTree,
                        activityName = childElementList.get(i).mappedItemName,
                        activityId = childElementList.get(i).mappedItemId

                )
                activityTree.add(actTree)
            }
            return activityTree
        }catch (e: Exception){
            throw e
        }
    }

    fun processWorkplanMilestone(childElementList : List<ApproverStatusDetails>, allItemList: MutableList<ApproverStatusDetails>) : MutableList<MilestoneTree>{
        logger.info("API UTILS   ---   processWorkplanMilestone Initiated")
        val milestoneTree = mutableListOf<MilestoneTree>()
        try{

            for(i in 0..(childElementList.size - 1)){
                val childElementContainerTree = mutableListOf<DocumentTree>()
                val childElementChecklistTree = mutableListOf<ChecklistTree>()
                val filteredActivityItems = allItemList.filter { it.mappedToLinearId == childElementList.get(i).mappedItemLinearId }
                val filterChildElementContainers = filteredActivityItems.filter { it.mappedItemLevel == "CONTAINER" }
                if(filterChildElementContainers.size > 0){
                    childElementContainerTree.addAll(processPackageContainer(filterChildElementContainers))
                }
                val filterChildElementChecklist = filteredActivityItems.filter { it.mappedItemLevel == "CHECKLIST" }
                if(filterChildElementChecklist.size > 0){
                    childElementChecklistTree.addAll(processPackageChecklist(filterChildElementChecklist, allItemList))
                }
                val mileTree = MilestoneTree(
                        milestoneLinearId = childElementList.get(i).mappedItemLinearId,
                        levelName = childElementList.get(i).mappedItemLevel,
                        milestoneDocContainer = childElementContainerTree,
                        milestoneChecklist = childElementChecklistTree,
                        milestoneName = childElementList.get(i).mappedItemName,
                        milestoneId = childElementList.get(i).mappedItemId

                )
                milestoneTree.add(mileTree)
            }
            return milestoneTree
        }catch (e: Exception){
            throw e
        }
    }

    fun processPackageContainer(containerList : List<ApproverStatusDetails>) : MutableList<DocumentTree>{
        logger.info("API UTILS   ---   processPackageContainer Initiated")
        val containerTreeList = mutableListOf<DocumentTree>()
        try{
            for(container in 0..(containerList.size -1)){
                val containerTree = DocumentTree(
                        documentContainerLinearId = containerList.get(container).mappedItemLinearId,
                        containerName = containerList.get(container).mappedItemName,
                        levelName = containerList.get(container).mappedItemLevel
                )
                containerTreeList.add(containerTree)
            }
            return containerTreeList
        } catch (e : Exception){
            throw e
        }
    }

    fun processPackageChecklist(listOfchecklist : List<ApproverStatusDetails>, allItemList : List<ApproverStatusDetails>) : MutableList<ChecklistTree>{
        logger.info("API UTILS   ---   processPackageChecklist Initiated")
        val checklistTree = mutableListOf<ChecklistTree>()
        try{
            for(i in 0..(listOfchecklist.size -1)){
                val filterChecklistCategory = allItemList.filter { it.mappedToLinearId == listOfchecklist.get(i).mappedItemLinearId }
                if(filterChecklistCategory.size > 0){
                    val categoryTree = processPackageChecklistCategory(filterChecklistCategory, allItemList)
                    val chklistTree = ChecklistTree(
                            checklistLinearId = filterChecklistCategory.get(i).mappedItemLinearId,
                            levelName = filterChecklistCategory.get(i).mappedItemLevel,
                            checklistName = filterChecklistCategory.get(i).mappedItemName,
                            checklistCategory = categoryTree
                    )
                    checklistTree.add(chklistTree)
                }

            }
            return checklistTree
        }catch (e : Exception){
            throw e
        }
    }

    fun processPackageChecklistCategory(listOfChecklistCategory : List<ApproverStatusDetails>, allItemList: List<ApproverStatusDetails>) : MutableList<ChecklistCategoryTree>{
        logger.info("API UTILS   ---   processPackageChecklistCategory Initiated")
        val checklistCategoryTree = mutableListOf<ChecklistCategoryTree>()
        try{
            for(i in 0..(listOfChecklistCategory.size -1)){
                val filterChecklistCategoryItems = allItemList.filter { it.mappedToLinearId == listOfChecklistCategory.get(i).mappedItemLinearId }
                if(filterChecklistCategoryItems.size > 0){
                    val itemTree = processPackageChecklistItems(filterChecklistCategoryItems)
                    val categoryTree = ChecklistCategoryTree(
                            checklistCategoryLinearId = listOfChecklistCategory.get(i).mappedItemLinearId,
                            levelName = listOfChecklistCategory.get(i).mappedItemLevel,
                            checklistCategoryName = listOfChecklistCategory.get(i).mappedItemName,
                            checklistCategoryItems = itemTree
                    )
                    checklistCategoryTree.add(categoryTree)
                }
            }
            return checklistCategoryTree
        }catch(e : Exception){
            throw e
        }
    }

    fun processPackageChecklistItems(listOfChecklistCategoryItem : List<ApproverStatusDetails>) : MutableList<ChecklistCategoryItemsTree>{
        logger.info("API UTILS   ---   processPackageChecklistItems Initiated")
        val checklistCategoryItemsTree = mutableListOf<ChecklistCategoryItemsTree>()
        try{
            for(i in 0..(listOfChecklistCategoryItem.size - 1)){
                val itemCategoryTree = ChecklistCategoryItemsTree(
                        checklistItemId = listOfChecklistCategoryItem.get(i).mappedItemId,
                        levelName = listOfChecklistCategoryItem.get(i).mappedItemLevel,
                        checklistItemLinearId = listOfChecklistCategoryItem.get(i).mappedItemLinearId
                )
                checklistCategoryItemsTree.add(itemCategoryTree)
            }
            return checklistCategoryItemsTree
        }catch(e : Exception){
            throw e
        }
    }

    fun mailText(notificationType: String,name : String,projectName: String,roleName: String,projectLinearId: String,packageName: String,packageLinearId: String,approver: String) : String{
        logger.info("API UTILS   ---   mailText Initiated")
        var html : String =""
        if (notificationType === "USER"){
            html = "<html ?4email>\n" +
                    "    <head>\n" +
                    "    <title>Title of the document</title>\n" +
                    "    <style>\n" +
                    "      .button {\n" +
                    "        background-color: rgba(17,116,230,1);\n" +
                    "        border: none;\n" +
                    "        color: white;\n" +
                    "        background-position: relative;\n" +
                    "        position: relative;\n" +
                    "        left: 24px;\n" +
                    "        padding: 20px 34px;\n" +
                    "        text-align: center;\n" +
                    "        text-decoration: none;\n" +
                    "        display: inline-block;\n" +
                    "        font-size: 20px;\n" +
                    "        margin: 4px 2px;\n" +
                    "      }\n" +
                    "    </style>\n" +
                    "  </head>\n" +
                    "    <body>\n" +
                    "    <DIV \n" +
                    "    style=\"background-color: rgba(17,116,230,1);\n" +
                    "            padding-left: 20px; width: 100%; \n" +
                    "            line-height: 108px;\n" +
                    "            color: rgba(250, 250, 250,1);\n" +
                    "            font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "            font-size: 36px\">Ericsson Customer Acceptance</DIV>\n" +
                    "    \n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 36px\">Hi<span id= \"232902\"></span> $name</DIV>\n" +
                    "\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-weight:light;font-size: 28px\">Welcome the <span id= \"232902\"></span> $projectName</DIV>\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 14px\">You have been added as $roleName role for the project $projectName<span id= \"232902\"></span> </DIV>\n" +
                    "    <DIV style=\"text-align: center;margin:10px\"><a href=\"https://harmonia-test.internal.ericsson.com/projects/$projectLinearId/completion-status\" class=\"button\">View Project</a></DIV>\n" +
                    "\n" +
                    "    \n" +
                    "\n" +
                    "\n" +
                    " <footer>\n" +
                    " <DIV \n" +
                    " style=\"background-color: rgba(235,235,235,1);\n" +
                    "         padding-left: 20px; width: 100%; \n" +
                    "         line-height: 80px;\n" +
                    "         color: rgba(36,36,36,1);\n" +
                    "         font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "         font-size: 14px\">If you don’t yet have access to Ericsson Customer Acceptance please contact us <a href=\"mailto:nro.accetance.harmonia@ericsson.com\">here</a>.</DIV>\n" +
                    " </footer>\n" +
                    "</html>"
        } else if (notificationType === "APPROVER"){
            html = "<html ?4email>\n" +
                    "    <head>\n" +
                    "    <title>Title of the document</title>\n" +
                    "    <style>\n" +
                    "      .button {\n" +
                    "        background-color: rgba(17,116,230,1);\n" +
                    "        border: none;\n" +
                    "        color: white;\n" +
                    "        background-position: relative;\n" +
                    "        position: relative;\n" +
                    "        left: 24px;\n" +
                    "        padding: 20px 34px;\n" +
                    "        text-align: center;\n" +
                    "        text-decoration: none;\n" +
                    "        display: inline-block;\n" +
                    "        font-size: 20px;\n" +
                    "        margin: 4px 2px;\n" +
                    "      }\n" +
                    "    </style>\n" +
                    "  </head>\n" +
                    "    <body>\n" +
                    "    <DIV \n" +
                    "    style=\"background-color: rgba(17,116,230,1);\n" +
                    "            padding-left: 20px; width: 100%; \n" +
                    "            line-height: 108px;\n" +
                    "            color: rgba(250, 250, 250,1);\n" +
                    "            font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "            font-size: 36px\">Ericsson Customer Acceptance</DIV>\n" +
                    "    \n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 36px\">Hi<span id= \"232902\"></span> $name</DIV>\n" +
                    "\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-weight:light;font-size: 28px\">Welcome the <span id= \"232902\"></span> $projectName</DIV>\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 14px\">Acceptance package $packageName is available for your approval<span id= \"232902\"></span> </DIV>\n" +
                    "    <DIV style=\"text-align: center;margin:10px\"><a href=\"https://harmonia-test.internal.ericsson.com/projects/$projectLinearId/acceptance-packages/$packageLinearId\" class=\"button\">View Project</a></DIV>\n" +
                    "\n" +
                    "    \n" +
                    "\n" +
                    "\n" +
                    " <footer>\n" +
                    " <DIV \n" +
                    " style=\"background-color: rgba(235,235,235,1);\n" +
                    "         padding-left: 20px; width: 100%; \n" +
                    "         line-height: 80px;\n" +
                    "         color: rgba(36,36,36,1);\n" +
                    "         font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "         font-size: 14px\">If you don’t yet have access to Ericsson Customer Acceptance please contact us <a href=\"mailto:nro.accetance.harmonia@ericsson.com\">here</a>.</DIV>\n" +
                    " </footer>\n" +
                    "</html>"
        } else  if (notificationType === "ROLE"){
            html = "<html ?4email>\n" +
                    "    <head>\n" +
                    "    <title>Title of the document</title>\n" +
                    "    <style>\n" +
                    "      .button {\n" +
                    "        background-color: rgba(17,116,230,1);\n" +
                    "        border: none;\n" +
                    "        color: white;\n" +
                    "        background-position: relative;\n" +
                    "        position: relative;\n" +
                    "        left: 24px;\n" +
                    "        padding: 20px 34px;\n" +
                    "        text-align: center;\n" +
                    "        text-decoration: none;\n" +
                    "        display: inline-block;\n" +
                    "        font-size: 20px;\n" +
                    "        margin: 4px 2px;\n" +
                    "      }\n" +
                    "    </style>\n" +
                    "  </head>\n" +
                    "    <body>\n" +
                    "    <DIV \n" +
                    "    style=\"background-color: rgba(17,116,230,1);\n" +
                    "            padding-left: 20px; width: 100%; \n" +
                    "            line-height: 108px;\n" +
                    "            color: rgba(250, 250, 250,1);\n" +
                    "            font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "            font-size: 36px\">Ericsson Customer Acceptance</DIV>\n" +
                    "    \n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 36px\">Hi<span id= \"232902\"></span> $name</DIV>\n" +
                    "\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-weight:light;font-size: 28px\">Welcome the <span id= \"232902\"></span> $projectName</DIV>\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 14px\">You have been added as $roleName role for the acceptance package $packageName<span id= \"232902\"></span> </DIV>\n" +
                    "    <DIV style=\"text-align: center;margin:10px\"><a href=\"https://harmonia-test.internal.ericsson.com\" class=\"button\">View Project</a></DIV>\n" +
                    "\n" +
                    "    \n" +
                    "\n" +
                    "\n" +
                    " <footer>\n" +
                    " <DIV \n" +
                    " style=\"background-color: rgba(235,235,235,1);\n" +
                    "         padding-left: 20px; width: 100%; \n" +
                    "         line-height: 80px;\n" +
                    "         color: rgba(36,36,36,1);\n" +
                    "         font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "         font-size: 14px\">If you don’t yet have access to Ericsson Customer Acceptance please contact us <a href=\"mailto:nro.accetance.harmonia@ericsson.com\">here</a>.</DIV>\n" +
                    " </footer>\n" +
                    "</html>"
        }else if (notificationType === "UPDATESTATUS"){
            html = "<html ?4email>\n" +
                    "    <head>\n" +
                    "    <title>Title of the document</title>\n" +
                    "    <style>\n" +
                    "      .button {\n" +
                    "        background-color: rgba(17,116,230,1);\n" +
                    "        border: none;\n" +
                    "        color: white;\n" +
                    "        background-position: relative;\n" +
                    "        position: relative;\n" +
                    "        left: 24px;\n" +
                    "        padding: 20px 34px;\n" +
                    "        text-align: center;\n" +
                    "        text-decoration: none;\n" +
                    "        display: inline-block;\n" +
                    "        font-size: 20px;\n" +
                    "        margin: 4px 2px;\n" +
                    "      }\n" +
                    "    </style>\n" +
                    "  </head>\n" +
                    "    <body>\n" +
                    "    <DIV \n" +
                    "    style=\"background-color: rgba(17,116,230,1);\n" +
                    "            padding-left: 20px; width: 100%; \n" +
                    "            line-height: 108px;\n" +
                    "            color: rgba(250, 250, 250,1);\n" +
                    "            font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "            font-size: 36px\">Ericsson Customer Acceptance</DIV>\n" +
                    "    \n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 36px\">Hi<span id= \"232902\"></span> $name</DIV>\n" +
                    "\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-weight:light;font-size: 28px\">Welcome the <span id= \"232902\"></span> $projectName</DIV>\n" +
                    "\n" +
                    "    <DIV style=\"padding-left:10px; padding-top: 36px;font-family:Ericsson Hild, Helvetica, Arial, sans-serif;font-size: 14px\">Acceptance package $packageName status changed : submitted by approver $approver<span id= \"232902\"></span> </DIV>\n" +
                    "    <DIV style=\"text-align: center;margin:10px\"><a href=\"https://harmonia-test.internal.ericsson.com/projects/$projectLinearId/acceptance-packages/$packageLinearId\" class=\"button\">View Project</a></DIV>\n" +
                    "\n" +
                    "    \n" +
                    "\n" +
                    "\n" +
                    " <footer>\n" +
                    " <DIV \n" +
                    " style=\"background-color: rgba(235,235,235,1);\n" +
                    "         padding-left: 20px; width: 100%; \n" +
                    "         line-height: 80px;\n" +
                    "         color: rgba(36,36,36,1);\n" +
                    "         font-family:Ericsson Hild, Helvetica, Arial, sans-serif;\n" +
                    "         font-size: 14px\">If you don’t yet have access to Ericsson Customer Acceptance please contact us <a href=\"mailto:nro.accetance.harmonia@ericsson.com\">here</a>.</DIV>\n" +
                    " </footer>\n" +
                    "</html>"
        }
        return html;

    }

}


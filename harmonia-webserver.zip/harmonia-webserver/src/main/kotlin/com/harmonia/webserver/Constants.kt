package com.harmonia.webserver

val API_ERISITE_SB2_AUTH_URL : String = "https://api-nonprod.erisite.ericsson.net/token"
val API_ERISITE_SB2_URL : String = "https://api-nonprod.erisite.ericsson.net/sb-erisite/1.0.0/api/"

val ERICSSON_ROLE_ID = "ERI10001"
enum class BELONGS_TO{
    INTERNAL,
    EXTERNAL
}

val API_RA_QA_POST_URL : String = "https://apigwy-qa.ericsson.net/I210315/v1/rest-api/bc-create-session"
val API_RA_QA_GET_URL : String = "https://apigwy-qa.ericsson.net/I210315/v1/rest-api/bc-get-updates?ssoLinearId="

val RA_USERNAME : String ="TSSRAHARRA";
val RA_PASSWORD : String ="vEsb6YBpeN52PefzV3aBZRTx";


val STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=harmonia;AccountKey=hhFVwcysvj8ls+sGV8/qQ1KjuuR4B2iKeWLeWyNK08CZHPe9zzDdNffJPnuBiZleXUl/0+lG3ct+KFH0Kpt3gw==;EndpointSuffix=core.windows.net"
val STORAGE_CONTAINER_NAME = "acceptancedocuments"

enum class APPROVAL_STATUS{
    APPROVED,
    PENDING,
    REJECTED,
    IN_PROGRESS
}

enum class STATUS{
    IN_PROGRESS,
    COMPLETED
}

val OFF_CHAIN_WEB_URL = "http://20.50.147.243:3001"



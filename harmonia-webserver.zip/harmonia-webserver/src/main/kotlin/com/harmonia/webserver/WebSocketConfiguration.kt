//@file:Suppress("DEPRECATION")

package com.harmonia.webserver


import org.springframework.context.annotation.Configuration
import org.springframework.messaging.simp.config.MessageBrokerRegistry
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker
import org.springframework.web.socket.config.annotation.StompEndpointRegistry
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer


//@Configuration
//@EnableWebSocketMessageBroker
//open class WebSocketConfiguration : AbstractWebSocketMessageBrokerConfigurer() {
//    override fun registerStompEndpoints(stompEndpointRegistry: StompEndpointRegistry) {
//        stompEndpointRegistry.addEndpoint("/socket")
//                .setAllowedOrigins("*")
//                .withSockJS()
//    }
//
//    override fun configureMessageBroker(registry: MessageBrokerRegistry) {
//        registry.enableSimpleBroker("/topic","/user")
//        registry.setApplicationDestinationPrefixes("/app")
//    }
//}

@Configuration
@EnableWebSocketMessageBroker
    open class WebSocketConfig : WebSocketMessageBrokerConfigurer {



    override fun configureMessageBroker(config: MessageBrokerRegistry) {
        config.enableSimpleBroker("/import-notification","/user")
        config.enableSimpleBroker("/approvalNotification","/user")
//        config.enableSimpleBroker("/projectComment","/user")
        config.enableSimpleBroker("/comment","/user")
        config.enableSimpleBroker("/submitChecklistNotification","/user")
        config.enableSimpleBroker("/addApproverNotification","/user")
        config.setApplicationDestinationPrefixes("/app")
    }

    override fun registerStompEndpoints(registry: StompEndpointRegistry) {
        registry.addEndpoint("/socket").setAllowedOrigins("*").withSockJS().setHeartbeatTime(1000)
    }
}
